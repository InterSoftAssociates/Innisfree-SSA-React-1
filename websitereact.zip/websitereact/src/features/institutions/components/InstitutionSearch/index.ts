export { default } from './InstitutionSearch';
