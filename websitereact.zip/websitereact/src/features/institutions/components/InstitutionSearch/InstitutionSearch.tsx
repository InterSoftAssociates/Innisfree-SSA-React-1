// hooks
import useInstitutionSearch from '../../hooks/useInstitutionSearch';

// components
import AutocompleteInput from '@/components/shared/AutocompleteInput';

// types
import { Institution } from '@/features/institutions/types';

interface InstitutionSearchProps {
  onInstitutionSelected?: (institution: Institution | null) => void;
  defaultInstitution?: Institution | null;
}

export default function InstitutionSearch({
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  onInstitutionSelected = () => {},
  defaultInstitution,
}: InstitutionSearchProps) {
  const {
    searchTerm,
    handleInputChange,
    institutions,
    isLoading,
    handleSelect,
    isLoadingInfo,
  } = useInstitutionSearch(onInstitutionSelected, defaultInstitution);

  return (
    <AutocompleteInput
      placeholder="Search institution..."
      value={searchTerm || ''}
      onChange={handleInputChange}
      options={institutions}
      isLoading={isLoading}
      isDisabled={isLoadingInfo}
      onOptionClick={handleSelect}
      renderOptionLabel={(institution: Institution) =>
        institution.institutionName
      }
      getOptionKey={(institution: Institution, idx: number) =>
        institution.institutionId + `-${idx}`
      }
    />
  );
}
