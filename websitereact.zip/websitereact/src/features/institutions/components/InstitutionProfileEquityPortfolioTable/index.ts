export { default } from './InstitutionProfileEquityPortfolioTable';
