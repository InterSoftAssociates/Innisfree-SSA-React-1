import { memo, useMemo } from 'react';
import IgniteTable from '@/components/shared/IgniteTable';
import useInstitutionProfileEquityPortfolioTable from '../../hooks/useInstitutionProfileEquityPortfolioTable';
import InstitutionProfile from '../../types/InstitutionProfile';
import { formatToIgniteTableColumns } from '@/lib/formatting';

interface InstitutionProfileEquityPortfolioTableProps {
  institutionProfile: InstitutionProfile;
  isLoading: boolean;
}

function InstitutionProfileEquityPortfolioTable({
  institutionProfile,
  isLoading,
}: InstitutionProfileEquityPortfolioTableProps) {
  const { columns, data, toolbarButtons, activeView } =
    useInstitutionProfileEquityPortfolioTable(institutionProfile);

  // Convert columns to IgniteTable format
  const igniteColumns = useMemo(
    () => formatToIgniteTableColumns(columns),
    [columns],
  );

  return (
    <IgniteTable
      size="small"
      isLoading={isLoading}
      data={data}
      maxHeight={'230px'}
      columns={igniteColumns}
      primaryKey="companyName"
      pageSize={10}
      additionalButtons={toolbarButtons}
      excelFileName={`${institutionProfile?.institution?.institutionName}-${activeView}-${Date.now()}`}
    />
  );
}

export default memo(InstitutionProfileEquityPortfolioTable);
