export { default } from './InstitutionProfileFundsTable';
