// hooks
import { useMemo } from 'react';
import useInstitutionProfileFundsTable from '../../hooks/useInstitutionProfileFundsTable';

// types
import { InstitutionProfile } from '../../types';

// lib
import { formatToIgniteTableColumns } from '@/lib/formatting';

// components
import IgniteTable from '@/components/shared/IgniteTable';

export default function InstitutionProfileFundsTable({
  institutionProfile,
  isLoading,
}: {
  institutionProfile: InstitutionProfile;
  isLoading: boolean;
}) {
  const { columns, data } = useInstitutionProfileFundsTable({
    institutionProfile,
  });

  const igniteColumns = useMemo(
    () => formatToIgniteTableColumns(columns),
    [columns],
  );

  console.log('igniteColumns', igniteColumns);

  return (
    <IgniteTable
      isLoading={isLoading}
      size="small"
      data={data}
      maxHeight={'230px'}
      columns={igniteColumns}
      primaryKey="entityId"
      pageSize={10}
      excelFileName={`${institutionProfile?.institution?.institutionName}-${'people'}-${Date.now()}`}
    />
  );
}
