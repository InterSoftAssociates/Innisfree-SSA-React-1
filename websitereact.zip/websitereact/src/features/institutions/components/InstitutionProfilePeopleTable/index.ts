export { default } from './InstitutionProfilePeopleTable';
