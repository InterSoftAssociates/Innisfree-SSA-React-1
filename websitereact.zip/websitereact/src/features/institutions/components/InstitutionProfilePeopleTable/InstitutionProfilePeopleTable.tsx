// hooks
import { useMemo } from 'react';
import useInstitutionProfilePeopleTable from '../../hooks/useInstitutionProfilePeopleTable';

// types
import { InstitutionProfile } from '../../types';

// lib
import { formatToIgniteTableColumns } from '@/lib/formatting';

// components
import IgniteTable from '@/components/shared/IgniteTable';

export default function InstitutionProfilePeopleTable({
  institutionProfile,
  isLoading,
}: {
  institutionProfile: InstitutionProfile;
  isLoading: boolean;
}) {
  const { columns, data } = useInstitutionProfilePeopleTable({
    institutionProfile,
  });

  const igniteColumns = useMemo(
    () => formatToIgniteTableColumns(columns),
    [columns],
  );

  return (
    <IgniteTable
      isLoading={isLoading}
      size="small"
      data={data}
      maxHeight={'230px'}
      columns={igniteColumns}
      primaryKey="entityId"
      pageSize={10}
      excelFileName={`${institutionProfile?.institution?.institutionName}-${'people'}-${Date.now()}`}
    />
  );
}
