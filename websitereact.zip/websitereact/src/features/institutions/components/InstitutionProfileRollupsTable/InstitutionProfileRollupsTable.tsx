// hooks
import { useMemo } from 'react';
import useInstitutionProfileRollupsTable from '../../hooks/useInstitutionProfileRollupsTable';

// types
import { InstitutionProfile } from '../../types';
import Rollup from '@/types/Rollup';

// lib
import { formatToIgniteTableColumns } from '@/lib/formatting';

// components
import IgniteTable from '@/components/shared/IgniteTable';

export default function InstitutionProfileRollupsTable({
  institutionProfile,
  isLoading,
}: {
  institutionProfile: InstitutionProfile;
  isLoading: boolean;
}) {
  const { columns, data } = useInstitutionProfileRollupsTable({
    institutionProfile,
  });

  const igniteColumns = useMemo(
    () => formatToIgniteTableColumns(columns),
    [columns],
  );

  return (
    <IgniteTable
      isLoading={isLoading}
      size="small"
      data={data as Rollup[]}
      maxHeight={'230px'}
      columns={igniteColumns}
      primaryKey="entityId"
      pageSize={10}
      excelFileName={`${institutionProfile?.institution?.institutionName}-${'people'}-${Date.now()}`}
    />
  );
}
