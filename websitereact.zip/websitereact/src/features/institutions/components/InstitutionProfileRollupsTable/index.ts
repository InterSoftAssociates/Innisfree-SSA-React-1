export { default } from './InstitutionProfileRollupsTable';
