import { useState, useMemo, useCallback } from 'react';
import { TableProps } from '@/components/shared/Table/Table';
import InstitutionProfile from '../types/InstitutionProfile';
import { formatNumber } from '@/lib/formatting';
import { faArrowTrendUp } from '@fortawesome/free-solid-svg-icons';

export type TableView = 'topHoldings' | 'topBuys' | 'topSells';

export default function useInstitutionProfileEquityPortfolioTable(
  institutionProfile: InstitutionProfile,
) {
  const [activeView, setActiveView] = useState<TableView>('topHoldings');

  const columns: TableProps<any>['columns'] = useMemo(() => {
    const baseColumns = [
      {
        key: 'companyName',
        header: 'Companies',
        filter: 'text' as const,
        render: (value: string) => value,
      },
      {
        key: 'value',
        header: 'Value (USD,mm)',
        filter: 'number' as const,
        render: (value: number) => value.toLocaleString(),
      },
      {
        key: 'valueChange',
        header: 'Value Change',
        filter: 'number' as const,
        render: (value: number) => formatNumber(value, 0),
      },
    ];

    // if (activeView === 'topHoldings') {
    //   return [
    //     ...baseColumns,
    //     {
    //       key: 'valueChange',
    //       header: 'Value Change',
    //       filter: 'number' as const,
    //       render: (value: number) => formatCurrency(value, 2),
    //     },
    //   ];
    // }

    return baseColumns;
  }, []);

  const data = useMemo(() => {
    switch (activeView) {
      case 'topHoldings':
        return institutionProfile.topCompanies;
      case 'topBuys':
        return institutionProfile.topBuys;
      case 'topSells':
        return institutionProfile.topSells;
      default:
        return [];
    }
  }, [institutionProfile, activeView]);

  const handleViewChange = useCallback((view: TableView) => {
    setActiveView(view);
  }, []);

  const toolbarButtons = useMemo(
    () => [
      {
        onClick: () => handleViewChange('topHoldings'),
        children: 'Top Holdings',
        isActive: activeView === 'topHoldings',
        icon: faArrowTrendUp,
      },
      {
        onClick: () => handleViewChange('topBuys'),
        children: 'Top Buys',
        isActive: activeView === 'topBuys',
        icon: faArrowTrendUp,
      },
      {
        onClick: () => handleViewChange('topSells'),
        children: 'Top Sells',
        isActive: activeView === 'topSells',
        icon: faArrowTrendUp,
      },
    ],
    [activeView, handleViewChange],
  );

  return {
    columns,
    data,
    toolbarButtons,
    activeView,
  };
}
