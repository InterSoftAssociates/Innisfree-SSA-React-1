import { ColumnDef } from '@/components/shared/Table/Table';
import { useMemo } from 'react';
import { InstitutionProfile } from '../types';
import Fund from '@/types/Fund';

export default function useInstitutionProfileFundsTable({
  institutionProfile,
}: {
  institutionProfile: InstitutionProfile;
}) {
  const columns: ColumnDef<Fund>[] = useMemo(() => {
    return [
      {
        header: 'Name',
        key: 'fundName' as Fund['fundName'],
        render: (value) => value,
      },

      {
        header: 'Investment Style',
        key: 'investmentStyle' as Fund['investmentStyle'],
        render: (value) => value,
      },
    ] as ColumnDef<Fund>[];
  }, []);

  const data = useMemo(() => {
    return institutionProfile.funds;
  }, [institutionProfile]);

  return {
    columns,
    data,
  };
}
