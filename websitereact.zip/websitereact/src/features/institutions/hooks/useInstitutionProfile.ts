import { useParams } from 'react-router';

// hooks
import useSWR from 'swr';

// services
import { getInstitutionProfile } from '../services/institutions.service';

// types
import { InstitutionProfile } from '../types';

interface UseInstitutionProfileReturn {
  data: InstitutionProfile;
  error: any;
  isLoading: boolean;
}

export default function useInstitutionProfile(): UseInstitutionProfileReturn {
  const { entityId } = useParams<{ entityId: string }>();

  const {
    data = {} as InstitutionProfile,
    error,
    isLoading,
  } = useSWR(`INSTITUTION_PROFILE/${entityId}`, () =>
    getInstitutionProfile(Number(entityId)),
  );

  return {
    data,
    error,
    isLoading,
  };
}
