import useAPIAutocompleteSearch from '@/hooks/useAPIAutocompleteSearch';
import { Institution } from '@/features/institutions/types';
import { getInstitutions } from '../../companies/services/companies.service';

interface UseInstitutionSearchReturn {
  searchTerm: string;
  institutions: Institution[];
  isLoading: boolean;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleSelect: (institution: Institution) => Promise<Institution | undefined>;
  isLoadingInfo: boolean;
}

export default function useInstitutionSearch(
  onInstitutionSelected: (institution: Institution | null) => void,
  defaultInstitution?: Institution | null,
): UseInstitutionSearchReturn {
  const genericSearch = useAPIAutocompleteSearch<Institution, Institution>({
    searchFunction: (term) => getInstitutions(term),
    getInfoFunction: async (institution) => institution, // Assuming no additional info needed
    onItemSelected: (institution) => onInstitutionSelected(institution),
    defaultItem: defaultInstitution,
    getSearchTerm: (institution) => institution.institutionName,
    searchKey: 'INSTITUTION_SEARCH',
  });

  return {
    ...genericSearch,
    institutions: genericSearch.items,
  };
}
