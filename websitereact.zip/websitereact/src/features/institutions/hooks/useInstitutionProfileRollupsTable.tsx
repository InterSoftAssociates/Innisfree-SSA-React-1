import { ColumnDef } from '@/components/shared/Table/Table';
import { useMemo } from 'react';
import { InstitutionProfile } from '../types';
import Rollup from '@/types/Rollup';

export default function useInstitutionProfileRollupsTable({
  institutionProfile,
}: {
  institutionProfile: InstitutionProfile;
}) {
  const columns: ColumnDef<Rollup>[] = useMemo(() => {
    return [
      {
        header: 'Name',
        key: 'institutionName' as keyof Rollup,
        render: (value) => value,
      },
    ] as ColumnDef<Rollup>[];
  }, []);

  const data = useMemo(() => {
    return institutionProfile.rollups;
  }, [institutionProfile]);

  return {
    columns,
    data,
  };
}
