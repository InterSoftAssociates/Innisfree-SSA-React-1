import { ColumnDef } from '@/components/shared/Table/Table';
import { useMemo } from 'react';
import { InstitutionProfile } from '../types';
import Person from '@/types/Person';

export default function useInstitutionProfilePeopleTable({
  institutionProfile,
}: {
  institutionProfile: InstitutionProfile;
}) {
  const columns: ColumnDef<Person>[] = useMemo(() => {
    return [
      {
        header: 'Name',
        key: 'fullName' as keyof Person,
        render: (value) => value,
      },
      {
        header: 'Job',
        key: 'jobFunction' as keyof Person,
        render: (value) => value,
      },
      {
        header: 'Phone',
        key: 'phone',
        render: (value) => value,
      },
    ] as ColumnDef<Person>[];
  }, []);

  const data = useMemo(() => {
    return institutionProfile.people;
  }, [institutionProfile]);

  return {
    columns,
    data,
  };
}
