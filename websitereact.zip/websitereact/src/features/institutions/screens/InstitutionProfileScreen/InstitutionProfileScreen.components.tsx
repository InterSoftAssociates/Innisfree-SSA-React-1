import React from 'react';
import {
  Card,
  VerticalLine,
  VerticalLineStats,
  StatsButton,
} from '@/components/shared';

export const SectionHeader = ({
  icon,
  title,
  imageClass = '',
}: {
  icon: string;
  title: string;
  imageClass?: string;
}) => (
  <div className="InstitutionProfileScreen__section__row">
    <img
      src={`/static/images/${icon}`}
      alt={title.toLowerCase()}
      className={`InstitutionProfileScreen__section__image ${imageClass}`}
    />
    <h1 className="InstitutionProfileScreen__section__title">{title}</h1>
  </div>
);

export const EditableField = ({
  label,
  value,
  icon,
  direction = 'left',
}: {
  label: string;
  value: string;
  icon?: string;
  direction?: 'left' | 'right';
}) => (
  <VerticalLine direction={direction}>
    <div className="InstitutionProfileScreen__section__row">
      {icon && (
        <img
          src={`/static/images/${icon}`}
          alt={label.toLowerCase()}
          className="InstitutionProfileScreen__section__image"
        />
      )}
      <label>{label}</label>
      {value || ''}
      <img
        src="/static/images/pencil.png"
        alt="edit"
        className="InstitutionProfileScreen__section__image"
      />
    </div>
  </VerticalLine>
);

export const PortfolioStats = ({
  numHoldings,
  buysIn,
  sellsOut,
  buys,
  sells,
}: {
  numHoldings: number | string | undefined;
  buysIn: number | string | undefined;
  sellsOut: number | string | undefined;
  buys: number | string | undefined;
  sells: number | string | undefined;
}) => (
  <>
    <div className="InstitutionProfileScreen__section__column">
      <div className="InstitutionProfileScreen__section__row">
        <VerticalLineStats
          value={numHoldings}
          label="Holdings"
          variants={['highlight']}
        />
      </div>
    </div>
    <div className="InstitutionProfileScreen__section__column">
      <div className="InstitutionProfileScreen__section__row">
        <StatsButton
          image="/static/images/up-arrow.png"
          label="Buys"
          value={buysIn?.toLocaleString()}
          variants={['buy']}
        />
        <StatsButton
          image="/static/images/down.png"
          label="Sells Out"
          value={sellsOut?.toLocaleString()}
          variants={['sell']}
        />
      </div>
      <div className="InstitutionProfileScreen__section__row">
        <StatsButton
          variants={['buy']}
          label="Buys"
          value={`USD ${buys ? buys.toLocaleString() : ''}`}
        />
        <StatsButton
          variants={['sell']}
          label="Sells"
          value={`USD ${sells ? sells.toLocaleString() : ''}`}
        />
      </div>
    </div>
  </>
);

export const ProfileSection = ({
  children,
  className = '',
  ...rest
}: {
  title?: string;
  children: React.ReactNode;
  className?: string;
  icon?: string;
  [key: string]: any;
}) => (
  <Card
    Component="section"
    contentClassName={`InstitutionProfileScreen__section ${className}`}
    {...rest}
  >
    {children}
  </Card>
);
