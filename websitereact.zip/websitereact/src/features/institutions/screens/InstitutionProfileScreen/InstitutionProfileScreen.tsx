import React from 'react';
import useInstitutionProfile from '../../hooks/useInstitutionProfile';
import {
  Loader,
  TextArea,
  VerticalLine,
  VerticalLineStats,
} from '@/components/shared';
import InstitutionProfileEquityPortfolioTable from '../../components/InstitutionProfileEquityPortfolioTable';
import InstitutionProfilePeopleTable from '../../components/InstitutionProfilePeopleTable/InstitutionProfilePeopleTable';
import InstitutionProfileFundsTable from '../../components/InstitutionProfileFundsTable/InstitutionProfileFundsTable';
import InstitutionProfileRollupsTable from '../../components/InstitutionProfileRollupsTable/InstitutionProfileRollupsTable';
import {
  SectionHeader,
  EditableField,
  PortfolioStats,
  ProfileSection,
} from './InstitutionProfileScreen.components';
import './InstitutionProfileScreen.scss';

export default function InstitutionProfileScreen() {
  const { data: institutionProfile, isLoading } = useInstitutionProfile();
  const { institution } = institutionProfile || {};

  if (isLoading || !institutionProfile) {
    return <Loader isFixed isVisible />;
  }

  return (
    <main className="InstitutionProfileScreen">
      <ProfileSection className="InstitutionProfileScreen__section--demographics">
        <div className="InstitutionProfileScreen__section__column">
          <div className="InstitutionProfileScreen__section__row">
            <img
              src="/static/images/bank.png"
              alt="bank"
              className="InstitutionProfileScreen__section__image InstitutionProfileScreen__section__image--big"
            />
            <h1 className="InstitutionProfileScreen__section__title">
              {institution?.institutionName}
            </h1>
          </div>

          <div className="InstitutionProfileScreen__section__row">
            <img
              src="/static/images/maps-and-flags.png"
              alt="location"
              className="InstitutionProfileScreen__section__image"
            />
            <p className="InstitutionProfileScreen__section__text">
              {institution?.address}
            </p>

            <VerticalLine direction="left">
              <img
                src="/static/images/domain.png"
                alt="domain"
                className="InstitutionProfileScreen__section__image"
              />
              <img
                src="/static/images/pencil.png"
                alt="edit"
                className="InstitutionProfileScreen__section__image"
              />
            </VerticalLine>
          </div>

          <div className="InstitutionProfileScreen__section__row">
            <VerticalLine direction="left">
              <b>Investment Manager-</b>
            </VerticalLine>
          </div>

          <div className="InstitutionProfileScreen__section__row">
            <VerticalLine direction="left">
              <label>Style: {institution?.investmentStyle}</label>
              <img
                src="/static/images/pencil.png"
                alt="edit"
                className="InstitutionProfileScreen__section__image"
              />
            </VerticalLine>
            <VerticalLine direction="left">
              <label>Orientation: </label>
              <img
                src="/static/images/pencil.png"
                alt="edit"
                className="InstitutionProfileScreen__section__image"
              />
            </VerticalLine>
          </div>
        </div>

        <div
          className="InstitutionProfileScreen__section__column"
          style={{ width: '40%' }}
        >
          <VerticalLineStats
            value={institution?.aum?.toLocaleString?.()}
            label="Equity Portfolio Value"
          />
          <VerticalLineStats
            variants={['highlight']}
            value={`%${institution?.turnoverRate ? Number(institution.turnoverRate).toFixed(2) : '0.00'}`}
            label="EQ Turnover Rate"
          />
        </div>
      </ProfileSection>

      <ProfileSection className="InstitutionProfileScreen__section--equity-portfolio">
        <div
          className="InstitutionProfileScreen__section__column"
          style={{ width: '40%' }}
        >
          <SectionHeader
            icon="dollar-symbol.png"
            title="Equity Portfolio"
            imageClass="InstitutionProfileScreen__section__image--big"
          />
          <div
            className="InstitutionProfileScreen__section__row InstitutionProfileScreen__section__row--separator"
            style={{
              display: 'flex',
              justifyContent: 'flex-start',
              gap: '10px',
            }}
          >
            <PortfolioStats
              numHoldings={institution?.numHoldings?.toLocaleString?.()}
              buysIn={institution?.buysIn}
              sellsOut={institution?.sellsOut}
              buys={institution?.buys}
              sells={institution?.sells}
            />
          </div>
        </div>
        <div className="InstitutionProfileScreen__section__table">
          {institutionProfile && (
            <InstitutionProfileEquityPortfolioTable
              institutionProfile={institutionProfile}
              isLoading={isLoading}
            />
          )}
        </div>
      </ProfileSection>

      <section
        className="InstitutionProfileScreen__section__row"
        style={{ alignItems: 'stretch' }}
      >
        <ProfileSection className="InstitutionProfileScreen__section--institution-information">
          <div className="InstitutionProfileScreen__section__column">
            <SectionHeader
              icon="information1.png"
              title="Institution Information"
              imageClass="InstitutionProfileScreen__section__image--big"
            />
            <div className="InstitutionProfileScreen__section__row InstitutionProfileScreen__section__row--separator">
              <EditableField label="Investment Approach" value="" />
            </div>
            <div className="InstitutionProfileScreen__section__row">
              <TextArea
                defaultValue={institution?.profile}
                style={{ minHeight: '150px' }}
              />
            </div>
            <div className="InstitutionProfileScreen__section__row">
              <EditableField label="Quick Links" value="" icon="domain.png" />
              <div className="InstitutionProfileScreen__section__column">
                <EditableField
                  icon="circle-phone-flip.png"
                  label="Phone"
                  value={institution?.phone || ''}
                />
                <EditableField
                  icon="maps-and-flags.png"
                  label="Address"
                  value={institution?.address || ''}
                />
              </div>
            </div>
          </div>
        </ProfileSection>

        <ProfileSection className="InstitutionProfileScreen__section--people">
          <div className="InstitutionProfileScreen__section__column">
            <SectionHeader
              icon="group.png"
              title="People"
              imageClass="InstitutionProfileScreen__section__image--big"
            />
            <div className="InstitutionProfileScreen__section__row InstitutionProfileScreen__section__row--separator">
              <InstitutionProfilePeopleTable
                institutionProfile={institutionProfile}
                isLoading={isLoading}
              />
            </div>
          </div>
        </ProfileSection>
      </section>

      <section
        className="InstitutionProfileScreen__section__row InstitutionProfileScreen__section--equity-focus"
        style={{
          alignItems: 'stretch',
        }}
      >
        <ProfileSection>
          <div className="InstitutionProfileScreen__section__column">
            <SectionHeader
              icon="information1.png"
              title="Equity Focus"
              imageClass="InstitutionProfileScreen__section__image--big"
            />
            <div className="InstitutionProfileScreen__section__row InstitutionProfileScreen__section__row--separator">
              {/* equity focus table can go here */}
            </div>
          </div>
        </ProfileSection>

        <ProfileSection>
          <div className="InstitutionProfileScreen__section__column">
            <SectionHeader
              icon="money.png"
              title="Funds"
              imageClass="InstitutionProfileScreen__section__image--big"
            />
            <div className="InstitutionProfileScreen__section__row InstitutionProfileScreen__section__row--separator">
              {/* funds table can go here */}
              {/* <h5>No Funds</h5> */}
              {isLoading || institutionProfile?.funds?.length ? (
                <InstitutionProfileFundsTable
                  institutionProfile={institutionProfile}
                  isLoading={isLoading}
                />
              ) : (
                <h5>No Funds</h5>
              )}
            </div>
          </div>
        </ProfileSection>

        <ProfileSection style={{ maxWidth: '33%' }}>
          <div className="InstitutionProfileScreen__section__column">
            <SectionHeader
              icon="chart-tree.png"
              title="Parent/Rollups"
              imageClass="InstitutionProfileScreen__section__image--big"
            />
            <div className="InstitutionProfileScreen__section__row InstitutionProfileScreen__section__row--separator">
              {isLoading || institutionProfile?.rollups?.length ? (
                <InstitutionProfileRollupsTable
                  institutionProfile={institutionProfile}
                  isLoading={isLoading}
                />
              ) : (
                <h5>No Parent/Rollups</h5>
              )}
            </div>
          </div>
        </ProfileSection>
      </section>
    </main>
  );
}
