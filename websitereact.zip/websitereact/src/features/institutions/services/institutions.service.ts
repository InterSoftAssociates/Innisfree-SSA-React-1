import api from '@/services/api';
import InstitutionProfile from './../types/InstitutionProfile';

export const getInstitutionProfile = async (
  id: number,
): Promise<InstitutionProfile> => {
  const result = await api.get<InstitutionProfile>(
    `/Home/GetInstProfile/${id}`,
  );
  return result.data;
};
