import Institution from './Institution';
import Person from '@/types/Person';
import Fund from '@/types/Fund';
import Rollup from '@/types/Rollup';

interface InstitutionProfile {
  institution: Institution;
  funds: Fund[];
  rollups?: Rollup[] | null; // null in the response
  parent: null; // null in the response
  people: Person[];
  topCompanies: any[]; // Empty array in the response, type can be refined when data structure is known
  topBuys: any[]; // Empty array in the response, type can be refined when data structure is known
  topSells: any[]; // Empty array in the response, type can be refined when data structure is known
}

export default InstitutionProfile;
