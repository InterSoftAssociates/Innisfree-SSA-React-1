interface Institution {
  address?: string;
  aum?: string;
  buys?: string;
  buysIn?: string;
  entityId: number;
  factsetEntityId: string;
  industry?: string;
  institutionId: number;
  institutionName: string;
  investmentStyle?: string;
  mainFundParent: boolean;
  numHoldings: number;
  phone?: string;
  profile?: string;
  sector?: string;
  sells?: string;
  sellsOut?: string;
  sic?: string;
  turnoverRate?: string;
  instInternalId?: number;
}

export default Institution;
