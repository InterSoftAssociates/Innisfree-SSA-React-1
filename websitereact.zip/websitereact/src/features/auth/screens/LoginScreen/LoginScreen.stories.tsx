import { StoryFn, Meta } from '@storybook/react/types-6-0';
// import { action } from '@storybook/addon-actions';
import { MemoryRouter } from 'react-router-dom';
import LoginScreen from './LoginScreen';
import { expect, userEvent, waitFor, within } from '@storybook/test';

// Mock the auth store
// const mockUseAuthStore = {
//   login: action('login'),
// };

// jest.mock('../../store/auth.store', () => ({
//   __esModule: true,
//   default: () => mockUseAuthStore,
// }));

// // Mock the auth services
// jest.mock('@/features/auth/services', () => ({
//   postLogin: async () => ({ hasError: false }),
//   SSOLogin: async () => ({ hasError: false }),
//   sendLoginCode: async () => ({ success: true }),
// }));

export default {
  title: 'screens/LoginScreen',
  component: LoginScreen,
  decorators: [
    (Story) => (
      <MemoryRouter>
        <Story />
      </MemoryRouter>
    ),
  ],
} as Meta;

const Template: StoryFn = () => <LoginScreen />;

export const Default = Template.bind({});

export const WithError = Template.bind({});
WithError.parameters = {
  initialState: {
    router: {
      location: {
        search: '?error=Invalid%20credentials',
      },
    },
  },
};

export const WithTempCodeModal = Template.bind({});
WithTempCodeModal.play = async ({ canvasElement }) => {
  const canvas = within(canvasElement);

  // Fill in the username and password
  await userEvent.type(canvas.getByPlaceholderText('username'), 'testuser');
  await userEvent.type(canvas.getByPlaceholderText('password'), 'password123');

  // Click the login button
  await userEvent.click(canvas.getByText('Login'));

  // Wait for the modal to appear
  await waitFor(() => {
    expect(
      canvas.getByText('We do not recognize this device'),
    ).toBeInTheDocument();
  });
};
