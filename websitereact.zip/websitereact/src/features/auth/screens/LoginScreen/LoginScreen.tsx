// hooks
import useLogin from '../../hooks/useLogin';

// components
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Card, Input, Button, Modal, Loader } from '@/components/shared';

// icons
import { faLock, faUser, faTimes } from '@fortawesome/free-solid-svg-icons';

// styles
import './LoginScreen.scss';

export default function LoginScreen() {
  const {
    state,
    onLoginButtonClick,
    onLoginSSOClick,
    getTmpCode,
    loginFromGetTmpCodeDialog,
    setField,
    closeMessage,
  } = useLogin();

  const {
    username,
    password,
    messages,
    isLoaderVisible,
    tempCode,
    isRememberDeviceChecked,
    isTmpCodeModalVisible,
  } = state;

  return (
    <div className="LoginScreen">
      <Card variants={['float']} containerClassName="LoginScreen__Card">
        <form className="LoginScreen__form" onSubmit={onLoginButtonClick}>
          <div className="LoginScreen__fieldset">
            <legend className="LoginScreen__legend">Login</legend>
            <div className="LoginScreen__inputs">
              <Input
                id="usern"
                type="text"
                placeholder="username"
                icon={faUser}
                value={username}
                onChange={(e) => setField('username', e.target.value)}
                tabIndex={1}
                required
                autoFocus
              />
              <Input
                id="pass"
                type="password"
                placeholder="password"
                icon={faLock}
                value={password}
                onChange={(e) => setField('password', e.target.value)}
                tabIndex={2}
                required
              />

              <div className="LoginScreen__input-group">
                <Button type="submit">Login</Button>
                <Button
                  onClick={onLoginSSOClick}
                  variant="secondary"
                  type="button"
                >
                  Login By Microsoft Account
                </Button>
              </div>
            </div>
          </div>
          <div className="LoginScreen__messages" onClick={closeMessage}>
            {messages.length > 0 && (
              <div className="LoginScreen__error-message">
                <FontAwesomeIcon
                  icon={faTimes}
                  className="LoginScreen__close-icon"
                />
                <ul className="LoginScreen__error-list">
                  {messages.map((message, index) => (
                    <li key={index} className="LoginScreen__error-item">
                      <span>{message}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </form>
      </Card>
      <Loader isVisible={isLoaderVisible} />
      <Modal
        isOpen={isTmpCodeModalVisible}
        onClose={() => setField('isTmpCodeModalVisible', false)}
        title="We do not recognize this device"
      >
        <Loader isVisible={isLoaderVisible} />

        <div className="LoginScreen__tmp-code-content">
          <Input
            type="text"
            placeholder="Temporary Code"
            value={tempCode}
            onChange={(e) => setField('tempCode', e.target.value)}
          />
          <label className="LoginScreen__remember-device">
            <input
              type="checkbox"
              checked={isRememberDeviceChecked}
              onChange={(e) =>
                setField('isRememberDeviceChecked', e.target.checked)
              }
            />
            Remember me on this device
          </label>
          <Button onClick={getTmpCode}>Get Code</Button>
          <Button onClick={loginFromGetTmpCodeDialog}>Complete Login</Button>
        </div>
      </Modal>
    </div>
  );
}
