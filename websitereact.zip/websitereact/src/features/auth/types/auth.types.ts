export interface AuthResponse {
  idToken: string;
}

export interface VerifyTokenResponse {
  isAuthenticated?: boolean;
  sessionKey: string;
  username: string;
  hasError?: boolean;
  errorMessage?: string;
  user_id?: string;
}

export interface AuthLoginPayload {
  username: string;
  password: string;
  tempCode: string;
  rememberDevice: boolean;
}

export interface AuthLoginResponse {
  sessionKey: string;
  username: string;
  errorMessage?: string;
  hasError?: boolean;
  user_id?: string;
}

export interface AuthStoreState {
  isLoading: boolean;
  error: string | null;
  username: string | null;
  isAuthenticated: boolean;
  logoutMessage: string | null;
}

export interface AuthStoreReducer {
  login: (payload: VerifyTokenResponse) => void;
  logout: (msg?: string) => void;
  isLoggedIn: () => boolean;
  SSOLogout: () => Promise<void>;
  verify: () => Promise<void>;
  setState: (args: Partial<AuthStoreState>) => void;
}

export interface AuthStore extends AuthStoreState, AuthStoreReducer {}
