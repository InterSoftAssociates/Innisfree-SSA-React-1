// store creation
import { create } from 'zustand';
import useCompanyStore from '@/features/companies/store/company.store';

// middleware
import { devtools, persist } from 'zustand/middleware';

// types
import {
  AuthLoginResponse,
  AuthStore,
  AuthStoreState,
  VerifyTokenResponse,
} from '../types';

// types
import { ZustandStoreReducer } from '@/types/zustand.types';

// services/lib
import Cookies from 'js-cookie';
import * as AuthService from '../services/auth.service';

const initialState: AuthStoreState = {
  isLoading: false,
  error: null,
  username: Cookies.get('username') || null,
  isAuthenticated: false,
  logoutMessage: null,
};

const authStoreReducer = (
  set: ZustandStoreReducer<AuthStore>['set'],
  get: ZustandStoreReducer<AuthStore>['get'],
): AuthStore => ({
  ...initialState,

  isLoggedIn: () => {
    const sessionKey = Cookies.get('sessionKey');
    set({ isAuthenticated: !!sessionKey, logoutMessage: null });
    return !!sessionKey;
  },

  login: (
    payload: Partial<VerifyTokenResponse> | Partial<AuthLoginResponse>,
  ) => {
    set({
      isLoading: false,
      isAuthenticated: true,
      username: payload.username || Cookies.get('username'),
    });
  },

  logout: (msg?: string) => {
    AuthService.removeSession();

    set({
      isLoading: false,
      error: null,
      username: null,
      isAuthenticated: false,
      logoutMessage: msg,
    });

    if (msg) {
      window.location.search = `error=${msg}`;
    }

    useCompanyStore.getState().reset();
  },

  SSOLogout: async () => {
    await AuthService.SSOLogout();
    get().logout();
  },

  verify: async () => {
    try {
      const sessionKey = Cookies.get('sessionKey');
      const username = Cookies.get('username');
      const idToken = Cookies.get('idToken');

      const verifyTokenResponse = await AuthService.postVerify(idToken!);

      if (verifyTokenResponse) {
        get().login({
          ...verifyTokenResponse,
          username: verifyTokenResponse.username.split('@', 1)[0],
        });
        return;
      }
      if (!sessionKey || !username) {
        set({ isLoading: false, isAuthenticated: false });
        return;
      }

      set({
        isLoading: false,
        isAuthenticated: true,
      });
    } catch (error) {
      console.error('Verify error:', error);
      set({ isLoading: false, isAuthenticated: false });
      AuthService.removeSession();
      throw error;
    }
  },

  setState: (state: Partial<AuthStore>) => {
    set(state);
  },
});

const persistProps = {
  name: '__innisfree-auth',
  partialize: (state: AuthStore) => ({
    isAuthenticated: state.isAuthenticated,
    username: state.username || Cookies.get('username'),
  }),
};

const devtoolsProps = {
  name: 'AuthStore',
  trace: true,
};

const useAuthStore = create<AuthStore>()(
  devtools(persist(authStoreReducer, persistProps), devtoolsProps),
);

useAuthStore
  .getState()
  .verify()
  .catch((error) => {
    console.error('Verify error:', error);
  });

export default useAuthStore;
