import api from '@api';
import { AxiosResponse } from 'axios';
import Cookies from 'js-cookie';
import {
  AuthLoginPayload,
  VerifyTokenResponse,
  AuthLoginResponse,
} from '../types';
import { displayAPIErrorMessage } from '@/lib/notifications';
import { msalInstance } from '../../../services/msal';
import useAuthStore from '../store';

const domain: string = window.location.hostname;

export const setSessionKey = (sessionKey: string) => {
  Cookies.set('sessionKey', sessionKey, {
    expires: 1 / 2,
    domain,
    secure: true,
  });

  api.defaults.headers.common['SessionKey'] = sessionKey;
  // api.defaults.headers.common['domain'] = domain; // this breaks api calls, probably a config in the backend that doesn't want this domain on port 5173?
};

const setCookieHeaders = (data: VerifyTokenResponse | AuthLoginResponse) => {
  const { username = '', user_id = '', sessionKey } = data;

  Cookies.set('username', username, {
    domain,
    expires: 1 / 2,
    secure: true,
    sameSite: 'strict',
  });

  Cookies.set('user_id', user_id, {
    domain,
    expires: 1 / 2,
    secure: true,
    sameSite: 'strict',
  });

  Cookies.set('sessionKey', sessionKey, {
    domain,
    expires: 1 / 2,
    secure: true,
    sameSite: 'strict',
  });
};

export const removeSession = () => {
  Cookies.remove('sessionKey', { domain });
  Cookies.remove('security', { domain });
  Cookies.remove('idToken', { domain });
  Cookies.remove('username', { domain });
  Cookies.remove('user_id', { domain });

  delete api.defaults.headers.common['SessionKey'];
  // delete api.defaults.headers.common['domain'];
};

export const logout = (msg?: string) => {
  removeSession();
  useAuthStore.getState().logout(msg);
};

export const postLogin = async (payload: AuthLoginPayload) => {
  try {
    const response = await api.post<AuthLoginResponse>('/Home/Login', payload, {
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
      },
    });

    if (response.data?.sessionKey) {
      setSessionKey(response.data.sessionKey);
      setCookieHeaders(response.data);
    }

    useAuthStore.getState().setState({
      username: response.data.username,
      isAuthenticated: true,
    });
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    displayAPIErrorMessage(error);
    throw error;
  }
};

export const postVerify = async (
  idToken: string | undefined = Cookies.get('idToken'),
): Promise<VerifyTokenResponse | void> => {
  try {
    if (!idToken) {
      console.error('No token provided.');
      return;
    }

    const response: AxiosResponse<VerifyTokenResponse> = await api.post(
      `/Home/VerifyToken`,
      { token: idToken },
    );

    const result = response.data;
    if (result.isAuthenticated && result.sessionKey) {
      Cookies.set('idToken', idToken, {
        domain,
        expires: 1 / 2,
      });
      setSessionKey(result.sessionKey);
      setCookieHeaders(result);
      console.log('Token verified and session created.');
    } else {
      console.error('Token verification failed.');
    }

    return result;
  } catch (error) {
    console.error('Error during token verification:', error);
    displayAPIErrorMessage(error);
    throw error;
  }
};

export const SSOLogin = async (): Promise<VerifyTokenResponse | void> => {
  try {
    const loginRequest = {
      scopes: ['openid', 'User.Read'],
    };

    const response = await msalInstance.loginPopup(loginRequest);

    if (response) {
      console.log('ID Token acquired at: ' + new Date().toString());
      console.log(response);

      return (await postVerify(response.idToken)) as VerifyTokenResponse;
    }

    const currentAccounts = msalInstance.getAllAccounts(); // can examing saved token by existing accounts.
    if (!currentAccounts || currentAccounts.length === 0) {
      // No user signed in
      return;
    }
  } catch (error) {
    console.error(error);
    throw error.response.data;
  }
};

export const SSOLogout = async () => {
  try {
    const logoutRequest = {
      account: msalInstance.getAccountByUsername(
        msalInstance.getAllAccounts()[0].username,
      ),
    };

    await msalInstance.logoutRedirect(logoutRequest);
    logout();
    console.log('Logout successful');
  } catch (error) {
    console.error(error);
  }
};

export const sendLoginCode = async (username: string) => {
  try {
    const resp = await api.post('/Home/SendLoginCode', username);
    return resp.data;
  } catch (error) {
    displayAPIErrorMessage(error);
  }
};
