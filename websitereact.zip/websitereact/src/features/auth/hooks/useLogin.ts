// hooks
import { useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import useAuthStore from '../store';
import useAsyncReducer from '@/hooks/useAsyncReducer';
import { useSnackbar } from 'notistack';

// services
import { postLogin, SSOLogin, sendLoginCode } from '@/features/auth/services';

// types
import { VerifyTokenResponse } from '../types';

// lib
import { PATHS } from '@/routes/paths';

type LoginState = {
  username: string;
  password: string;
  messages: string[];
  isLoaderVisible: boolean;
  tempCode: string;
  isRememberDeviceChecked: boolean;
  isTmpCodeModalVisible: boolean;
};

type LoginAction =
  | { type: 'SET_FIELD'; field: keyof LoginState; payload: any }
  | { type: 'CLEAR_MESSAGES' }
  | { type: 'RESET_TMP_CODE_DIALOG' };

const initialState: LoginState = {
  username: '',
  password: '',
  messages: [],
  isLoaderVisible: false,
  tempCode: '',
  isRememberDeviceChecked: false,
  isTmpCodeModalVisible: false,
};

function loginReducer(state: LoginState, action: LoginAction): LoginState {
  switch (action.type) {
    case 'SET_FIELD':
      return { ...state, [action.field]: action.payload };
    case 'CLEAR_MESSAGES':
      return { ...state, messages: [] };
    case 'RESET_TMP_CODE_DIALOG':
      return {
        ...state,
        tempCode: '',
      };
    default:
      return state;
  }
}

export default function useLogin() {
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();
  const [state, dispatch, getState] = useAsyncReducer(
    loginReducer,
    initialState,
  );
  const navigate = useNavigate();
  const { login: authStoreLogin } = useAuthStore();

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const error = urlParams.get('error');
    if (error) {
      dispatch({ type: 'SET_FIELD', field: 'messages', payload: [error] });
    }
  }, [dispatch]);

  const validateLogin = useCallback(() => {
    const err = [];
    const currentState = getState();
    if (currentState.username === '') err.push('Username is required.');
    if (currentState.password === '') err.push('Password is required.');
    dispatch({ type: 'SET_FIELD', field: 'messages', payload: err });
    return err.length === 0;
  }, [dispatch, getState]);

  const setLoading = useCallback(
    (isLoading: boolean) => {
      dispatch({
        type: 'SET_FIELD',
        field: 'isLoaderVisible',
        payload: isLoading,
      });
    },
    [dispatch],
  );

  const handleLoginResponse = useCallback(
    (response: VerifyTokenResponse | null) => {
      if (!response) {
        dispatch({
          type: 'SET_FIELD',
          field: 'messages',
          payload: ['Unknown error occurred.'],
        });
      } else if (response.hasError) {
        if (
          response.errorMessage
            ?.toLowerCase()
            ?.includes?.('access code required')
        ) {
          dispatch({
            type: 'SET_FIELD',
            field: 'isTmpCodeModalVisible',
            payload: true,
          });
        } else {
          dispatch({
            type: 'SET_FIELD',
            field: 'messages',
            payload: [response.errorMessage],
          });
        }
      } else {
        authStoreLogin({
          ...response,
          username: response.username.split('@', 1)[0],
        });
        navigate(PATHS.HOME);
      }
      setLoading(false);
    },
    [authStoreLogin, dispatch, navigate, setLoading],
  );

  const handleLogin = useCallback(async () => {
    try {
      setLoading(true);
      const currentState = getState();
      const response = await postLogin({
        username: currentState.username,
        password: currentState.password,
        tempCode: currentState.tempCode,
        rememberDevice: currentState.isRememberDeviceChecked,
      });
      handleLoginResponse(response);
    } catch (e) {
      setLoading(false);
    }
  }, [getState, handleLoginResponse, setLoading]);

  const onLoginButtonClick = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      dispatch({ type: 'CLEAR_MESSAGES' });
      if (validateLogin()) {
        handleLogin();
      }
    },
    [dispatch, validateLogin, handleLogin],
  );

  const handleSSOLogin = useCallback(async () => {
    try {
      setLoading(true);
      const response = await SSOLogin();
      const currentState = getState();
      if (response && currentState.username === '') {
        dispatch({
          type: 'SET_FIELD',
          field: 'username',
          payload: response.username.split('@', 1)[0],
        });
      }
      handleLoginResponse(response as VerifyTokenResponse);
    } catch (e) {
      setLoading(false);
    }
  }, [dispatch, getState, handleLoginResponse, setLoading]);

  const onLoginSSOClick = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      dispatch({ type: 'CLEAR_MESSAGES' });
      handleSSOLogin();
    },
    [dispatch, handleSSOLogin],
  );

  const getTmpCode = useCallback(async () => {
    setLoading(true);
    closeSnackbar();
    const currentState = getState();
    const resp = await sendLoginCode(currentState.username);
    if (resp.success) {
      dispatch({ type: 'RESET_TMP_CODE_DIALOG' });
      enqueueSnackbar('Check your email for your temporary code', {
        variant: 'info',
      });
    } else {
      enqueueSnackbar(resp.message, { variant: 'error' });
    }
    setLoading(false);
  }, [dispatch, getState, setLoading, enqueueSnackbar, closeSnackbar]);

  const loginFromGetTmpCodeDialog = useCallback(async () => {
    try {
      setLoading(true);
      dispatch({ type: 'RESET_TMP_CODE_DIALOG' });
      closeSnackbar();
      const currentState = getState();
      const response = await postLogin({
        username: currentState.username,
        password: currentState.password,
        tempCode: currentState.tempCode,
        rememberDevice: currentState.isRememberDeviceChecked,
      });
      if (!response || response.hasError) {
        const errorMessage =
          response?.errorMessage === 'Access code required.'
            ? 'Access code provided was not accepted.'
            : response?.errorMessage || 'Unknown error occurred.';

        enqueueSnackbar(errorMessage, { variant: 'error' });
      } else {
        dispatch({
          type: 'SET_FIELD',
          field: 'isTmpCodeModalVisible',
          payload: false,
        });
        authStoreLogin(response);
        navigate(PATHS.HOME);
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
    }
  }, [
    authStoreLogin,
    dispatch,
    getState,
    navigate,
    setLoading,
    enqueueSnackbar,
    closeSnackbar,
  ]);

  const setField = useCallback(
    (field: keyof LoginState, value: any) => {
      dispatch({ type: 'SET_FIELD', field, payload: value });
    },
    [dispatch],
  );

  return {
    state,
    onLoginButtonClick,
    onLoginSSOClick,
    getTmpCode,
    loginFromGetTmpCodeDialog,
    setField,
    closeMessage: useCallback(
      () => dispatch({ type: 'CLEAR_MESSAGES' }),
      [dispatch],
    ),
  };
}
