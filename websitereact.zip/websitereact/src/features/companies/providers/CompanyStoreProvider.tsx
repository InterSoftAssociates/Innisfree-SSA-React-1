import React, { useEffect } from 'react';
import useCompanyStore from '../store/company.store';
import useOnRouteChange from '@/hooks/useOnRouteChange';

export default function CompanyStoreProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const { init, handleNavigation } = useCompanyStore();

  useEffect(() => {
    init();
  }, [init]);

  useOnRouteChange((newRoute: string) => handleNavigation(newRoute));

  return children;
}
