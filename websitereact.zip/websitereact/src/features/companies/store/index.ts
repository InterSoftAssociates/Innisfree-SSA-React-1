export { default } from './company.store';
