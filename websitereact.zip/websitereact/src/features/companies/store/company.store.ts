// store creation/middleware
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';

// types
import { CompanyStore, CompanyStoreState, HistoricalHolder } from '../types';
import { ZustandStoreReducer } from '@/types/zustand.types';

// services
import {
  getInvestmentStyles,
  getReportDates,
  getStakeFilingTypes,
  postGetHistoricalHolders,
  postGetCurrentHolders,
  postGetHitlist,
  postGetCompanyInfo,
} from '../services/companies.service';

// lib
import { displayAPIErrorMessage } from '@/lib/notifications';
import { PATHS } from '@/routes/paths';
import Company from './../types/Company';
import { performanceMeasurement } from '@/lib/performanceMeasurement';

const initialState: CompanyStoreState = {
  isLoadingInit: true,
  isLoadingReportDates: false,
  isLoadingStakeFilingTypes: false,
  isLoadingHistoricalHolders: false,
  isLoadingCurrentHolders: false,
  selectedCompany: null,
  selectedCompanyInfo: null,
  showFilter: 'institutions',
  reportDates: [],
  stakeFilingTypes: [],
  selectedHistoricalPeriods: [],
  selectedStakeFilingTypes: [],
  historicalHolders: [],
  historicalHoldersCompanyName: '',
  currentHolders: [],
  currentHoldersCompanyName: '',
  lastDateTimeUpdated: 0,
  investmentStyles: [],
  currentHoldersCacheKey: '',
  historicalHoldersCacheKey: '',
};

const createCompanyStore = (
  set: ZustandStoreReducer<CompanyStore>['set'],
  get: ZustandStoreReducer<CompanyStore>['get'],
): CompanyStore => ({
  ...initialState,

  getFilterData: async () => {
    try {
      performanceMeasurement.start('getFilterData');

      const {
        reportDates: existingReportDates,
        stakeFilingTypes: existingStakeFilingTypes,
        investmentStyles: existingInvestmentStyles,
      } = get();

      if (
        existingReportDates?.length > 10 &&
        existingStakeFilingTypes?.length > 10 &&
        existingInvestmentStyles?.length > 10
      ) {
        return set({
          isLoadingReportDates: false,
          isLoadingStakeFilingTypes: false,
        });
      }

      set({ isLoadingReportDates: true, isLoadingStakeFilingTypes: true });

      const [reportDates, stakeFilingTypes, investmentStyles] =
        await Promise.all([
          getReportDates(),
          getStakeFilingTypes(),
          getInvestmentStyles(),
        ]);

      const { selectedHistoricalPeriods, selectedStakeFilingTypes } = get();

      set({
        reportDates:
          Array.isArray(reportDates) && reportDates.length
            ? reportDates
            : get().reportDates,
        stakeFilingTypes: stakeFilingTypes || get().stakeFilingTypes,
        selectedHistoricalPeriods: selectedHistoricalPeriods.length
          ? selectedHistoricalPeriods
          : reportDates.slice(0, 3),
        selectedStakeFilingTypes: selectedStakeFilingTypes.length
          ? selectedStakeFilingTypes
          : stakeFilingTypes?.map?.((type) => type.code) || [],
        investmentStyles: investmentStyles || get().investmentStyles,
        isLoadingReportDates: false,
        isLoadingStakeFilingTypes: false,
      });
    } finally {
      performanceMeasurement.end('getFilterData');
    }
  },

  init: async () => {
    const { isLoadingInit, getFilterData } = get();
    if (!isLoadingInit) return;

    try {
      await getFilterData();

      set({
        selectedCompany: get().selectedCompany || null,
        selectedCompanyInfo: get().selectedCompanyInfo || null,
        isLoadingInit: false,
      });
    } catch (error) {
      set({
        isLoadingInit: false,
        isLoadingReportDates: false,
        isLoadingStakeFilingTypes: false,
      });
      displayAPIErrorMessage(error);
    }
  },

  getHistoricalHolders: async (force = false) => {
    let newCacheKey = '';

    try {
      if (
        !window.location.pathname.includes(
          PATHS.COMPANIES.HISTORICAL_HOLDERS,
        ) &&
        !force
      )
        return;

      const {
        selectedCompany,
        showFilter,
        selectedHistoricalPeriods,
        selectedStakeFilingTypes,
        historicalHoldersCacheKey,
      } = get();

      if (!selectedHistoricalPeriods?.length) {
        displayAPIErrorMessage({
          message: 'Please select at least one historical period.',
        });

        return;
      }

      if (!selectedCompany?.companyId) {
        displayAPIErrorMessage({ message: 'Please select a company.' });
        return;
      }

      newCacheKey = `${selectedCompany.companyId}-${showFilter}-${selectedHistoricalPeriods.join(',')}-${selectedStakeFilingTypes.join(',')}`;
      if (newCacheKey === historicalHoldersCacheKey && !force) return;

      set({ isLoadingHistoricalHolders: true });

      const result = await postGetHistoricalHolders({
        companyId: selectedCompany.companyId as number,
        clientInd: selectedCompany.clientInd ?? false,
        byInst: showFilter === 'institutions',
        reportDates: selectedHistoricalPeriods,
        filingTypes: selectedStakeFilingTypes,
      });

      if (!result?.dataString) throw new Error('No data returned');

      const historicalHolders = JSON.parse(
        result.dataString,
      ) as HistoricalHolder[];
      set({
        historicalHolders,
        historicalHoldersCompanyName: result.companyName,
        isLoadingHistoricalHolders: false,
        lastDateTimeUpdated: new Date().getTime(),
        historicalHoldersCacheKey: newCacheKey,
      });
    } catch (error) {
      set((prevState) => ({
        isLoadingHistoricalHolders: false,
        historicalHolders: [],
        historicalHoldersCompanyName: prevState.historicalHoldersCompanyName,
        lastDateTimeUpdated: new Date().getTime(),
        historicalHoldersCacheKey: newCacheKey,
      }));
      displayAPIErrorMessage(error);
    }
  },

  getCurrentHolders: async (force = false) => {
    let newCacheKey = '';
    try {
      if (
        !window.location.pathname.includes(PATHS.COMPANIES.CURRENT_HOLDERS) &&
        !force
      )
        return;

      const {
        selectedCompany,
        showFilter,
        selectedStakeFilingTypes,
        currentHoldersCacheKey,
      } = get();

      if (!selectedCompany?.companyId) {
        displayAPIErrorMessage({ message: 'Please select a company.' });
        return;
      }

      newCacheKey = `${selectedCompany.companyId}-${showFilter}-${selectedStakeFilingTypes.join(',')}`;
      if (newCacheKey === currentHoldersCacheKey && !force) return;

      set({ isLoadingCurrentHolders: true });

      const result = await postGetCurrentHolders({
        companyId: selectedCompany.companyId as number,
        clientInd: selectedCompany.clientInd ?? false,
        byInst: showFilter === 'institutions',
        filingTypes: selectedStakeFilingTypes,
      });

      // console.log('selectedCompany', selectedCompany);
      // if (!result?.currHolders?.length)
      //   throw new Error(
      //     'No current holders data for: ' + selectedCompany.ticker,
      //   );

      set({
        currentHolders: result.currHolders,
        currentHoldersCompanyName: result.companyName,
        isLoadingCurrentHolders: false,
        lastDateTimeUpdated: new Date().getTime(),
        currentHoldersCacheKey: newCacheKey,
      });
    } catch (error) {
      set((prevState) => ({
        isLoadingCurrentHolders: false,
        currentHolders: prevState.currentHolders,
        currentHoldersCompanyName: prevState.currentHoldersCompanyName,
        lastDateTimeUpdated: new Date().getTime(),
        currentHoldersCacheKey: newCacheKey,
      }));
      displayAPIErrorMessage(error);
    }
  },

  handleNavigation: (newRoute: string) => {
    const { getCurrentHolders, getHistoricalHolders, selectedCompany } = get();
    if (!selectedCompany) return;

    if (newRoute.includes(PATHS.COMPANIES.CURRENT_HOLDERS)) {
      getCurrentHolders();
    } else if (newRoute.includes(PATHS.COMPANIES.HISTORICAL_HOLDERS)) {
      getHistoricalHolders();
    }
  },

  setSelectedCompany: (data, force = false) => {
    try {
      // performanceMeasurement.start('setSelectedCompany');
      const {
        selectedCompany: prevSelectedCompany,
        getHistoricalHolders,
        getCurrentHolders,
      } = get();

      if (prevSelectedCompany?.companyId === data.company?.companyId) {
        if (!force) return;
      }

      set((prevState) => ({
        selectedCompany: data.company,
        selectedCompanyInfo: data.companyInfo ?? prevState.selectedCompanyInfo,
        currentHoldersCacheKey: '',
        historicalHoldersCacheKey: '',
      }));

      const currentRoute = window.location.pathname;
      if (currentRoute.includes(PATHS.COMPANIES.HISTORICAL_HOLDERS)) {
        getHistoricalHolders(true);
      }

      if (currentRoute.includes(PATHS.COMPANIES.CURRENT_HOLDERS)) {
        getCurrentHolders(true);
      }
    } finally {
      // performanceMeasurement.end('setSelectedCompany');
    }
  },

  setSelectedCompanyFromHomeScreen: async (company: Company) => {
    if (get().selectedCompany?.companyId === company.companyId) return;

    set({
      selectedCompany: null,
      selectedCompanyInfo: null,
      currentHoldersCacheKey: '',
      historicalHoldersCacheKey: '',
    });

    const {
      setSelectedCompany,
      reportDates,
      stakeFilingTypes,
      investmentStyles,
      getFilterData,
    } = get();

    // if there are no selected historical periods, select the first 3, and if there aren't any from the API, fetch them, like in the init function.
    if (
      !reportDates?.length ||
      !stakeFilingTypes?.length ||
      !investmentStyles?.length
    ) {
      await getFilterData();
    }

    const companyInfo = await postGetCompanyInfo(company.companyId);
    set({ selectedCompanyInfo: companyInfo, selectedCompany: company });

    setSelectedCompany(
      {
        company,
        companyInfo,
      },
      true,
    );
  },

  onFilterChange: () => {
    try {
      performanceMeasurement.start('onFilterChange');
      const { getHistoricalHolders, getCurrentHolders } = get();
      const currentRoute = window.location.pathname;

      if (currentRoute.includes(PATHS.COMPANIES.HISTORICAL_HOLDERS)) {
        getHistoricalHolders(true);
      } else if (currentRoute.includes(PATHS.COMPANIES.CURRENT_HOLDERS)) {
        getCurrentHolders(true);
      }
    } finally {
      performanceMeasurement.end('onFilterChange');
    }
  },

  setShowFilter: (filter) => {
    set({ showFilter: filter });
    get().onFilterChange();
  },

  setSelectedHistoricalPeriods: (dates) => {
    set({ selectedHistoricalPeriods: dates });
    get().onFilterChange();
  },

  setSelectedStakeFilingTypes: (types) => {
    set({ selectedStakeFilingTypes: types });
    get().onFilterChange();
  },

  selectAllHistoricalPeriods: () => {
    const { reportDates } = get();
    set({ selectedHistoricalPeriods: reportDates });
    get().onFilterChange();
  },

  selectAllStakeFilingTypes: () => {
    const { stakeFilingTypes } = get();
    set({
      selectedStakeFilingTypes: stakeFilingTypes.map((type) => type.code),
    });
    get().onFilterChange();
  },

  getHitlist: async () => {
    const {
      selectedCompany,
      showFilter,
      selectedHistoricalPeriods,
      selectedStakeFilingTypes,
    } = get();
    await postGetHitlist({
      companyId: selectedCompany?.companyId as number,
      byInst: showFilter === 'institutions',
      reportDates: selectedHistoricalPeriods,
      filingTypes: selectedStakeFilingTypes,
    });
  },

  forceRefresh: () => {
    const { getCurrentHolders, getHistoricalHolders } = get();
    getCurrentHolders(true);
    getHistoricalHolders(true);
  },

  reset: () => {
    useCompanyStore.persist.clearStorage();
    set({
      ...initialState,
    });
  },
});

const useCompanyStore = create<CompanyStore>()(
  devtools(
    persist(createCompanyStore, {
      name: '__innisfree-companies',
      partialize: (state) => ({
        isLoadingInit: state.isLoadingInit,
        selectedCompany: state.selectedCompany,
        selectedCompanyInfo: state.selectedCompanyInfo,
        showFilter: state.showFilter,
        stakeFilingTypes: state.stakeFilingTypes,
        reportDates: state.reportDates,
        selectedHistoricalPeriods:
          state.selectedHistoricalPeriods ||
          state.reportDates?.slice?.(0, 3) ||
          [],
        selectedStakeFilingTypes:
          state.selectedStakeFilingTypes ||
          state.stakeFilingTypes?.map?.((type) => type.code) ||
          [],
        historicalHolders: state.historicalHolders,
        historicalHoldersCompanyName: state.historicalHoldersCompanyName,
        lastDateTimeUpdated: state.lastDateTimeUpdated,
        investmentStyles: state.investmentStyles,
        currentHolders: state.currentHolders,
        currentHoldersCompanyName: state.currentHoldersCompanyName,
        currentHoldersCacheKey: state.currentHoldersCacheKey,
        historicalHoldersCacheKey: state.historicalHoldersCacheKey,
      }),
    }),
    { name: 'CompanyStore', trace: true },
  ),
);

export default useCompanyStore;
