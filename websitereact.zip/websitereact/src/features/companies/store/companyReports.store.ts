// store creation/middleware
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';

// types
import { ZustandStoreReducer } from '@/types/zustand.types';
import { Company } from '../types';
import {
  CompanyReportsStore,
  CompanyReportsStoreState,
} from '../types/CompanyReportsStore';

// lib
import { filterUnique } from '@/lib/filtering';
import { postGetMoneyFlowReport } from '../services/companies.service';

const initialState: CompanyReportsStoreState = {
  selectedCompanies: [],
  reportType: 'moneyflow',
  isRunReportLoading: false,
};

const createCompanyReportsStore = (
  set: ZustandStoreReducer<CompanyReportsStore>['set'],
  get: ZustandStoreReducer<CompanyReportsStore>['get'],
): CompanyReportsStore => ({
  ...initialState,

  setReportType: (reportType: string) => {
    set({ reportType });
  },

  addCompany: (company: Company): Company[] => {
    const { selectedCompanies } = get();

    const updatedSelectedCompanies = filterUnique([
      ...selectedCompanies,
      company,
    ]);

    set((prevState) => ({
      ...prevState,
      selectedCompanies: updatedSelectedCompanies,
    }));

    return updatedSelectedCompanies;
  },

  removeCompany: (company: Company): Company[] => {
    const { selectedCompanies } = get();

    const updatedSelectedCompanies = selectedCompanies.filter(
      (selectedCompany) => selectedCompany.companyId !== company.companyId,
    );

    set((prevState) => ({
      ...prevState,
      selectedCompanies: updatedSelectedCompanies,
    }));

    return updatedSelectedCompanies;
  },

  runReport: async () => {
    try {
      set({ isRunReportLoading: true });
      const { reportType, selectedCompanies } = get();
      const companyIds: number[] = selectedCompanies.map(
        (company) => company.companyId,
      );

      switch (reportType) {
        case 'moneyflow':
          await postGetMoneyFlowReport(companyIds);
          break;
        default:
          await postGetMoneyFlowReport(companyIds);
      }
    } finally {
      set({ isRunReportLoading: false });
    }
  },
});

const useCompanyReportsStore = create<CompanyReportsStore>()(
  persist(devtools(createCompanyReportsStore), {
    name: '__innisfree-company-reports',
  }),
);

export default useCompanyReportsStore;
