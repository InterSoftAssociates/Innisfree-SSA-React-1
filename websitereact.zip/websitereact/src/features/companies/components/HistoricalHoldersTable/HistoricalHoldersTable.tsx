import { memo } from 'react';

// hooks
import useHistoricalHoldersTable from '../../hooks/useHistoricalHoldersTable';

// types
import { HistoricalHolder } from '../../types';

// components
import Table from '@/components/shared/Table';

export default function HistoricalHoldersTable({
  initialData,
  isInitialLoading = undefined,
}: {
  initialData?: HistoricalHolder[] | null;
  isInitialLoading?: boolean | undefined;
}) {
  const {
    columns,
    data,
    initialSort,
    initialSortDirection,
    initialLimit,
    isLoading,
    selectedCompany,
    additionalButtons,
  } = useHistoricalHoldersTable();

  return (
    <Table
      data={initialData || data}
      isLoading={isInitialLoading !== undefined ? isInitialLoading : isLoading}
      // @ts-expect-error i dont know why it's complaining about this
      columns={columns}
      initialSort={initialSort}
      initialSortDirection={initialSortDirection}
      initialLimit={initialLimit}
      fileName={`${selectedCompany?.ticker}-${selectedCompany?.companyName}-${Date.now()}`}
      toolbarButtons={additionalButtons}
    />
  );
}
