export { default } from './HistoricalHoldersTable';
