import { memo } from 'react';

// hooks
import useCompanyReportsTable from '@/features/companies/hooks/useCompanyReportsTable';

// components
import IgniteTable from '@/components/shared/IgniteTable';
import CompanyReportsSelect from '../CompanyReportsSelect';
import { ToolbarButton } from '@/components/shared';

// styles
import './CompanyReportsTable.scss';

export default function CompanyReportsTable() {
  const { igniteColumns, data, toolbarButtons, isRunReportLoading } =
    useCompanyReportsTable();

  return (
    <IgniteTable
      primaryKey="companyId"
      columns={igniteColumns}
      data={data}
      isLoading={isRunReportLoading}
      renderToolbar={() => (
        <CompanyReportsTableToolbar toolbarButtons={toolbarButtons} />
      )}
    />
  );
}

const CompanyReportsTableToolbar = memo(
  ({
    toolbarButtons,
  }: {
    toolbarButtons: {
      onClick: () => void;
      children: React.ReactNode;
      icon?: any;
    }[];
  }) => (
    <div className="CompanyReportsTable__toolbar">
      <div className="CompanyReportsTable__toolbar__left">
        <div className="CompanyReportsTable__toolbar__left__reports">
          <label className="CompanyReportsTable__toolbar__left__reports__label">
            Reports
          </label>
          <div className="CompanyReportsTable__toolbar__left__reports__select">
            <CompanyReportsSelect />
          </div>
        </div>
        <p className="CompanyReportsTable__toolbar__left__directions">
          <b>Directions:</b> Enter companies above and it will fill the list
          below. The report will run on the companies in the list.
        </p>
      </div>
      <div className="CompanyReportsTable__toolbar__right">
        {toolbarButtons.map(
          (
            button: {
              onClick: () => void;
              children: React.ReactNode;
              icon?: any;
            },
            index: number,
          ) => (
            <ToolbarButton
              key={index}
              onClick={button.onClick}
              icon={button.icon}
            >
              {button.children}
            </ToolbarButton>
          ),
        )}
      </div>
    </div>
  ),
);
