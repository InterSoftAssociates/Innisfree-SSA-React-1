export { default } from './CompanyReportsTable';
