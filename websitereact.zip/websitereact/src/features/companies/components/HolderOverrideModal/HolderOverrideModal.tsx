import { useState } from 'react';

// components
import { Modal } from '@/components/shared';
import InstitutionSearch from '@/features/institutions/components/InstitutionSearch';
import InvestmentStyleSearch from '../InvestmentStyleSearch';

// types
import { Institution } from '@/features/institutions/types';
import { InvestmentStyle } from '../../types';

// styles
import './HolderOverrideModal.scss';

export default function HolderOverrideModal({
  row,
  isOpen,
  onClose,
}: {
  row: Institution;
  isOpen: boolean;
  onClose: () => void;
}) {
  const [selectedInstitution, setSelectedInstitution] =
    useState<Institution | null>(null);

  const [selectedInvestmentStyle, setSelectedInvestmentStyle] =
    useState<InvestmentStyle | null>(null);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Override"
      isCloseButtonVisible
      actionButtons={[
        {
          children: 'Save',
          onClick: onClose, // todo: implement save
        },
        {
          variant: 'danger',
          children: 'Cancel',
          onClick: onClose,
        },
      ]}
    >
      <div className="HolderOverrideModal">
        <InstitutionSearch
          defaultInstitution={row}
          onInstitutionSelected={(institution) => {
            setSelectedInstitution(institution);
          }}
        />
        <InvestmentStyleSearch
          defaultInvestmentStyle={selectedInvestmentStyle}
          onInvestmentStyleSelected={(investmentStyle) =>
            setSelectedInvestmentStyle(investmentStyle)
          }
        />
      </div>
    </Modal>
  );
}
