export { default } from './HolderFundsTable';
