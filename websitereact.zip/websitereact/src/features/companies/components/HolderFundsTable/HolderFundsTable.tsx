// hooks
import useHolderFundsTable from '../../hooks/useHolderFundsTable';

// components
import Table from '@/components/shared/Table';

// types
import { FundTableColumns } from '../../types/Fund';
import { ColumnDef } from '@/components/shared/Table/Table';

export default function HolderFundsTable({
  isOpen = false,
  entityId = 0,
  initialSort,
}: {
  isOpen?: boolean;
  entityId?: number;
  initialSort?: undefined;
}) {
  const { columns, data, initialSortDirection, initialLimit, isLoading } =
    useHolderFundsTable({ isOpen, entityId });

  return (
    <Table
      data={data}
      isLoading={isLoading}
      // @ts-expect-error i dont know why it's complaining about this
      columns={columns as ColumnDef<FundTableColumns>[]}
      initialSort={initialSort}
      initialSortDirection={initialSortDirection}
      initialLimit={initialLimit}
    />
  );
}
