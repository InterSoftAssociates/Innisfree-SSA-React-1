export { default } from './HistoricalHoldersIgniteTable';
