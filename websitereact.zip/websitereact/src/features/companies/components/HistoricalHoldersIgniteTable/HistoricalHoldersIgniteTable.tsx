import { memo } from 'react';
// hooks
import useHistoricalHoldersTableIgnite from '../../hooks/useHistoricalHoldersTableIgnite';

// components
import IgniteTable from '@/components/shared/IgniteTable';

// types
import { HistoricalHolder, HistoricalHolderTableColumns } from '../../types';

function HistoricalHoldersIgniteTable() {
  const { columns, data, isLoading, primaryKey, additionalButtons } =
    useHistoricalHoldersTableIgnite();

  return (
    <IgniteTable<HistoricalHolder, HistoricalHolderTableColumns>
      data={data}
      columns={columns}
      primaryKey={primaryKey}
      pageSize={50}
      isLoading={isLoading}
      additionalButtons={additionalButtons}
      maxHeight={'450px'}
    />
  );
}

function areEqual(_prevProps: any, _nextProps: any) {
  return true; // Since this component doesn't have any props, it should only re-render when its hook data changes
}

export default memo(HistoricalHoldersIgniteTable, areEqual);
