// hooks
import useCurrentHoldersTable from '../../hooks/useCurrentHoldersTable';

// types
import { CurrentHolder } from '../../types';

// components
import Table from '@/components/shared/Table';

export default function CurrentHoldersTable() {
  const {
    columns,
    data,
    initialSort,
    initialSortDirection,
    initialLimit,
    isLoading,
  } = useCurrentHoldersTable();

  return (
    <Table
      data={data}
      isLoading={isLoading}
      columns={columns}
      initialSort={initialSort as keyof CurrentHolder}
      initialSortDirection={initialSortDirection}
      initialLimit={initialLimit}
    />
  );
}
