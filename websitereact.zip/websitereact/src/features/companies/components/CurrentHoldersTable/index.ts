export { default } from './CurrentHoldersTable';
