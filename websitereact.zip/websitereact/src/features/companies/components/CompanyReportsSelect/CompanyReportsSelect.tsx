// hooks
import useCompanyReportsStore from '../../store/companyReports.store';

// lib
import { REPORT_TYPES } from '@/lib/constants';

// components
import { Select } from '@/components/shared';

export default function CompanyReportsSelect() {
  const { reportType, setReportType } = useCompanyReportsStore();

  return (
    <Select
      options={REPORT_TYPES}
      value={reportType}
      onChange={setReportType}
    />
  );
}
