// hooks
import useCompanyStore from '../../store/company.store';
import { useState, useEffect } from 'react';

// components
import {
  Button,
  Card,
  Select,
  FlexContainer,
  Tooltip,
} from '@/components/shared';
import HoldersShowFilter from '../HoldersShowFilter';

// styles
import './CurrentHoldersFilters.scss';

export default function CurrentHoldersFilters() {
  const {
    isLoadingStakeFilingTypes,
    stakeFilingTypes,
    selectedStakeFilingTypes,
    setSelectedStakeFilingTypes,
    selectAllStakeFilingTypes,
    forceRefresh,
  } = useCompanyStore();

  const [innerSelectedFilingTypes, setInnerSelectedFilingTypes] = useState<
    string[]
  >([]);

  useEffect(() => {
    setInnerSelectedFilingTypes(selectedStakeFilingTypes);
  }, [selectedStakeFilingTypes]);

  return (
    <Card
      headerTitle="Current Holders"
      containerClassName="CurrentHoldersFilters"
      contentClassName="CurrentHoldersFilters__content"
      variants={['danger']}
    >
      <div className="CurrentHoldersFilters__content__left">
        <HoldersShowFilter name="current-holders-show-filter" />
      </div>

      <div className="CurrentHoldersFilters__content__right">
        <Select
          label="Report Types"
          isDisabled={isLoadingStakeFilingTypes}
          options={stakeFilingTypes?.map?.((type) => ({
            value: type.code,
            label: type.name,
          }))}
          value={innerSelectedFilingTypes}
          onChange={(value: string | number | (string | number)[]) =>
            setInnerSelectedFilingTypes(value as string[])
          }
          onClose={() => setSelectedStakeFilingTypes(innerSelectedFilingTypes)}
          isMulti
        />

        <FlexContainer flexDirection="column">
          {/* adding this empty label so that they're equal heights */}
          <label style={{ opacity: 0 }}>Select All</label>
          <Tooltip title="Select All Report Types" placement="top">
            <Button
              isDisabled={isLoadingStakeFilingTypes}
              onClick={selectAllStakeFilingTypes}
            >
              Select All
            </Button>
          </Tooltip>
        </FlexContainer>

        <FlexContainer flexDirection="column">
          {/* adding this empty label so that they're equal heights */}
          <label style={{ opacity: 0 }}>Refresh</label>
          <Tooltip title="Refresh/Re-fetch data" placement="top">
            <Button onClick={forceRefresh}>Refresh</Button>
          </Tooltip>
        </FlexContainer>
      </div>
    </Card>
  );
}
