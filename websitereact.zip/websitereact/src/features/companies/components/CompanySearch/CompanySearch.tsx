import { memo } from 'react';

// hooks
import useCompanySearch from '../../hooks/useCompanySearch';

// components
import AutocompleteInput from '@/components/shared/AutocompleteInput';

// types
import Company from '../../types/Company';
import CompanyInfo from '../../types/CompanyInfo';

interface CompanySearchProps {
  onCompanySelected?: (data: {
    company: Company;
    companyInfo: CompanyInfo | null;
  }) => void;
  defaultCompany?: Company | null;
}

function CompanySearch({
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  onCompanySelected = ({ company, companyInfo }) => {},
  defaultCompany,
}: CompanySearchProps) {
  const {
    searchTerm,
    handleInputChange,
    companies,
    isLoading,
    handleSelect,
    isLoadingInfo,
  } = useCompanySearch(onCompanySelected, defaultCompany);

  return (
    <AutocompleteInput
      placeholder="Search company..."
      value={searchTerm ? searchTerm || defaultCompany?.companyName : ''}
      onChange={handleInputChange}
      options={companies}
      isLoading={isLoading}
      isDisabled={isLoadingInfo}
      onOptionClick={handleSelect}
      renderOptionLabel={(company: Company) =>
        `${company.ticker}: ${company.companyName}`
      }
      getOptionKey={(company: Company, idx: number) =>
        company.companyId + `-${idx}`
      }
    />
  );
}

export default memo(CompanySearch);
