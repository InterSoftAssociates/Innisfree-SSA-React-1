// hooks
import { memo } from 'react';
import useHistoricalHoldersFilters from '../../hooks/useHistoricalHoldersFilters';

// components
import {
  Button,
  Card,
  Select,
  FlexContainer,
  Tooltip,
} from '@/components/shared';

// components
import HoldersShowFilter from '../HoldersShowFilter';

// styles
import './HistoricalHoldersFilters.scss';

function HistoricalHoldersFilters() {
  const {
    historicalPeriods,
    stakeFilingTypes,
    handleHistoricalPeriodsChange,
    handleStakeFilingTypesChange,
    handleHistoricalPeriodsClose,
    handleStakeFilingTypesClose,
    reportDateOptions,
    stakeFilingTypeOptions,
    isLoadingReportDates,
    isLoadingStakeFilingTypes,
    selectAllHistoricalPeriods,
    selectAllStakeFilingTypes,
    forceRefresh,
  } = useHistoricalHoldersFilters();

  return (
    <Card
      headerTitle="Historical Holders"
      containerClassName="HistoricalHoldersFilters"
      contentClassName="HistoricalHoldersFilters__content"
    >
      <div className="HistoricalHoldersFilters__content__left">
        <HoldersShowFilter name="historical-holders-show-filter" />
      </div>

      <div className="HistoricalHoldersFilters__content__right">
        <Select
          label="Historical Periods"
          isDisabled={isLoadingReportDates}
          options={reportDateOptions}
          value={historicalPeriods}
          onChange={handleHistoricalPeriodsChange}
          onClose={handleHistoricalPeriodsClose}
          isMulti
        />

        <FlexContainer flexDirection="column">
          <label style={{ opacity: 0 }}>Select All</label>
          <Tooltip title="Select All Historical Periods">
            <Button
              isDisabled={isLoadingReportDates}
              onClick={selectAllHistoricalPeriods}
            >
              Select All
            </Button>
          </Tooltip>
        </FlexContainer>

        <Select
          label="Report Types"
          isDisabled={isLoadingStakeFilingTypes}
          options={stakeFilingTypeOptions}
          value={stakeFilingTypes}
          onChange={handleStakeFilingTypesChange}
          onClose={handleStakeFilingTypesClose}
          isMulti
        />

        <FlexContainer flexDirection="column">
          <label style={{ opacity: 0 }}>Select All</label>
          <Tooltip title="Select All Report Types">
            <Button
              isDisabled={isLoadingStakeFilingTypes}
              onClick={selectAllStakeFilingTypes}
            >
              Select All
            </Button>
          </Tooltip>
        </FlexContainer>

        <FlexContainer flexDirection="column">
          <label style={{ opacity: 0 }}>Refresh</label>
          <Tooltip title="Refresh/Re-fetch Data">
            <Button onClick={forceRefresh}>Refresh</Button>
          </Tooltip>
        </FlexContainer>
      </div>
    </Card>
  );
}

export default memo(HistoricalHoldersFilters);
