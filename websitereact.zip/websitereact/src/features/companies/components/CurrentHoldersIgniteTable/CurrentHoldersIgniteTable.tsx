import useCurrentHoldersTableIgnite from '../../hooks/useCurrentHoldersTableIgnite';
import IgniteTable from '@/components/shared/IgniteTable';
import { CurrentHolder, CurrentHolderTableColumns } from '../../types';

export default function CurrentHoldersIgniteTable() {
  const { columns, data, isLoading, primaryKey } =
    useCurrentHoldersTableIgnite();

  const rowClasses = {
    'IgniteTable__row--positive': ({ _data: row }: { _data: CurrentHolder }) =>
      row.change !== null && row.change !== undefined && row.change > 0,
    'IgniteTable__row--negative': ({ _data: row }: { _data: CurrentHolder }) =>
      row.change !== null && row.change !== undefined && row.change < 0,
  };

  return (
    <IgniteTable<CurrentHolder, CurrentHolderTableColumns>
      data={data}
      columns={columns}
      primaryKey={primaryKey}
      pageSize={50}
      isLoading={isLoading}
      rowClasses={rowClasses}
      maxHeight={'450px'}
    />
  );
}
