// components
import { Modal } from '@/components/shared';
import HolderRollupsTable from '../HolderRollupsTable';

// types
import { Institution } from '@/features/institutions/types';

// styles
import './HolderRollupsModal.scss';

export default function HolderRollupsModal({
  row,
  isOpen,
  onClose,
}: {
  row: Institution;
  isOpen: boolean;
  onClose: () => void;
}) {
  return (
    <div className="HolderRollupsModal">
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title="Rollups"
        isCloseButtonVisible
        styles={{
          content: {
            maxWidth: '80%',
          },
        }}
      >
        {row?.instInternalId && isOpen && (
          <HolderRollupsTable isOpen={isOpen} entityId={row.instInternalId} />
        )}
      </Modal>
    </div>
  );
}
