// hooks
import { useEffect, useState } from 'react';
import useCompanyStore from '../../store/company.store';

// components
import AutocompleteInput from '@/components/shared/AutocompleteInput';

// types
import InvestmentStyle from '../../types/InvestmentStyle';

interface InvestmentStyleSearchProps {
  onInvestmentStyleSelected?: (institution: InvestmentStyle | null) => void;
  defaultInvestmentStyle?: InvestmentStyle | null;
}

export default function InstitutionSearch({
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  onInvestmentStyleSelected = () => {},
  defaultInvestmentStyle,
}: InvestmentStyleSearchProps) {
  const { investmentStyles } = useCompanyStore();
  const [innerInvestmentStyle, setInnerInvestmentStyle] = useState<string>('');

  useEffect(() => {
    if (defaultInvestmentStyle?.name) {
      setInnerInvestmentStyle(defaultInvestmentStyle?.name);
    }
  }, [defaultInvestmentStyle]);

  return (
    <AutocompleteInput
      placeholder="Search investment style..."
      options={investmentStyles
        .filter((x, i, a) => a.findIndex((y) => y.name === x.name) === i)
        .filter((investmentStyle) =>
          !innerInvestmentStyle
            ? true
            : investmentStyle.name
                .toLowerCase()
                .includes(innerInvestmentStyle.toLowerCase()),
        )
        .slice(0, 5)}
      value={innerInvestmentStyle || ''}
      onChange={(e) => setInnerInvestmentStyle(e.target.value)}
      onOptionClick={onInvestmentStyleSelected}
      renderOptionLabel={(investmentStyle: InvestmentStyle) =>
        investmentStyle.name
      }
      getOptionKey={(investmentStyle: InvestmentStyle, index: number) =>
        investmentStyle.code + `-${index}`
      }
      isLoading={false}
    />
  );
}
