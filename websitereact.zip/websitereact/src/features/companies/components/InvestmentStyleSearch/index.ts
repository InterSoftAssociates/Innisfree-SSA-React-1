export { default } from './InvestmentStyleSearch';
