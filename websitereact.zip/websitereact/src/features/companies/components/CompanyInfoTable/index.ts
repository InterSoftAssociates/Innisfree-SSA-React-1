export { default } from './CompanyInfoTable';
