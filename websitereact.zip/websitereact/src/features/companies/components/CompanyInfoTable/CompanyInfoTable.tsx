// components
import TableSmall from '@/components/shared/TableSmall';

// types
import { CompanyInfo } from '../../types';

// styles
import './CompanyInfoTable.scss';
import { memo } from 'react';

interface CompanyInfoTableProps {
  companyInfo: CompanyInfo | null;
}

const formatNumber = (num: number | null | undefined) =>
  num !== null && num !== undefined ? num?.toLocaleString?.() : '';

function CompanyInfoTable({ companyInfo }: CompanyInfoTableProps) {
  const companyInfoTableData = [
    {
      Industry: companyInfo?.industry,
      'Institutional Holders': formatNumber(companyInfo?.numInst),
      'Market Cap (USD, mm)': formatNumber(companyInfo?.marketCap),
      'Price/Sales (ttm)': '', // Not provided in CompanyInfo
      'Return On Assets (ttm)': '', // Not provided in CompanyInfo
    },
    {
      Sector: companyInfo?.sector,
      'Mutual Fund Holders': formatNumber(companyInfo?.numFunds),
      'Shares Held by Inst (mmd)': '', // Not provided in CompanyInfo
      'Price/Book (ttm)': '', // Not provided in CompanyInfo
      'Return On Equity (ttm)': '', // Not provided in CompanyInfo
    },
    {
      Sic: companyInfo?.sic,
      '% of Institutional Holders': '', // Can be calculated if needed
      'Enterprise Value/Sales': '', // Not provided in CompanyInfo
      'Enterprise Value/EBITDA (ttm)': '', // Not provided in CompanyInfo
      'Debt/Capital': '', // Not provided in CompanyInfo
    },
    {
      'Security Type': 'Share',
      'Shares Outstanding (mm)': formatNumber(companyInfo?.sharesOutstanding),
      'Trailing P/E (tm)': '', // Not provided in CompanyInfo
      'Dividend Yield (%)': '', // Not provided in CompanyInfo
      'Net Activity': '', // Can be calculated if needed
    },
    {
      'Buys (USD,mm)': formatNumber(companyInfo?.buys),
      'Buy Ins (USD, mm)': formatNumber(companyInfo?.buysIn),
      'Sells (USD,mm)': formatNumber(companyInfo?.sells),
      'Sells Outs (USD, mm)': '', // Not provided in CompanyInfo
      '': '',
    },
    {
      '# of Buys': formatNumber(companyInfo?.buyers),
      '# of Buys Ins': '', // Not provided in CompanyInfo
      '# of Sells': formatNumber(companyInfo?.sellers),
      '# of Sell Outs': '', // Not provided in CompanyInfo
      '': '',
    },
  ];

  return (
    <div className="CompanyInfoTable">
      <TableSmall
        data={companyInfoTableData}
        className="CompanyInfoTable__table"
      />
    </div>
  );
}

export default memo(CompanyInfoTable);
