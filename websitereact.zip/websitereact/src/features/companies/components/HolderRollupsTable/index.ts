export { default } from './HolderRollupsTable';
