import useHolderFundsTable from '../../hooks/useHolderFundsTable';
import Table from '@/components/shared/Table';
import { Fund } from '../../types/Fund';

export default function HolderRollupsTable({ isOpen = false, entityId = 0 }) {
  const {
    columns,
    data,
    initialSort,
    initialSortDirection,
    initialLimit,
    isLoading,
  } = useHolderFundsTable({ isOpen, entityId });

  return (
    <Table
      data={data}
      isLoading={isLoading}
      // @ts-expect-error i dont know why it's complaining about this
      columns={columns.filter(({ key }) => key !== 'fundName')}
      initialSort={initialSort as keyof Fund | undefined}
      initialSortDirection={initialSortDirection}
      initialLimit={initialLimit}
    />
  );
}
