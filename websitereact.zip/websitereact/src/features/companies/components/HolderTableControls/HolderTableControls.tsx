import { useMemo, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faF,
  faPencil,
  faProjectDiagram,
} from '@fortawesome/free-solid-svg-icons';
import { Tooltip } from '@/components/shared';
import HolderOverrideModal from '../HolderOverrideModal';
import HolderFundsModal from '../HolderFundsModal';
import HolderRollupsModal from '../HolderRollupsModal';
import { CurrentHolder, HistoricalHolder } from '../../types';
import { Institution } from '@/features/institutions/types';
import './HolderTableControls.scss';

export default function HolderTableControls({
  row,
}: {
  row: HistoricalHolder | CurrentHolder;
}) {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isFundsModalOpen, setIsFundsModalOpen] = useState(false);
  const [isRollupsModalOpen, setIsRollupsModalOpen] = useState(false);

  const hasFund = useMemo(() => {
    return (
      (row as HistoricalHolder).has_fund === 'hf' ||
      (row as CurrentHolder).hasFund === 'hf'
    );
  }, [row]);

  const hasRollup = useMemo(() => {
    return (
      (row as HistoricalHolder).has_rollup === 'ru' ||
      (row as CurrentHolder).hasRollup === 'ru'
    );
  }, [row]);

  return (
    <>
      <div className="HolderTableControls">
        <Tooltip title="Override" placement="right">
          <FontAwesomeIcon
            icon={faPencil}
            className="HolderTableControls__icon HolderTableControls__icon--edit"
            onClick={() => setIsEditModalOpen(true)}
          />
        </Tooltip>

        {hasFund && (
          <Tooltip title="Funds" placement="right">
            <FontAwesomeIcon
              icon={faF}
              onClick={() => setIsFundsModalOpen(true)}
              className="HolderTableControls__icon HolderTableControls__icon--funds"
            />
          </Tooltip>
        )}

        {hasRollup && (
          <Tooltip title="Rollups" placement="right">
            <FontAwesomeIcon
              icon={faProjectDiagram}
              className="HolderTableControls__icon HolderTableControls__icon--rollups"
              onClick={() => setIsRollupsModalOpen(true)}
            />
          </Tooltip>
        )}
      </div>

      <HolderOverrideModal
        row={row as unknown as Institution}
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
      />

      {hasFund && (
        <HolderFundsModal
          row={row as unknown as Institution}
          isOpen={isFundsModalOpen}
          onClose={() => setIsFundsModalOpen(false)}
        />
      )}

      {hasRollup && (
        <HolderRollupsModal
          row={row as unknown as Institution}
          isOpen={isRollupsModalOpen}
          onClose={() => setIsRollupsModalOpen(false)}
        />
      )}
    </>
  );
}
