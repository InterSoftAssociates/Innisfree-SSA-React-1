import { StoryFn, Meta } from '@storybook/react';
import HolderTableControls from './HolderTableControls';
import { CurrentHolder, HistoricalHolder } from '../../types';

export default {
  title: 'features/companies/components/HolderTableControls',
  component: HolderTableControls,
  tags: ['autodocs'],
  argTypes: {
    row: {
      control: 'object',
    },
  },
} as Meta;

const Template: StoryFn<{ row: CurrentHolder | HistoricalHolder }> = (args) => (
  <HolderTableControls {...args} />
);

export const Default = Template.bind({});
Default.args = {
  row: {
    hasFund: 'no',
    hasRollup: 'no',
  } as CurrentHolder,
};

export const WithFund = Template.bind({});
WithFund.args = {
  row: {
    hasFund: 'hf',
    hasRollup: 'no',
  } as CurrentHolder,
};

export const WithRollup = Template.bind({});
WithRollup.args = {
  row: {
    hasFund: 'no',
    hasRollup: 'ru',
  } as CurrentHolder,
};

export const WithFundAndRollup = Template.bind({});
WithFundAndRollup.args = {
  row: {
    hasFund: 'hf',
    hasRollup: 'ru',
  } as CurrentHolder,
};

export const HistoricalHolderTemplate = Template.bind({});
HistoricalHolderTemplate.args = {
  row: {
    has_fund: 'hf',
    has_rollup: 'ru',
  } as HistoricalHolder,
};
