// components
import { Modal } from '@/components/shared';
import HolderFundsTable from '../HolderFundsTable';

// types
import { Institution } from '@/features/institutions/types';

// styles
import './HolderFundsModal.scss';

export default function HolderOverrideModal({
  row,
  isOpen,
  onClose,
}: {
  row: Institution;
  isOpen: boolean;
  onClose: () => void;
}) {
  return (
    <div className="HolderFundsModal">
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title="Funds"
        isCloseButtonVisible
        styles={{
          content: {
            maxWidth: '80%',
          },
        }}
      >
        {row?.instInternalId && isOpen && (
          <HolderFundsTable isOpen={isOpen} entityId={row.instInternalId} />
        )}
      </Modal>
    </div>
  );
}
