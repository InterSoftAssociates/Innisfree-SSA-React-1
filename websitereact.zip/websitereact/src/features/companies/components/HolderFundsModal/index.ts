export { default } from './HolderFundsModal';
