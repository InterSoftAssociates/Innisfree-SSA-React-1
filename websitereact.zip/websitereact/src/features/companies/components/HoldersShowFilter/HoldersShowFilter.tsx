// hooks
import useCompanyStore from '../../store/company.store';

// components
import RadioGroup from '@/components/shared/RadioGroup';

export default function HoldersShowFilter({ name }: { name?: string }) {
  const { showFilter, setShowFilter } = useCompanyStore();

  return (
    <RadioGroup
      name={name || 'holders-show-filter'}
      label="Show:"
      options={[
        {
          label: 'Institutions',
          value: 'institutions',
          id: 'institutions',
        },
        { label: 'Funds', value: 'funds', id: 'funds' },
      ]}
      value={showFilter}
      variant="default"
      onChange={(value: 'institutions' | 'funds') => setShowFilter(value)}
    />
  );
}
