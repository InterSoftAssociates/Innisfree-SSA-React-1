interface CompanyInfo {
  marketCap?: number;
  numInst: number;
  numFunds: number;
  numBuyers?: number;
  numSellers?: number;
  buys?: number;
  sells?: number;
  companyId: number;
  companyName: string;
  ticker: string;
  facsetId: number;
  cusip?: number | undefined;
  cikId?: number | undefined;
  crdId?: number | undefined;
  lieId?: number | undefined;
  bloombergId?: number | undefined;
  industry: string;
  sector: string;
  sic: string;
  sharesOutstanding?: number | undefined;
  clientInd: boolean;
  sellers?: number;
  buyers?: number | undefined;
  buysIn?: number | undefined;
}

export default CompanyInfo;
