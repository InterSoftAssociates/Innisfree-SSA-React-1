interface InvestmentStyle {
  active: any;
  code: string | null;
  referenceId: number;
  type: string;
  name: string;
}

export default InvestmentStyle;
