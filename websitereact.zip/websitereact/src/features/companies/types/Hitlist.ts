export interface GetHitlistPayload {
  byInst: boolean;
  companyId: number;
  filingTypes: string[];
  reportDates: string[];
}

export interface GetHitlistResponse {
  fileContentResult: any;
  fileData: any;
  fileName: string;
  messageResponse: {
    success: boolean;
    message: string;
  };
}
