import Company from './Company';

export type GetCompanyReportPayload = Array<Company['companyId']>; // Array of company IDs

export interface GetCompanyReportResponse {
  fileContentResult?: any; // possibly null
  fileData: string; // base64 encoded string
  fileName: string;
  messageResponse: {
    success: boolean;
    message: string;
  };
}
