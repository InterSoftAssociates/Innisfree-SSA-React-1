export interface Fund {
  fundName: string;
  institutionName: string;
  most_recent_report_date: string;
  most_recent_position: number;
  factsetId: string;
  internalId: number;
  investmentStyle: string;
  rn: number;
  institution_id: number;
  multi_manager_fund: string;
  inst_factset_id: string;
  instInternalId: number;
  rollup_inst_internal_id: number;
  rollup_inst_factset_id: string;
  morningstart_owner_id: string | null;
  overall_change: number;
  has_fund: 'hf' | 'nf';
  has_rollup: string;
  custodian_name: string | null;
  custodian_entity_id: number;
  fundId: number;
  [key: string]: number | string | null;
}

export interface FundTableColumns {
  controls: string;
  fundName: string;
  institutionName: string;
  investmentStyle: string;
  most_recent_report_date: string;
  most_recent_position: number;
  overall_change: number;
  [key: string]: string | number; // For historical period columns (1, 2, 3, 4, etc.)
}

import { TableProps } from '@/components/shared/Table/Table';

export type FundTableProps = TableProps<FundTableColumns>;
