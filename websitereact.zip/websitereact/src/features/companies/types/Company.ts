interface Company {
  bloombergId?: number;
  cikId?: number;
  clientInd: boolean;
  companyId: number;
  companyName: string;
  crdId?: number;
  cusip?: number;
  facsetId: number;
  industry: string;
  lieId?: number;
  sector: string;
  sharesOutstanding: number;
  sic: string;
  ticker: string;
}

export default Company;
