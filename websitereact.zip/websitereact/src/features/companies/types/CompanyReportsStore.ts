import Company from './Company';

export interface CompanyReportsStoreState {
  selectedCompanies: Company[];
  reportType: string;
  isRunReportLoading: boolean;
}

export interface CompanyReportsStoreReducer {
  addCompany: (company: Company) => Company[];
  removeCompany: (company: Company) => Company[];
  setReportType: (reportType: string) => void;
  runReport: () => void;
}

export interface CompanyReportsStore
  extends CompanyReportsStoreState,
    CompanyReportsStoreReducer {}
