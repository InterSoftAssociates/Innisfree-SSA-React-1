import Company from './Company';

export interface GetHistoricalHoldersPayload {
  companyId: number;
  clientInd: boolean;
  byInst: boolean; // showFilter on 'institutions' | 'funds'
  reportDates: string[];
  filingTypes: string[];
  entityId?: number;
}

export interface HistoricalHolder {
  institutionName: string;
  most_recent_report_date: string;
  most_recent_position: number;
  factsetId: string;
  internalId: number;
  investmentStyle: string;
  institution_id: number;
  institution_ids: string | null;
  multi_manager_fund: string;
  advisory_firm: string;
  location: string | null;
  country: string | null;
  rollups: string | null;
  period_change: number;
  aum: number;
  has_fund: 'hf' | 'nf';
  instInternalId: number;
  '1': any;
  '2': any;
  '3': any;
  '4': any;
  has_rollup: 'ru' | 'nr';
}

export interface HistoricalHolderTableColumns extends HistoricalHolder {
  controls: string;
}

export interface GetHistoricalHoldersResponse {
  dataString: string; // JSON stringified HistoricalHolder[]
  companyName: Company['companyName'];
  success: boolean;
}
