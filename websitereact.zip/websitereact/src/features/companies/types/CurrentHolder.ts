export interface CurrentHolder {
  institutionName: string;
  fundName: string;
  position: number;
  factsetId: string;
  internalId: number;
  investmentStyle: string | null;
  value: number;
  change: number;
  perSharesOutstanding: number | null;
  perPort: number | null;
  positionSource: string;
  positionDate: string;
  aum: number;
  multiManagerFund: string;
  hasFund: string;
  instInternalId: number;
  instFactsetId: string | null;
  rollupInstInteranlId: string | null;
  rollupInstFactsetId: string | null;
  custodianName: string | null;
  custodianInternalId: string | null;
  hasRollup: string;
  fundId: number;
}

export interface GetCurrentHoldersResponse {
  currHolders: CurrentHolder[];
  companyName: string;
  ticker: string | null;
  success: boolean;
  message: string | null;
}

export interface GetCurrentHoldersPayload {
  companyId: number;
  clientInd: boolean;
  byInst: boolean;
  filingTypes: string[];
}

export interface CurrentHolderTableColumns extends CurrentHolder {
  controls: string;
}
