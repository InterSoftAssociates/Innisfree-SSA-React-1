interface StakeFilingType {
  active: boolean;
  code: string;
  name: string;
  referenceId: number;
  type: null;
}

export default StakeFilingType;
