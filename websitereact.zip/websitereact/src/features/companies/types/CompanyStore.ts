import Company from './Company';
import CompanyInfo from './CompanyInfo';
import StakeFilingType from './StakeFilingType';
import InvestmentStyle from './InvestmentStyle';
import { HistoricalHolder } from './HistoricalHolder';
import { CurrentHolder } from './CurrentHolder';

export interface CompanyStoreState {
  isLoadingInit: boolean;
  isLoadingReportDates: boolean;
  isLoadingStakeFilingTypes: boolean;
  selectedCompany: Company | null;
  selectedCompanyInfo: CompanyInfo | null;
  showFilter: 'institutions' | 'funds';
  reportDates: string[];
  stakeFilingTypes: StakeFilingType[];
  selectedHistoricalPeriods: string[];
  selectedStakeFilingTypes: string[];
  isLoadingHistoricalHolders: boolean;
  historicalHolders: HistoricalHolder[];
  historicalHoldersCompanyName: string;
  lastDateTimeUpdated: number;
  investmentStyles: InvestmentStyle[];
  isLoadingCurrentHolders: boolean;
  currentHolders: CurrentHolder[];
  currentHoldersCompanyName: string;
  currentHoldersCacheKey: string;
  historicalHoldersCacheKey: string;
}

export interface CompanyStoreReducer extends CompanyStoreState {
  init: () => void;
  setSelectedCompany: (
    data: {
      company: Company | null;
      companyInfo?: CompanyInfo | null;
    },
    force?: boolean,
  ) => void;
  setShowFilter: (filter: CompanyStoreState['showFilter']) => void;
  getFilterData: () => Promise<void>;
  setSelectedCompanyFromHomeScreen: (company: Company) => void;
  setSelectedHistoricalPeriods: (
    dates: CompanyStoreState['selectedHistoricalPeriods'],
  ) => void;
  setSelectedStakeFilingTypes: (
    types: CompanyStoreState['selectedStakeFilingTypes'],
  ) => void;
  selectAllHistoricalPeriods: () => void;
  selectAllStakeFilingTypes: () => void;
  getHistoricalHolders: (force?: boolean) => Promise<void>;
  getCurrentHolders: (force?: boolean) => Promise<void>;
  onFilterChange: () => void;
  forceRefresh: () => void;
  handleNavigation: (newRoute: string) => void;
  getHitlist: () => void;
  reset: () => void;
}

export interface CompanyStore extends CompanyStoreState, CompanyStoreReducer {}
