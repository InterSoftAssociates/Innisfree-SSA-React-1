// components
import { useMemo } from 'react';
import {
  HistoricalHoldersFilters,
  HistoricalHoldersTable,
  HistoricalHoldersIgniteTable,
} from '../../components';

// styles
import './HistoricalHoldersScreen.scss';

export default function HistoricalHoldersScreen() {
  const query = useMemo(() => {
    return new URLSearchParams(window.location.search);
  }, []);

  return (
    <div className="HistoricalHoldersScreen">
      <HistoricalHoldersFilters />

      {query.get('ignite') === 'true' ? (
        <HistoricalHoldersIgniteTable />
      ) : (
        <HistoricalHoldersTable />
      )}
    </div>
  );
}
