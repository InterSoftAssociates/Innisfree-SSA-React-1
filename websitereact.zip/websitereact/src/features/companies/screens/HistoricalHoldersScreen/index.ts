export { default } from './HistoricalHoldersScreen';
