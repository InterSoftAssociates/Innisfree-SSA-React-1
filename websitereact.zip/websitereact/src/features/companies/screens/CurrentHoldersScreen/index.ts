export { default } from './CurrentHoldersScreen';
