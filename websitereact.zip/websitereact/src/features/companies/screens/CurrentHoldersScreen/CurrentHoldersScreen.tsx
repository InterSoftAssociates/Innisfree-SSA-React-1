import { useMemo } from 'react';

// components
import {
  CurrentHoldersFilters,
  CurrentHoldersTable,
  CurrentHoldersIgniteTable,
} from '../../components';

// styles
import './CurrentHoldersScreen.scss';

export default function CurrentHoldersScreen() {
  const query = useMemo(() => {
    return new URLSearchParams(window.location.search);
  }, []);

  return (
    <div className="CurrentHoldersScreen">
      <CurrentHoldersFilters />

      {query.get('ignite') ? (
        <CurrentHoldersIgniteTable />
      ) : (
        <CurrentHoldersTable />
      )}
    </div>
  );
}
