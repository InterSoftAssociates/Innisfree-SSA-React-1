// hooks
import useCompanyReportsStore from '../../store/companyReports.store';

// components
import { Card } from '@/components/shared';
import { CompanySearch, CompanyReportsTable } from '../../components';

// styles
import './CompanyReportsScreen.scss';

export default function CompanyReportsScreen() {
  const { addCompany } = useCompanyReportsStore();

  return (
    <main className="CompanyReportsScreen">
      <Card
        containerClassName="CompanyReportsScreen__search-card"
        contentClassName="CompanyReportsScreen__search-card__content"
      >
        <CompanySearch
          onCompanySelected={({ company }) => addCompany(company)}
        />
      </Card>

      <CompanyReportsTable />
    </main>
  );
}
