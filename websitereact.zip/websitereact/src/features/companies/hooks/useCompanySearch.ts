import useAPIAutocompleteSearch from '@/hooks/useAPIAutocompleteSearch';
import { Company, CompanyInfo } from '../types';
import {
  postCompaniesQuickSearch,
  postGetCompanyInfo,
} from '../services/companies.service';

interface UseCompanySearchReturn {
  searchTerm: string;
  companies: Company[];
  isLoading: boolean;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleSelect: (company: Company) => Promise<CompanyInfo | undefined>;
  isLoadingInfo: boolean;
}

export default function useCompanySearch(
  onCompanySelected: (args: {
    company: Company;
    companyInfo: CompanyInfo | null;
  }) => void,
  defaultCompany?: Company | null,
): UseCompanySearchReturn {
  const genericSearch = useAPIAutocompleteSearch<Company, CompanyInfo>({
    searchFunction: (term) =>
      postCompaniesQuickSearch(term) as Promise<Company[]>,
    getInfoFunction: (company) => postGetCompanyInfo(company.companyId),
    onItemSelected: (company, companyInfo) =>
      onCompanySelected({ company, companyInfo }),
    defaultItem: defaultCompany,
    getSearchTerm: (company) =>
      company?.companyName ? `${company.ticker}: ${company.companyName}` : '',
    searchKey: 'COMPANIES_QUICK_SEARCH',
  });

  return {
    ...genericSearch,
    companies: genericSearch.items,
  };
}
