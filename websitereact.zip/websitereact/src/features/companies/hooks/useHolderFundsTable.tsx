import { useMemo } from 'react';
import useSWR from 'swr';
import useCompanyStore from '../store/company.store';

// types
import { Fund, FundTableColumns, GetHistoricalHoldersPayload } from '../types';
import { ColumnDef, TableProps } from '@/components/shared/Table/Table';

// lib
import { formatDate } from '@/lib/formatting';

// services
import { postGetHistoricalHolders } from '../services/companies.service';

export default function useHolderFundsTable({
  entityId,
}: {
  entityId: number;
  isOpen: boolean;
}) {
  const {
    selectedCompany,
    selectedHistoricalPeriods,
    selectedStakeFilingTypes,
  } = useCompanyStore();

  const { data, isLoading } = useSWR(
    `GET_HISTORICAL_HOLDERS_FUNDS-${entityId}` as const,
    async () => {
      if (!selectedCompany) return null;

      const payload: GetHistoricalHoldersPayload = {
        entityId,
        reportDates: selectedHistoricalPeriods,
        filingTypes: selectedStakeFilingTypes,
        // byInst: showFilter === 'institutions',
        byInst: false,
        companyId: selectedCompany.companyId,
        clientInd: selectedCompany.clientInd,
      };

      return await postGetHistoricalHolders(payload);
    },
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    },
  );

  const columns: ColumnDef<FundTableColumns>[] = useMemo(
    () => {
      const baseColumns = [
        // {
        //   key: 'controls' as keyof FundTableColumns,
        //   header: '',
        //   filter: 'none' as const,
        //   render: () => <></>,
        //   // render: (_v: '', row: Fund) => <FundTableControls row={row} />,
        // },
        {
          key: 'fundName' as keyof FundTableColumns,
          header: 'Fund Name',
          filter: 'text' as const,
        },
        {
          key: 'institutionName' as keyof FundTableColumns,
          header: 'Institution Name',
          filter: 'text' as const,
        },
        {
          key: 'investmentStyle' as keyof FundTableColumns,
          header: 'Investment Style',
          filter: 'text' as const,
        },
        {
          key: 'most_recent_report_date' as keyof FundTableColumns,
          header: 'Most Recent Date',
          filter: 'date' as const,
          render: (value: string) => formatDate(value),
        },
        {
          key: 'most_recent_position' as keyof FundTableColumns,
          header: 'Most Recent Position',
          filter: 'number' as const,
          render: (value: number) => (value ? value.toLocaleString() : ''),
        },
        {
          key: 'overall_change' as keyof FundTableColumns,
          header: 'Overall Change',
          filter: 'number' as const,
          render: (value: number) => (value ? value.toLocaleString() : ''),
        },
      ];

      // const historicalColumns = selectedHistoricalPeriods.map(
      //   (period, index) => ({
      //     key: (index + 1).toString() as keyof FundTableColumns,
      //     header: formatDate(period),
      //     filter: 'number' as const,
      //     render: (value: number) => value?.toLocaleString() ?? '-',
      //   }),
      // );

      return [...baseColumns /* ...historicalColumns */];
    },
    [
      /*selectedHistoricalPeriods */
    ],
  );

  const initialSort = useMemo(() => 'most_recent_position' as keyof Fund, []);
  const initialSortDirection: 'asc' | 'desc' = useMemo(() => 'desc', []);
  const initialLimit = useMemo(() => 50, []);
  const memoizedData = useMemo(
    () => (data?.dataString ? JSON.parse(data?.dataString) : []),
    [data?.dataString],
  );

  return {
    columns,
    initialSort,
    initialSortDirection,
    initialLimit,
    isLoading,
    data: memoizedData,
  };
}
