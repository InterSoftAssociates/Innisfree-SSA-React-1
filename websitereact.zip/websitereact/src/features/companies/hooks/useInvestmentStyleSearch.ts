import useAPIAutocompleteSearch from '@/hooks/useAPIAutocompleteSearch';
import { getInstitutions } from '../../companies/services/companies.service';
import { InvestmentStyle } from '../types';

interface UseInvestmentStyleSearchReturn {
  searchTerm: string;
  institutions: InvestmentStyle[];
  isLoading: boolean;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleSelect: (
    institution: InvestmentStyle,
  ) => Promise<InvestmentStyle | undefined>;
  isLoadingInfo: boolean;
}

export default function useInvestmentStyleSearch(
  onInstitutionSelected: (institution: Institution | null) => void,
  defaultInstitution?: InvestmentStyle | null,
): UseInvestmentStyleSearchReturn {
  const genericSearch = useAPIAutocompleteSearch<
    InvestmentStyle,
    InvestmentStyle
  >({
    searchFunction: (term) => getInstitutions(term),
    getInfoFunction: async (institution) => institution, // Assuming no additional info needed
    onItemSelected: (institution) => onInstitutionSelected(institution),
    defaultItem: defaultInstitution,
    getSearchTerm: (institution) => institution?.institutionName,
    searchKey: 'INSTITUTION_SEARCH',
  });

  return {
    ...genericSearch,
    institutions: genericSearch.items,
  };
}
