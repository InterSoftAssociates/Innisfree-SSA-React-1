// hooks
import { useMemo } from 'react';
import useCompanyStore from '../store/company.store';

// lib
import {
  formatDate,
  formatNumber,
  formatCurrency,
  truncate,
} from '@/lib/formatting';

// components
import HolderTableControls from '../components/HolderTableControls';

// types
import { IgrCellTemplateContext } from '@infragistics/igniteui-react-grids';
import { CurrentHolder, CurrentHolderTableColumns } from '../types';

const TRUNCATE_LENGTH = 23;

export default function useCurrentHoldersTableIgnite() {
  const { currentHolders, isLoadingCurrentHolders } = useCompanyStore();

  const columns = useMemo(
    () => [
      {
        field: 'controls' as keyof CurrentHolderTableColumns,
        header: '',
        dataType: 'string',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) => (
          <HolderTableControls
            row={props.dataContext.cell.row.data as CurrentHolder}
          />
        ),
        isSortable: false,
      },
      {
        field: 'institutionName' as keyof CurrentHolderTableColumns,
        header: 'Institution',
        dataType: 'string',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
          truncate(props.dataContext.cell.value, TRUNCATE_LENGTH),
        isSortable: true,
      },
      {
        field: 'investmentStyle' as keyof CurrentHolderTableColumns,
        header: 'Investment Style',
        dataType: 'string',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
          truncate(props.dataContext.cell.value || '', TRUNCATE_LENGTH),
        isSortable: true,
      },
      {
        field: 'value' as keyof CurrentHolderTableColumns,
        header: 'Value (USD,MM)',
        dataType: 'number',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
          formatCurrency(props.dataContext.cell.value),
        isSortable: true,
      },
      {
        field: 'position' as keyof CurrentHolderTableColumns,
        header: 'Shares',
        dataType: 'number',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
          formatNumber(props.dataContext.cell.value),
        isSortable: true,
      },
      {
        field: 'change' as keyof CurrentHolderTableColumns,
        header: 'Change',
        dataType: 'number',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
          formatNumber(props.dataContext.cell.value),
        isSortable: true,
      },
      {
        field: 'perSharesOutstanding' as keyof CurrentHolderTableColumns,
        header: '% S/O',
        dataType: 'number',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
          props.dataContext.cell.value !== null
            ? `${formatNumber(props.dataContext.cell.value)}%`
            : '',
        isSortable: true,
      },
      {
        field: 'perPort' as keyof CurrentHolderTableColumns,
        header: '% Port',
        dataType: 'number',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
          props.dataContext.cell.value !== null
            ? `${formatNumber(props.dataContext.cell.value)}%`
            : '',
        isSortable: true,
      },
      {
        field: 'positionDate' as keyof CurrentHolderTableColumns,
        header: 'Position Date',
        dataType: 'date',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
          formatDate(props.dataContext.cell.value),
        isSortable: true,
      },
      {
        field: 'positionSource' as keyof CurrentHolderTableColumns,
        header: 'Position Source',
        dataType: 'string',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
          props.dataContext.cell.value,
        isSortable: true,
      },
      {
        field: 'aum' as keyof CurrentHolderTableColumns,
        header: 'Equity Assets Under Management',
        dataType: 'number',
        bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
          formatCurrency(props.dataContext.cell.value),
        isSortable: true,
      },
    ],
    [],
  );

  const data = useMemo(() => currentHolders, [currentHolders]);

  return {
    columns,
    data,
    isLoading: isLoadingCurrentHolders,
    primaryKey: 'institutionName' as keyof CurrentHolder,
  };
}
