import { useCallback, useMemo } from 'react';
import useCompanyStore from '../store/company.store';

// types
import { HistoricalHolder, HistoricalHolderTableColumns } from '../types';
import { TableProps } from '@/components/shared/Table/Table';

// lib
import { formatDate, truncate } from '@/lib/formatting';
import { exportToExcel } from '@/lib/excel';

// components
import HolderTableControls from '../components/HolderTableControls';
import Tooltip from '@/components/shared/Tooltip';
import { Link } from 'react-router-dom';

// icons
import { faDownload } from '@fortawesome/free-solid-svg-icons';
import { PATHS } from '@/routes/paths';

export default function useHistoricalHoldersTable() {
  const {
    historicalHolders,
    isLoadingHistoricalHolders,
    selectedCompany,
    reportDates,
    getHitlist,
    selectedHistoricalPeriods,
  } = useCompanyStore();

  const TRUNCATE_LENGTH = 32;

  const columns: TableProps<HistoricalHolderTableColumns>['columns'] =
    useMemo(() => {
      const baseColumns = [
        {
          key: 'controls' as keyof HistoricalHolderTableColumns,
          header: '',
          filter: 'none' as const,
          render: (_v: '', row: HistoricalHolder) => (
            <HolderTableControls row={row} />
          ),
          columnWidth: '9%',
        },
        {
          key: 'institutionName' as keyof HistoricalHolderTableColumns,
          header: 'Institution',
          filter: 'text' as const,
          render: (value: string, row: HistoricalHolder) => (
            <Tooltip
              placement="top"
              title={value.length > TRUNCATE_LENGTH ? value : ''}
            >
              <Link
                to={PATHS.get('INSTITUTIONS.PROFILE', {
                  entityId: row.instInternalId,
                })}
              >
                {truncate(value, TRUNCATE_LENGTH)}
              </Link>
            </Tooltip>
          ),
          columnWidth: '20%',
        },
        {
          key: 'investmentStyle' as keyof HistoricalHolderTableColumns,
          header: 'Investment Style',
          filter: 'text' as const,
          columnWidth: '17%',
        },
        {
          key: 'most_recent_report_date' as keyof HistoricalHolderTableColumns,
          header: 'Most Recent Date',
          filter: 'date' as const,
          render: (value: string) => formatDate(value),
          columnWidth: '17%',
        },
        {
          key: 'most_recent_position' as keyof HistoricalHolderTableColumns,
          header: 'Most Recent Position',
          filter: 'text' as const,
          columnWidth: '17%',
          render: (value: number) => value?.toLocaleString?.(),
        },
        {
          key: 'period_change' as keyof HistoricalHolderTableColumns,
          header: 'Period Change',
          filter: 'text' as const,
          columnWidth: 'calc(19% - 80px)',
          render: (value: number) => value?.toLocaleString?.(),
        },
      ];

      const historicalColumns = (selectedHistoricalPeriods ?? []).map(
        (period, index) => ({
          key: (index + 1).toString() as keyof HistoricalHolderTableColumns,
          header: formatDate(period),
          filter: 'text' as const,
          render: (value: number) => value?.toLocaleString?.(),
          columnWidth: '10%',
        }),
      );

      return [...baseColumns, ...historicalColumns];
    }, [selectedHistoricalPeriods]);

  const mappedHistoricalHolders = useMemo(() => {
    return historicalHolders.map((holder) => {
      const mappedHolder: any = { ...holder };
      selectedHistoricalPeriods.forEach((period, index) => {
        mappedHolder[index + 1] = holder[index + 1];
      });
      return mappedHolder;
    });
  }, [historicalHolders, selectedHistoricalPeriods]);

  const getEstimatesHoldings = useCallback(() => {
    const last8ReportDates = reportDates.slice(0, 8);

    const columns = [
      { header: 'Institution', key: 'institutionName' },
      { header: 'Investment Style', key: 'investmentStyle' },
      { header: 'Most Recent Date', key: 'most_recent_report_date' },
      { header: 'Most Recent Position', key: 'most_recent_position' },
      { header: 'Period Change', key: 'period_change' },
      ...selectedHistoricalPeriods.map((date, index) => ({
        header: formatDate(date),
        key: (index + 1).toString(),
      })),
    ];

    exportToExcel(
      mappedHistoricalHolders,
      columns,
      `${selectedCompany?.ticker}-${selectedCompany?.companyName}-EstimatesHoldings-${Date.now()}`,
    );
  }, [
    mappedHistoricalHolders,
    selectedHistoricalPeriods,
    selectedCompany,
    reportDates,
  ]);

  const initialSort = useMemo(() => undefined, []);
  const initialSortDirection: 'asc' | 'desc' = useMemo(() => 'asc', []);
  const initialLimit = useMemo(() => 50, []);

  const additionalButtons = useMemo(
    () => [
      {
        onClick: getEstimatesHoldings,
        children: 'Get Estimates Holdings',
        icon: faDownload,
      },
      {
        onClick: getHitlist,
        children: 'Hitlist',
        icon: faDownload,
      },
    ],
    [getEstimatesHoldings, getHitlist],
  );

  return {
    columns,
    data: mappedHistoricalHolders,
    initialSort,
    initialSortDirection,
    initialLimit,
    isLoading: isLoadingHistoricalHolders,
    selectedCompany,
    additionalButtons,
  };
}
