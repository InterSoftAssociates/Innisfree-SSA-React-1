import { useCallback, useEffect, useMemo, useState } from 'react';
import useCompanyStore from '../store/company.store';

export default function useHistoricalHoldersFilters() {
  const [isInititalized, setIsInititalized] = useState(false);
  const {
    isLoadingReportDates,
    reportDates = [],
    selectedHistoricalPeriods,
    setSelectedHistoricalPeriods,
    stakeFilingTypes,
    selectedStakeFilingTypes,
    setSelectedStakeFilingTypes,
    isLoadingStakeFilingTypes,
    selectAllHistoricalPeriods,
    selectAllStakeFilingTypes,
    forceRefresh,
  } = useCompanyStore();

  const [localHistoricalPeriods, setLocalHistoricalPeriods] = useState<
    string[]
  >([]);
  const [localStakeFilingTypes, setLocalStakeFilingTypes] = useState<string[]>(
    [],
  );

  useEffect(() => {
    // only need to do this once
    if (isInititalized) return;
    setLocalHistoricalPeriods(selectedHistoricalPeriods);
  }, [selectedHistoricalPeriods, isInititalized]);

  useEffect(() => {
    // only need to do this once
    if (isInititalized) return;
    setLocalStakeFilingTypes(selectedStakeFilingTypes);
  }, [selectedStakeFilingTypes, isInititalized]);

  useEffect(() => {
    if (localHistoricalPeriods.length > 0 && localStakeFilingTypes.length > 0) {
      setIsInititalized(true);
    }
  }, [localHistoricalPeriods, localStakeFilingTypes]);

  const handleHistoricalPeriodsChange = useCallback(
    (value: string | number | (string | number)[]) => {
      setLocalHistoricalPeriods(value as string[]);
    },
    [],
  );

  const handleStakeFilingTypesChange = useCallback(
    (value: string | number | (string | number)[]) => {
      setLocalStakeFilingTypes(value as string[]);
    },
    [],
  );

  const handleHistoricalPeriodsClose = useCallback(() => {
    if (
      JSON.stringify(localHistoricalPeriods) !==
      JSON.stringify(selectedHistoricalPeriods)
    ) {
      setSelectedHistoricalPeriods(localHistoricalPeriods);
    }
  }, [
    localHistoricalPeriods,
    selectedHistoricalPeriods,
    setSelectedHistoricalPeriods,
  ]);

  const handleStakeFilingTypesClose = useCallback(() => {
    if (
      JSON.stringify(localStakeFilingTypes) !==
      JSON.stringify(selectedStakeFilingTypes)
    ) {
      setSelectedStakeFilingTypes(localStakeFilingTypes);
    }
  }, [
    localStakeFilingTypes,
    selectedStakeFilingTypes,
    setSelectedStakeFilingTypes,
  ]);

  const reportDateOptions = useMemo(
    () => reportDates?.map?.((date) => ({ value: date, label: date })),
    [reportDates],
  );

  const stakeFilingTypeOptions = useMemo(
    () =>
      stakeFilingTypes?.map?.((type) => ({
        value: type.code,
        label: type.name,
      })),
    [stakeFilingTypes],
  );

  return {
    historicalPeriods: localHistoricalPeriods,
    stakeFilingTypes: localStakeFilingTypes,
    handleHistoricalPeriodsChange,
    handleStakeFilingTypesChange,
    handleHistoricalPeriodsClose,
    handleStakeFilingTypesClose,
    reportDateOptions,
    stakeFilingTypeOptions,
    isLoadingReportDates,
    isLoadingStakeFilingTypes,
    selectAllHistoricalPeriods,
    selectAllStakeFilingTypes,
    forceRefresh,
  };
}
