import { useCallback, useMemo } from 'react';
import useCompanyStore from '../store/company.store';

// components
import HolderTableControls from '../components/HolderTableControls';
import Tooltip from '@/components/shared/Tooltip';
import { Link } from 'react-router-dom';

// types
import { HistoricalHolder, HistoricalHolderTableColumns } from '../types';

// lib
import { formatDate } from '@/lib/formatting';
import { exportToExcel } from '@/lib/excel';

// icons
import { faDownload } from '@fortawesome/free-solid-svg-icons';
import { PATHS } from '@/routes/paths';

export default function useHistoricalHoldersTableIgnite() {
  const {
    historicalHolders,
    isLoadingHistoricalHolders,
    getHitlist,
    selectedCompany,
    selectedHistoricalPeriods,
  } = useCompanyStore();

  const holderTableControlsBodyTemplate = useCallback(
    (props: { dataContext: { cell: { row: { data: HistoricalHolder } } } }) => (
      <HolderTableControls
        row={props.dataContext.cell.row.data as HistoricalHolder}
      />
    ),
    [],
  );

  const institutionNameBodyTemplate = useCallback(
    (props: { dataContext: { cell: { value: string } } }) => (
      <Link
        to={PATHS.get('INSTITUTIONS.PROFILE', {
          entityId: props.dataContext.cell.row.data.instInternalId,
        })}
      >
        <Tooltip title={props.dataContext.cell.value}>
          {props.dataContext.cell.value}
        </Tooltip>
      </Link>
    ),
    [],
  );

  const columns = useMemo(
    () => [
      {
        field: 'controls' as keyof HistoricalHolderTableColumns,
        header: '',
        dataType: 'string',
        bodyTemplate: holderTableControlsBodyTemplate,
        isSortable: false,
      },
      {
        field: 'institutionName' as keyof HistoricalHolderTableColumns,
        header: 'Institution',
        dataType: 'string',
        bodyTemplate: institutionNameBodyTemplate,
        isSortable: true,
      },
      {
        field: 'investmentStyle' as keyof HistoricalHolderTableColumns,
        header: 'Investment Style',
        dataType: 'string',
        isSortable: true,
      },
      {
        field: 'most_recent_report_date' as keyof HistoricalHolderTableColumns,
        header: 'Most Recent Date',
        dataType: 'date',
        formatter: formatDate,
        isSortable: true,
      },
      {
        field: 'most_recent_position' as keyof HistoricalHolderTableColumns,
        header: 'Most Recent Position',
        dataType: 'number',
        isSortable: true,
      },
      {
        field: 'period_change' as keyof HistoricalHolderTableColumns,
        header: 'Period Change',
        dataType: 'number',
        isSortable: true,
      },
      ...(selectedHistoricalPeriods ?? []).map((period, index) => ({
        field: (index + 1).toString() as keyof HistoricalHolderTableColumns,
        header: formatDate(period),
        dataType: 'number',
        isSortable: true,
      })),
    ],

    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedHistoricalPeriods],
  );

  const data = useMemo(() => {
    return historicalHolders.map((holder: HistoricalHolder) => {
      const mappedHolder: any = { ...holder };
      selectedHistoricalPeriods.forEach((_period: string, index: number) => {
        mappedHolder[index + 1] = holder[index + 1];
      });
      return mappedHolder;
    });
  }, [historicalHolders, selectedHistoricalPeriods]);

  const getEstimatesHoldings = useCallback(() => {
    const excelColumns = [
      { header: 'Institution', key: 'institutionName' },
      { header: 'Investment Style', key: 'investmentStyle' },
      { header: 'Most Recent Date', key: 'most_recent_report_date' },
      { header: 'Most Recent Position', key: 'most_recent_position' },
      { header: 'Period Change', key: 'period_change' },
      ...(selectedHistoricalPeriods ?? []).map((date, index) => ({
        header: formatDate(date),
        key: (index + 1).toString(),
      })),
    ];

    exportToExcel(
      data,
      excelColumns,
      `${selectedCompany?.ticker}-${
        selectedCompany?.companyName
      }-EstimatesHoldings-${Date.now()}`,
    );
  }, [data, selectedHistoricalPeriods, selectedCompany]);

  const additionalButtons = useMemo(
    () => [
      {
        onClick: getEstimatesHoldings,
        children: 'Get Estimates Holdings',
        icon: faDownload,
      },
      {
        onClick: getHitlist,
        children: 'Hitlist',
        icon: faDownload,
      },
    ],
    [getEstimatesHoldings, getHitlist],
  );

  return useMemo(
    () => ({
      columns,
      data,
      isLoading: isLoadingHistoricalHolders,
      primaryKey: 'institutionName' as keyof HistoricalHolder,
      additionalButtons,
    }),
    [columns, data, isLoadingHistoricalHolders, additionalButtons],
  );
}
