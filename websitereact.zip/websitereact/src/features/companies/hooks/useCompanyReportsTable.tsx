// hooks
import { useMemo } from 'react';
import useCompanyReportsStore from '../store/companyReports.store';

// types
import { Company } from '../types';
import { ColumnDef } from '@/components/shared/Table/Table';

// lib
import { formatToIgniteTableColumns } from '@/lib/formatting';

// components
import IconButton from '@/components/shared/IconButton';
import Tooltip from '@/components/shared/Tooltip';

// icons
import { faCancel, faReceipt } from '@fortawesome/free-solid-svg-icons';

export default function useCompanyReportsTable() {
  const { selectedCompanies, removeCompany, runReport, isRunReportLoading } =
    useCompanyReportsStore();

  const columns: ColumnDef<Company>[] = useMemo(
    () => [
      {
        key: 'companyName',
        header: 'Company Name',
        filter: 'text',
        render: (value: string) => value,
      },
      {
        key: ' ' as keyof Company,
        header: '',
        filter: 'none',
        render: (_value: '', row: Company) => (
          <Tooltip title="Delete Row" placement="top">
            <IconButton
              color="error"
              onClick={() => removeCompany(row)}
              icon={faCancel}
            />
          </Tooltip>
        ),
      },
    ],

    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  // columns in a format that works for infragistics table IgniteTable component rather than custom Table component
  const igniteColumns = useMemo(
    () => formatToIgniteTableColumns(columns),
    [columns],
  );

  const toolbarButtons = useMemo(
    () => [
      {
        children: 'Run Report',
        icon: faReceipt,
        onClick: runReport,
      },
    ],

    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  const memoizedData = useMemo(
    () => ({
      columns,
      igniteColumns,
      data: selectedCompanies,
      toolbarButtons,
      isLoading: false,
      isRunReportLoading,
    }),
    [
      columns,
      igniteColumns,
      selectedCompanies,
      toolbarButtons,
      isRunReportLoading,
    ],
  );

  return memoizedData;
}
