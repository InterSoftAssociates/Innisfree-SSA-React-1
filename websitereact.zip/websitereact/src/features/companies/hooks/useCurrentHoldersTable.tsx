// hooks
import { useMemo } from 'react';
import useCompanyStore from '../store/company.store';

// types
import { CurrentHolder, CurrentHolderTableColumns } from '../types';
import { TableProps } from '@/components/shared/Table/Table';

// lib
import {
  formatDate,
  formatNumber,
  formatCurrency,
  truncate,
} from '@/lib/formatting';

// components
import HolderTableControls from '../components/HolderTableControls';
import Tooltip from '@/components/shared/Tooltip';

const TRUNCATE_LENGTH = 23;

export default function useCurrentHoldersTable() {
  const { currentHolders, isLoadingCurrentHolders } = useCompanyStore();

  const columns: TableProps<CurrentHolderTableColumns>['columns'] = useMemo(
    () => [
      {
        key: 'controls' as keyof CurrentHolderTableColumns,
        header: '',
        render: (_v: '', row: CurrentHolder) => (
          <HolderTableControls row={row} />
        ),
        columnWidth: '8%',
      },
      {
        key: 'institutionName',
        header: 'Institution',
        filter: 'text',
        render: (value: string) => (
          <Tooltip placement="top" title={value}>
            {truncate(value, TRUNCATE_LENGTH)}
          </Tooltip>
        ),
        columnWidth: '12%',
      },
      {
        key: 'investmentStyle',
        header: 'Investment Style',
        filter: 'text',
        render: (value: string) => (
          <Tooltip placement="top" title={value}>
            {truncate(value || '', TRUNCATE_LENGTH)}
          </Tooltip>
        ),
        columnWidth: '12%',
      },
      {
        key: 'value',
        header: 'Value (USD,MM)',
        filter: 'text',
        render: (value: number) => formatCurrency(value),
        columnWidth: '10%',
      },
      {
        key: 'position',
        header: 'Shares',
        filter: 'number',
        render: (value: number) => formatNumber(value),
        columnWidth: '10%',
      },
      {
        key: 'change',
        header: 'Change',
        filter: 'number',
        render: (value: number) => formatNumber(value),
        columnWidth: '10%',
      },
      {
        key: 'perSharesOutstanding',
        header: '% S/O',
        filter: 'number',
        render: (value: number | null) =>
          value !== null ? `${formatNumber(value)}%` : '',
        columnWidth: '8%',
      },
      {
        key: 'perPort',
        header: '% Port',
        filter: 'number',
        render: (value: number | null) =>
          value !== null ? `${formatNumber(value)}%` : '',
        columnWidth: '8%',
      },
      {
        key: 'positionDate',
        header: 'Position Date',
        filter: 'date',
        render: (value: string) => formatDate(value),
        columnWidth: '8%',
      },
      {
        key: 'positionSource',
        header: 'Position Source',
        filter: 'text',
        columnWidth: '8%',
      },
      {
        key: 'aum',
        header: 'Equity Assets Under Management',
        filter: 'number',
        render: (value: number) => formatCurrency(value),
        columnWidth: '20%',
      },
    ],
    [],
  );

  // const initialSort = useMemo(() => 'value' as keyof CurrentHolder, []);
  const initialSort = useMemo(() => undefined, []);
  const initialSortDirection: 'asc' | 'desc' = useMemo(() => 'desc', []);
  const initialLimit = useMemo(() => 50, []);

  return {
    columns,
    data: currentHolders,
    initialSort,
    initialSortDirection,
    initialLimit,
    isLoading: isLoadingCurrentHolders,
  };
}
