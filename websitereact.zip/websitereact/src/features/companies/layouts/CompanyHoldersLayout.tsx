import { useCallback } from 'react';
// store
import useCompanyStore from '../store/company.store';

// types
import { Company, CompanyInfo } from '../types';

// components
import { Card } from '@/components/shared';
import { CompanySearch, CompanyInfoTable } from '../components';

// styles
import './CompanyHoldersLayout.scss';

interface CompanyHoldersLayoutProps {
  children: React.ReactNode;
}

export default function CompanyHoldersLayout({
  children,
}: CompanyHoldersLayoutProps) {
  const { selectedCompany, selectedCompanyInfo, setSelectedCompany } =
    useCompanyStore();

  const onCompanySelected = useCallback(
    ({
      company,
      companyInfo,
    }: {
      company: Company | null;
      companyInfo: CompanyInfo | null;
    }) => setSelectedCompany({ company, companyInfo }),

    // eslint-disable-next-line react-hooks/exhaustive-deps
    [setSelectedCompany, selectedCompany, selectedCompanyInfo],
  );

  return (
    <main className="CompanyHoldersLayout">
      <Card contentClassName="CompanyHoldersLayout__search" Component="section">
        <CompanySearch
          defaultCompany={selectedCompany}
          onCompanySelected={onCompanySelected}
        />
        <CompanyInfoTable
          companyInfo={selectedCompanyInfo as CompanyInfo | null}
        />
      </Card>
      <section className="CompanyHoldersLayout__children">{children}</section>
    </main>
  );
}
