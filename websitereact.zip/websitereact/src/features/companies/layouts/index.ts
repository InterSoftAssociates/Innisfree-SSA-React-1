export { default } from './CompanyHoldersLayout';
