import api from '@api';

// types
import {
  Company,
  CompanyInfo,
  GetHistoricalHoldersResponse,
  GetHistoricalHoldersPayload,
  StakeFilingType,
  GetCurrentHoldersPayload,
  GetCurrentHoldersResponse,
  GetHitlistPayload,
  GetHitlistResponse,
  GetCompanyReportPayload,
  GetCompanyReportResponse,
} from '../types';
import InvestmentStyle from '../types/InvestmentStyle';
import { Institution } from '@/features/institutions/types';
import { downloadExcel } from '@/lib/excel';

// lib
import { displayAPIErrorMessage } from '@/lib/notifications';
import { performanceMeasurement } from '@/lib/performanceMeasurement';
import IQCache from '@/lib/cache';

const cachedCompaniesQuickSearch: IQCache = new IQCache({
  ttl: 1000 * 60 * 60, // 1 hour
  maxItems: 100,
  key: 'COMPANIES_QUICK_SEARCH',
});

export const postCompaniesQuickSearch = async (query: string) => {
  if (query.length < 2) return;

  // only caching quick search and info, not the tables...
  const cached = cachedCompaniesQuickSearch.get(query);
  if (cached) {
    return cached;
  }

  const response = await api.post<Company[]>(
    `/Home/CompanyQuickSearch/${query}`,
  );

  cachedCompaniesQuickSearch.set(query, response.data);
  return response.data;
};

const cachedCompanyInfo: IQCache = new IQCache({
  ttl: 1000 * 60 * 60, // 1 hour
  maxItems: 100,
  key: 'COMPANY_INFO',
});

export const postGetCompanyInfo = async (companyId: number) => {
  // only caching quick search and info, not the tables aka historical holders/current holders...
  const cached = cachedCompanyInfo.get(companyId);

  if (cached) {
    return cached;
  }

  const response = await api.post<CompanyInfo>(
    `/Home/GetCompanyInfo/${companyId}`,
  );

  cachedCompanyInfo.set(companyId, response.data);
  return response.data;
};

export const getStakeFilingTypes = async () => {
  // performanceMeasurement.start('getStakeFilingTypes');
  const response = await api.get<StakeFilingType[]>(
    `/Home/GetStakeFilingTypes`,
  );
  // performanceMeasurement.end('getStakeFilingTypes');
  return response.data;
};

export const getReportDates = async () => {
  // performanceMeasurement.start('getReportDates');
  const response = await api.get<string[]>(`/Home/Get13fReportDates`);
  // performanceMeasurement.end('getReportDates');
  return response.data;
};

export const getInvestmentStyles = async () => {
  // performanceMeasurement.start('getInvestmentStyles');
  const response = await api.get<InvestmentStyle[]>(
    `/Home/GetInvestmentStyles`,
  );
  // performanceMeasurement.end('getInvestmentStyles');
  return response.data;
};

export const postGetHistoricalHolders = async (
  payload: GetHistoricalHoldersPayload,
): Promise<GetHistoricalHoldersResponse> => {
  performanceMeasurement.start('getHistoricalHolders');
  const response = await api.post<GetHistoricalHoldersResponse>(
    `/Home/GetHistoricalHolders`,
    payload,
  );
  performanceMeasurement.end('getHistoricalHolders');
  return response.data;
};

export const postGetCurrentHolders = async (
  payload: GetCurrentHoldersPayload,
) => {
  const response = await api.post<GetCurrentHoldersResponse>(
    `/Home/GetCurrHolders`,
    payload,
  );
  return response.data;
};

export const getInstitutions = async (query: string) => {
  const url = `/Home/GetInstitutionNames/${query}`;
  const response = await api.get<Institution[]>(url);
  return response.data;
};

export const postGetHitlist = async (payload: GetHitlistPayload) => {
  try {
    const { data } = await api.post<GetHitlistResponse>(
      `/Home/GetHitlist`,
      payload,
    );
    if (data.messageResponse.success) {
      downloadExcel(data.fileData, data.fileName);
    } else {
      displayAPIErrorMessage({ message: data.messageResponse.message });
    }
  } catch (error) {
    displayAPIErrorMessage(error);
  }
};

export const postGetMoneyFlowReport = async (
  payload: GetCompanyReportPayload,
): Promise<GetCompanyReportResponse> => {
  const url = `/Home/GetMoneyFlowReport`;
  const response = await api.post(url, payload);

  if (response.data.messageResponse.success) {
    downloadExcel(response.data.fileData, response.data.fileName);
  } else {
    displayAPIErrorMessage({ message: response.data.messageResponse.message });
  }

  return response.data;
};
