import AppRouter from './routes/index.routes';

function App() {
  return (
    <div className="App">
      <AppRouter />
    </div>
  );
}

export default App;
