import { createRoot } from 'react-dom/client';

// components
import App from './App';
import ErrorBoundary from './components/ErrorBoundary';

// clients/services
import { initializeMsal, msalInstance } from './services/msal';
import {
  IgrGridModule,
  IgrGridToolbarModule,
} from '@infragistics/igniteui-react-grids';
import { defineCustomElements } from '@infragistics/igniteui-dockmanager/loader';

// providers
import { MsalProvider } from '@azure/msal-react';
import { BrowserRouter } from 'react-router-dom';
import SnackbarProvider from './providers/SnackbarProvider';

// styles
import 'normalize.css';
import './styles/index.scss';

defineCustomElements();
IgrGridModule.register();
IgrGridToolbarModule.register();

initializeMsal().then(() => {
  createRoot(document.getElementById('root')!).render(
    <ErrorBoundary>
      <BrowserRouter>
        <SnackbarProvider>
          <MsalProvider instance={msalInstance}>
            <App />
          </MsalProvider>
        </SnackbarProvider>
      </BrowserRouter>
    </ErrorBoundary>,
  );
});
