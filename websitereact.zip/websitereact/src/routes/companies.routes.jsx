import { lazy, Suspense } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { PATHS } from './paths';

// components
import CompanyHoldersLayout from '@/features/companies/layouts/CompanyHoldersLayout';
import CompanyStoreProvider from '@/features/companies/providers/CompanyStoreProvider';

// screens
const CompanyReportsScreen = lazy(
  () => import('../features/companies/screens/CompanyReportsScreen'),
);
const HistoricalHoldersScreen = lazy(
  () => import('../features/companies/screens/HistoricalHoldersScreen'),
);
const CurrentHoldersScreen = lazy(
  () => import('../features/companies/screens/CurrentHoldersScreen'),
);

const companyRoutes = [
  {
    path: PATHS.COMPANIES.PARENT,
    element: (
      <CompanyStoreProvider>
        <Outlet />
      </CompanyStoreProvider>
    ),

    children: [
      {
        path: '',
        index: true,
        element: <Navigate to={PATHS.HOME} replace />,
      },

      {
        path: PATHS.COMPANIES.REPORTS,
        element: <CompanyReportsScreen />,
      },
      {
        element: (
          <CompanyHoldersLayout>
            <Outlet />
          </CompanyHoldersLayout>
        ),
        children: [
          {
            path: PATHS.COMPANIES.CURRENT_HOLDERS,
            element: <CurrentHoldersScreen />,
          },

          {
            path: PATHS.COMPANIES.HISTORICAL_HOLDERS,
            element: <HistoricalHoldersScreen />,
          },
        ],
      },
    ],
  },
];

export default companyRoutes;
