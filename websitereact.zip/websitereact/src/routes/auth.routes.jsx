import { Suspense } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { PATHS } from './paths';

// guards
import GuestGuard from '@/guards/GuestGuard';

// layouts
import AuthLayout from '@/layouts/AuthLayout';

// screens
import LoginScreen from '@/features/auth/screens/LoginScreen';

const authRoutes = [
  {
    path: PATHS.AUTH.PARENT,
    element: (
      <AuthLayout>
        <Suspense fallback={<div>loading...</div>}>
          <Outlet />
        </Suspense>
      </AuthLayout>
    ),

    children: [
      {
        path: '',
        element: <Navigate to={PATHS.AUTH.LOGIN} replace />,
      },
      {
        path: PATHS.AUTH.LOGIN,
        element: (
          <GuestGuard>
            <LoginScreen />
          </GuestGuard>
        ),
      },
      // {
      //   path: PATHS.AUTH.SIGN_UP,
      //   element: (
      //     <GuestGuard>
      //       <SignUpscreen />
      //     </GuestGuard>
      //   ),
      // },
    ],
  },
];

export default authRoutes;
