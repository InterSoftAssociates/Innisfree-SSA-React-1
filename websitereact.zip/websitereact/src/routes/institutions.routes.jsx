import { lazy, Suspense } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { PATHS } from './paths';

// screens
const InstitutionProfileScreen = lazy(
  () => import('../features/institutions/screens/InstitutionProfileScreen'),
);

const institutionRoutes = [
  {
    path: PATHS.INSTITUTIONS.PARENT,
    element: <Outlet />,

    children: [
      {
        path: '',
        index: true,
        element: <Navigate to={PATHS.HOME} replace />,
      },

      {
        path: PATHS.INSTITUTIONS.PROFILE,
        element: <InstitutionProfileScreen />,
      },
    ],
  },
];

export default institutionRoutes;
