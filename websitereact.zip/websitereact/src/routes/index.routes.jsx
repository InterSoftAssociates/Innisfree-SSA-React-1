import { lazy, Suspense } from 'react';
import { useNavigate, useRoutes, Outlet } from 'react-router-dom';
import { PATHS } from './paths';

// components
import ClassicLayout from '@/layouts/ClassicLayout';
import AuthGuard from '@/guards/AuthGuard';

// routes
import authRoutes from './auth.routes';
import institutionRoutes from './institutions.routes';
import companyRoutes from './companies.routes';

// screens
const HomeScreen = lazy(() => import('../screens/HomeScreen'));
const NotFoundScreen = lazy(() => import('../screens/NotFoundScreen'));

export default function AppRouter() {
  return useRoutes([
    {
      path: '',
      element: (
        <AuthGuard>
          <ClassicLayout>
            <Suspense /*fallback={<div>loading...</div>}*/>
              <Outlet />
            </Suspense>
          </ClassicLayout>
        </AuthGuard>
      ),

      // all the routes that will inherit the AuthGUard and the ClassicLayout
      children: [
        {
          index: true,
          element: <HomeScreen />,
        },
        ...institutionRoutes,
        ...companyRoutes,
      ],
    },

    // routes that will not inherit the AuthGuard and the ClassicLayout
    ...authRoutes,
    {
      path: '*',
      element: <NotFoundScreen />,
    },
  ]);
}
