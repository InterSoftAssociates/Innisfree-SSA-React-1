export const PATHS = {
  HOME: '/',
  AUTH: {
    PARENT: 'auth',
    LOGIN: 'login',
    SIGN_UP: 'sign-up',
  },
  SUBLEVEL: {
    PARENT: 'sublevel',
    MANAGE_USERS: 'manage-users',
  },
  COMPANIES: {
    PARENT: 'companies',
    REPORTS: 'reports',
    PROFILE: ':entityId',
    CURRENT_HOLDERS: 'current-holders',
    HISTORICAL_HOLDERS: 'historical-holders',
  },
  INSTITUTIONS: {
    PARENT: 'institutions',
    PROFILE: ':entityId',
  },
  get(path, params = {}) {
    const parts = path.split('.');
    let current = this;
    const segments = [];

    for (const part of parts) {
      if (current[part] === undefined) {
        return null; // Path not found
      }
      if (current[part].PARENT) {
        segments.push(current[part].PARENT);
      }
      current = current[part];
    }

    if (typeof current === 'string') {
      segments.push(current);
    }

    let resolvedPath = '/' + segments.join('/');

    // Replace parameters
    Object.entries(params).forEach(([key, value]) => {
      resolvedPath = resolvedPath.replace(`:${key}`, value);
    });

    return resolvedPath;
  },
};
