export const textFilterOptions = [
  {
    value: 'clear',
    label: 'Clear filter',
    filterFn: (value: string, items) => items,
  },
  {
    value: 'startsWith',
    label: 'Starts with',
    filterFn: (value: string, items: string[]) =>
      items.filter((item) => item.startsWith(value)),
  },
  {
    value: 'endsWith',
    label: 'Ends with',
    filterFn: (value: string, items: string[]) =>
      items.filter((item) => item.endsWith(value)),
  },
  {
    value: 'contains',
    label: 'Contains',
    filterFn: (value: string, items: string[]) =>
      items.filter((item) => item.includes(value)),
  },
  {
    value: 'notContains',
    label: 'Does not contain',
    filterFn: (value: string, items: string[]) =>
      items.filter((item) => !item.includes(value)),
  },
  {
    value: 'equals',
    label: 'Equals',
    filterFn: (value: string, items) => items.filter((item) => item === value),
  },
  {
    value: 'notEquals',
    label: 'Does not equal',
    filterFn: (value: string, items) => items.filter((item) => item !== value),
  },
];

export const dateFilterOptions = [
  {
    value: 'clear',
    label: 'Clear filter',
    filterFn: (value: string, items) => items,
  },
  {
    value: 'on',
    label: 'On',
    filterFn: (value: string, items) => items.filter((item) => item === value),
  },
  {
    value: 'notOn',
    label: 'Not On',
    filterFn: (value: string, items) => items.filter((item) => item !== value),
  },
  {
    value: 'after',
    label: 'After',
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getTime() > new Date(value).getTime(),
      ),
  },
  {
    value: 'before',
    label: 'Before',
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getTime() < new Date(value).getTime(),
      ),
  },
  {
    value: 'today',
    label: 'Today',
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).toDateString() === new Date().toDateString(),
      ),
  },
  {
    value: 'yesterday',
    label: 'Yesterday',
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).toDateString() === new Date().toDateString(),
      ),
  },
  {
    value: 'thisMonth',
    label: 'This month',
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getMonth() === new Date().getMonth(),
      ),
  },
  {
    value: 'lastMonth',
    label: 'Last month',
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getMonth() === new Date().getMonth(),
      ),
  },
  {
    value: 'nextMonth',
    label: 'Next month',
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getMonth() === new Date().getMonth(),
      ),
  },
  {
    value: 'thisYear',
    label: 'This year',
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getFullYear() === new Date().getFullYear(),
      ),
  },
  {
    value: 'lastYear',
    label: 'Last year',
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getFullYear() === new Date().getFullYear(),
      ),
  },
  {
    value: 'nextYear',
    label: 'Next year',
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getFullYear() === new Date().getFullYear(),
      ),
  },
];

export const findFilter = (filterType: string, key: string) => {
  switch (filterType) {
    case 'text':
      return textFilterOptions.find((option) => option.value === key);
    case 'date':
      return dateFilterOptions.find((option) => option.value === key);
    default:
      return [];
  }
};
