import { devlog } from './logging';

export type PerformanceMetric = {
  name: string;
  duration: number;
};

class PerformanceMeasurement {
  private metrics: PerformanceMetric[] = [];
  private ongoing: { [key: string]: number } = {};

  start(key: string): void {
    this.ongoing[key] = performance.now();
  }

  end(key: string): void {
    if (this.ongoing[key]) {
      const duration = performance.now() - this.ongoing[key];
      // this.metrics.push({ name: key, duration });
      devlog(`${key}: ${duration.toFixed(2)}ms`);
      delete this.ongoing[key];
    } else {
      devlog(`No start time found for key: ${key}`, 'warn');
    }
  }

  async measure<T>(name: string, fn: () => Promise<T>): Promise<T> {
    this.start(name);
    try {
      return await fn();
    } finally {
      this.end(name);
    }
  }

  getMetrics(): PerformanceMetric[] {
    return this.metrics;
  }

  clearMetrics(): void {
    this.metrics = [];
    this.ongoing = {};
  }
}

export const performanceMeasurement = new PerformanceMeasurement();
