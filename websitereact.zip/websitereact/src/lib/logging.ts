export const devlog = (
  message: string,
  method: 'log' | 'warn' | 'error' = 'log',
) => {
  if (process.env.NODE_ENV === 'production') return;
  console[method](message);
};
