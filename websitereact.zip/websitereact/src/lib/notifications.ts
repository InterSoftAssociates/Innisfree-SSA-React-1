import { enqueueSnackbar, VariantType } from 'notistack';

const errorMessages: string[] = [];

export const displayAPIErrorMessage = (
  error: {
    response?: { data?: { message: string } };
    message: string;
  },
  duration = 5000,
) => {
  const message =
    error.response?.data?.message || error.message || 'please try again later';

  if (errorMessages.includes(message)) return;

  errorMessages.push(message);
  enqueueSnackbar(message, {
    variant: 'error',
    autoHideDuration: duration,
    anchorOrigin: {
      vertical: 'top',
      horizontal: 'center',
    },
  });

  const intervalId = setInterval(() => {
    const index = errorMessages.indexOf(message);
    if (index !== -1) {
      errorMessages.splice(index, 1);
      clearInterval(intervalId);
    }
  }, duration);

  setTimeout(() => {
    clearInterval(intervalId);
  }, duration);
};

export const displayGeneralMessage = (
  message: string,
  variant: VariantType = 'info',
  duration = 5000,
) => {
  enqueueSnackbar(message, {
    variant,
    autoHideDuration: duration,
    anchorOrigin: {
      vertical: 'top',
      horizontal: 'center',
    },
  });
};
