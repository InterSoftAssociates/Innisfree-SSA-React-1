import * as XLSX from 'xlsx';

export function exportToExcel<T>(
  data: T[],
  columns: any,
  fileName: string = `Export-${Date.now()}`,
) {
  const worksheet = XLSX.utils.json_to_sheet(
    data.map((row) =>
      columns.reduce(
        (acc, column) => {
          acc[column.header] = row[column.key];
          return acc;
        },
        {} as Record<string, any>,
      ),
    ),
  );
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
  XLSX.writeFile(workbook, `${fileName}.xlsx`);
}

export function downloadExcel(data: any, fileName: string) {
  const a = document.createElement('a');
  document.body?.appendChild(a);
  //if it's a base64 string
  const byteArray = Uint8Array.from(atob(data), (c) => c.charCodeAt(0));

  //var byteArray = new Uint8Array(data);

  const blob = new Blob([byteArray], { type: 'application/octet-stream' });
  const url = window.URL.createObjectURL(blob);

  a.href = url;
  a.download = fileName;
  a.click();
  setTimeout(function () {
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }, 100);
}
