interface CacheSettings {
  ttl: number;
  maxItems: number;
  key: string;
}

export default class IQCache {
  private cache: Record<string, any> = {};

  constructor(private settings: CacheSettings) {}

  set(key: string | number, value: any) {
    this.cache[key] = value;

    if (this.isFull) {
      const oldestKey = this.getKeys()[0];
      delete this.cache[oldestKey];
    }

    this.startRemovalInterval();
  }

  get(key: string | number) {
    return this.cache[key];
  }

  clear() {
    this.cache = {};
  }

  getKeys() {
    return Object.keys(this.cache);
  }

  getValues() {
    return Object.values(this.cache);
  }

  getEntries() {
    return Object.entries(this.cache);
  }

  get size() {
    return Object.keys(this.cache).length;
  }

  get maxItems() {
    return this.settings.maxItems;
  }

  get ttl() {
    return this.settings.ttl;
  }

  get key() {
    return this.settings.key;
  }

  get isFull() {
    return this.size >= this.maxItems;
  }

  get isExpired() {
    return this.ttl <= 0;
  }

  get isEmpty() {
    return this.size === 0;
  }

  startRemovalInterval() {
    setInterval(() => {
      this.clear();
    }, this.ttl);
  }
}
