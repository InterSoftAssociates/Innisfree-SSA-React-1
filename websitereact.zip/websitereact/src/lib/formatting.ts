import { IgniteColumns } from '@/components/shared/IgniteTable/IgniteTable';
import { IgrCellTemplateContext } from '@infragistics/igniteui-react-grids';
import { format, parseISO } from 'date-fns';

export const formatDate = (dateString: string) => {
  try {
    return format(parseISO(dateString), 'MM/dd/yyyy');
  } catch {
    return dateString;
  }
};

export const formatNumber = (value: number | null, fracDigits: number = 2) => {
  if (value === null) return '';
  return new Intl.NumberFormat('en-US', {
    maximumFractionDigits: fracDigits,
  }).format(value);
};

export const formatCurrency = (
  value: number | null,
  fracDigits: number = 2,
) => {
  if (value === null) return '';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: fracDigits,
    maximumFractionDigits: fracDigits,
  }).format(value / 1000000); // Convert to millions
};

export const truncate = (value: string = '', length: number) =>
  value.length > length ? `${value.slice(0, length)}...` : value;

export const formatToIgniteTableColumns = (columns: any[]) =>
  // Convert columns to IgniteTable format
  columns.map((column) => ({
    field: column.key as string,
    header: column.header,
    dataType: 'string',
    isSortable: true,
    bodyTemplate: (props: { dataContext: IgrCellTemplateContext }) =>
      column.render?.(
        props.dataContext.cell.value,
        props.dataContext.cell.row.data,
      ),
  })) as IgniteColumns;
