export * from '../routes/paths';

export const REPORT_TYPES = [{ label: 'Money Flow', value: 'moneyflow' }];
