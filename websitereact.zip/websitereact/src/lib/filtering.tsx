import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faEraser,
  faArrowRight,
  faArrowLeft,
  faSearch,
  faBan,
  faEquals,
  faNotEqual,
} from '@fortawesome/free-solid-svg-icons';
import {
  faCalendarDay,
  faCalendarTimes,
  faCalendarPlus,
  faCalendarMinus,
  faCalendar,
} from '@fortawesome/free-solid-svg-icons';

export const textFilterOptions = [
  {
    value: 'clear',
    label: 'Clear filter',
    icon: <FontAwesomeIcon icon={faEraser} />,
    filterFn: (value: string, items) => items,
  },
  {
    value: 'startsWith',
    label: 'Starts with',
    icon: <FontAwesomeIcon icon={faArrowRight} />,
    filterFn: (value: string, items: string[]) =>
      items.filter((item) => item.startsWith(value)),
  },
  {
    value: 'endsWith',
    label: 'Ends with',
    icon: <FontAwesomeIcon icon={faArrowLeft} />,
    filterFn: (value: string, items: string[]) =>
      items.filter((item) => item.endsWith(value)),
  },
  {
    value: 'contains',
    label: 'Contains',
    icon: <FontAwesomeIcon icon={faSearch} />,
    filterFn: (value: string, items: string[]) =>
      items.filter((item) => item.includes(value)),
  },
  {
    value: 'notContains',
    label: 'Does not contain',
    icon: <FontAwesomeIcon icon={faBan} />,
    filterFn: (value: string, items: string[]) =>
      items.filter((item) => !item.includes(value)),
  },
  {
    value: 'equals',
    label: 'Equals',
    icon: <FontAwesomeIcon icon={faEquals} />,
    filterFn: (value: string, items) => items.filter((item) => item === value),
  },
  {
    value: 'notEquals',
    label: 'Does not equal',
    icon: <FontAwesomeIcon icon={faNotEqual} />,
    filterFn: (value: string, items) => items.filter((item) => item !== value),
  },
];

export const dateFilterOptions = [
  {
    value: 'clear',
    label: 'Clear filter',
    icon: <FontAwesomeIcon icon={faEraser} />,
    filterFn: (value: string, items) => items,
  },
  {
    value: 'on',
    label: 'On',
    icon: <FontAwesomeIcon icon={faCalendarDay} />,
    filterFn: (value: string, items) => items.filter((item) => item === value),
  },
  {
    value: 'notOn',
    label: 'Not On',
    icon: <FontAwesomeIcon icon={faCalendarTimes} />,
    filterFn: (value: string, items) => items.filter((item) => item !== value),
  },
  {
    value: 'after',
    label: 'After',
    icon: <FontAwesomeIcon icon={faCalendarPlus} />,
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getTime() > new Date(value).getTime(),
      ),
  },
  {
    value: 'before',
    label: 'Before',
    icon: <FontAwesomeIcon icon={faCalendarMinus} />,
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getTime() < new Date(value).getTime(),
      ),
  },
  {
    value: 'today',
    label: 'Today',
    icon: <FontAwesomeIcon icon={faCalendar} />,
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).toDateString() === new Date().toDateString(),
      ),
  },
  {
    value: 'yesterday',
    label: 'Yesterday',
    icon: <FontAwesomeIcon icon={faCalendarDay} />,
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).toDateString() === new Date().toDateString(),
      ),
  },
  {
    value: 'thisMonth',
    label: 'This month',
    icon: <FontAwesomeIcon icon={faCalendar} />,
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getMonth() === new Date().getMonth(),
      ),
  },
  {
    value: 'lastMonth',
    label: 'Last month',
    icon: <FontAwesomeIcon icon={faCalendar} />,
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getMonth() === new Date().getMonth(),
      ),
  },
  {
    value: 'nextMonth',
    label: 'Next month',
    icon: <FontAwesomeIcon icon={faCalendar} />,
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getMonth() === new Date().getMonth(),
      ),
  },
  {
    value: 'thisYear',
    label: 'This year',
    icon: <FontAwesomeIcon icon={faCalendar} />,
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getFullYear() === new Date().getFullYear(),
      ),
  },
  {
    value: 'lastYear',
    label: 'Last year',
    icon: <FontAwesomeIcon icon={faCalendar} />,
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getFullYear() === new Date().getFullYear(),
      ),
  },
  {
    value: 'nextYear',
    label: 'Next year',
    icon: <FontAwesomeIcon icon={faCalendar} />,
    filterFn: (value: string, items: string[]) =>
      items.filter(
        (item) => new Date(item).getFullYear() === new Date().getFullYear(),
      ),
  },
];

export const findFilter = (filterType: string, key: string) => {
  switch (filterType) {
    case 'text':
      return textFilterOptions.find((option) => option.value === key);
    case 'date':
      return dateFilterOptions.find((option) => option.value === key);
    default:
      return [];
  }
};

export const filterUnique = (array: any[]) =>
  array.filter((value, index, self) => self.indexOf(value) === index);
