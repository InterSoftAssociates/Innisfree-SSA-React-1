export { default } from './ErrorBoundary';
