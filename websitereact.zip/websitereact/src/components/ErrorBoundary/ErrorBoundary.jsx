import React from 'react';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ error, errorInfo });
    console.error('Error caught by ErrorBoundary:', error, errorInfo);
  }

  parseErrorStack(stack) {
    if (!stack) return null;
    const stackLines = stack.split('\n');
    for (let line of stackLines) {
      // Updated regex to capture the full path including query parameters
      const match = line.match(/at .+ \((.+?):(\d+):(\d+)\)/);
      if (match) {
        return {
          filePath: match[1],
          lineNumber: parseInt(match[2], 10),
          columnNumber: parseInt(match[3], 10),
        };
      }
    }
    return null;
  }

  openInIDE(filePath, lineNumber, columnNumber) {
    // VS Code URL protocol
    const protocol = 'vscode://file';

    // Remove any query parameters (including timestamps)
    let cleanPath = filePath.replace(/^(https?:\/\/[^/]+)/, '');

    // Remove any query parameters (including timestamps)
    cleanPath = cleanPath.split('?')[0].split(':')[0];

    // Remove any leading slash
    const normalizedPath = cleanPath.replace(/^\//, '');

    const fullPath = `${window.location.pathname}/${normalizedPath}`;

    // VS Code expects the path to be URL-encoded
    const encodedFilePath = encodeURIComponent(fullPath);

    // Construct the URL
    const url = `${protocol}/${encodedFilePath}`;

    console.log('Original file path:', filePath);
    console.log('Cleaned path:', cleanPath);
    console.log('Normalized path:', normalizedPath);
    console.log('Full path:', fullPath);
    console.log('VS Code URL:', url);

    // Open the URL in a new window/tab
    window.open(url, '_blank');
  }

  render() {
    if (this.state.hasError) {
      const errorLocation =
        this.state.error && this.state.error.stack
          ? this.parseErrorStack(this.state.error.stack)
          : null;

      return (
        <div className="ErrorBoundary">
          <h1>Oops! Something went wrong.</h1>
          <p>
            Error:{' '}
            {this.state.error ? this.state.error.toString() : 'Unknown error'}
          </p>
          {errorLocation && (
            <p
              className="ErrorBoundary__location"
              onClick={() =>
                this.openInIDE(
                  errorLocation.filePath,
                  errorLocation.lineNumber,
                  errorLocation.columnNumber,
                )
              }
              style={{ cursor: 'pointer', textDecoration: 'underline' }}
            >
              Error Location: {errorLocation.filePath}:
              {errorLocation.lineNumber}:{errorLocation.columnNumber}
            </p>
          )}
          <details style={{ whiteSpace: 'pre-wrap' }}>
            <summary>Error Details</summary>
            {this.state.errorInfo
              ? this.state.errorInfo.componentStack
              : 'No error details available'}
          </details>
        </div>
      );
    }

    return this.props.children;
  }
}

const styles = `
  .ErrorBoundary {
    padding: 20px;
    border: 1px solid #f5c6cb;
    border-radius: 4px;
    background-color: #f8d7da;
    color: #721c24;
    margin: 10px 0;
  }

  .ErrorBoundary__location:hover {
    color: #0056b3;
  }
`;

export default ({ children }) => (
  <>
    <style>{styles}</style>
    <ErrorBoundary>{children}</ErrorBoundary>
  </>
);
