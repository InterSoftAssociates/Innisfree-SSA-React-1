import React, { useState, useCallback } from 'react';
import { Link } from 'react-router-dom';

// hooks
import useAuthStore from '@/features/auth/store';
import useResize from '@/hooks/useResize';

// lib
import { PATHS } from '@/routes/paths';

// styles
import './Navbar.scss';

export default function Navbar() {
  const { logout /*, SSOLogout */ } = useAuthStore();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isMobile } = useResize({
    breakpoint: 768,
    onBreakpointChanged: () => {
      setIsMenuOpen(false);
    },
  });

  const toggleMenu = useCallback(() => {
    setIsMenuOpen((prevState) => !prevState);
  }, []);

  const closeMenu = useCallback(() => {
    setIsMenuOpen(false);
  }, []);

  return (
    <nav className="Navbar">
      <div className="Navbar__inner">
        <div className="Navbar__left">
          <Link className="Navbar__logo" to={PATHS.HOME}>
            <img
              className="Navbar__logo-img"
              src="/static/images/Innisfree_AW_Logo_R_rgb.jpg"
              alt="Innisfree Logo"
              width="175"
            />
          </Link>
        </div>
        {isMobile ? (
          <NavbarBurger isMenuOpen={isMenuOpen} toggleMenu={toggleMenu} />
        ) : (
          <div className="Navbar__right">
            <ul className="Navbar__nav-list">
              <NavItems logout={logout} />
            </ul>
          </div>
        )}
      </div>
      {isMobile && (
        <>
          <div className={`Navbar__drawer ${isMenuOpen ? 'open' : ''}`}>
            <ul className="Navbar__nav-list">
              <NavItems logout={logout} />
            </ul>
          </div>
          <div
            className={`Navbar__overlay ${isMenuOpen ? 'open' : ''}`}
            onClick={closeMenu}
          ></div>
        </>
      )}
    </nav>
  );
}

function NavbarBurger({
  isMenuOpen,
  toggleMenu,
}: {
  isMenuOpen: boolean;
  toggleMenu: () => void;
}) {
  return (
    <div
      className={`Navbar__hamburger ${isMenuOpen ? 'open' : ''}`}
      onClick={toggleMenu}
    >
      <span></span>
      <span></span>
      <span></span>
    </div>
  );
}

function NavItems({ logout }: { logout: () => void }) {
  return (
    <>
      <li className="Navbar__nav-item Navbar__nav-item--logo">
        <Link to="/" className="Navbar__nav-link">
          <img
            className="Navbar__logo-img"
            src="/static/images/Innisfree_AW_Logo_R_rgb.jpg"
            alt="Innisfree Logo"
            width="175"
          />
        </Link>
      </li>
      <li className="Navbar__nav-item">
        <Link
          to={PATHS.get('COMPANIES.HISTORICAL_HOLDERS')}
          className="Navbar__nav-link"
        >
          Historical Holders
        </Link>
      </li>

      <li className="Navbar__nav-item">
        <Link
          // target="_blank"
          to={PATHS.get('COMPANIES.HISTORICAL_HOLDERS') + '?ignite=true'}
          className="Navbar__nav-link"
        >
          Historical Holders Ignite
        </Link>
      </li>

      <li className="Navbar__nav-item">
        <Link
          to={PATHS.get('COMPANIES.CURRENT_HOLDERS')}
          className="Navbar__nav-link"
        >
          Current Holders
        </Link>
      </li>

      <li className="Navbar__nav-item">
        <Link
          // target="_blank"
          to={PATHS.get('COMPANIES.CURRENT_HOLDERS') + '?ignite=true'}
          className="Navbar__nav-link"
        >
          Current Holders Ignite
        </Link>
      </li>

      <li className="Navbar__nav-item">
        <Link to={PATHS.get('COMPANIES.REPORTS')} className="Navbar__nav-link">
          Reports
        </Link>
      </li>
      <li className="Navbar__nav-item" id="logout">
        <button onClick={() => logout()} className="Navbar__nav-button">
          Logout
        </button>
      </li>
      {/* <li className="Navbar__nav-item" id="ssoLogout">
        <button onClick={SSOLogout} className="Navbar__nav-button">
          SSOLogout
        </button>
      </li> */}
    </>
  );
}
