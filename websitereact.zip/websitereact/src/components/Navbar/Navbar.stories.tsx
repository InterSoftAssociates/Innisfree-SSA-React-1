import { StoryFn, Meta } from '@storybook/react/types-6-0';
import { MemoryRouter } from 'react-router-dom';
import Navbar from './Navbar';

export default {
  title: 'components/Navbar',
  component: Navbar,
  decorators: [
    (Story) => (
      <MemoryRouter>
        <Story />
      </MemoryRouter>
    ),
  ],
} as Meta;

const Template: StoryFn = () => <Navbar />;

export const Default = Template.bind({});

Default.args = {};
