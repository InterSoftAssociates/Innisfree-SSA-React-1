// hooks
import React from 'react';

// components
import Scrollbar from '../Scrollbar';

// styles
import './Dropdown.scss';

interface SelectOption {
  value: string | number;
  label: string;
  icon?: React.ReactNode;
}

interface DropdownOptionProps {
  option: SelectOption;
  isSelected: boolean;
  onClick: () => void;
}

const DropdownOption: React.FC<DropdownOptionProps> = ({
  option,
  isSelected,
  onClick,
}) => (
  <div
    className={`Dropdown__option ${isSelected ? 'Dropdown__option--selected' : ''}`}
    onClick={onClick}
  >
    {option.icon ? (
      <div className="Dropdown__option-icon">{option.icon}</div>
    ) : null}
    {option.label}
  </div>
);

interface DropdownProps {
  options: SelectOption[];
  selectedValues: (string | number)[];
  onOptionClick: (optionValue: string) => void;
  isOpen: boolean;
  anchor?: 'top' | 'bottom';
}

const Dropdown: React.FC<DropdownProps> = ({
  options,
  selectedValues,
  onOptionClick,
  isOpen,
  anchor = 'bottom',
}) => {
  if (!isOpen) return null;

  return (
    <div className={`Dropdown Dropdown--anchor-${anchor}`}>
      <Scrollbar>
        <div className="Dropdown__options-inner">
          {options.map((option, key) => (
            <DropdownOption
              key={key}
              option={option}
              isSelected={selectedValues.includes(option.value)}
              onClick={() => onOptionClick(option.value)}
            />
          ))}
        </div>
      </Scrollbar>
    </div>
  );
};

export default Dropdown;
