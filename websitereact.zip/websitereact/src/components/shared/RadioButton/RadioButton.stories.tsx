import React, { useState } from 'react';
import { StoryFn, Meta } from '@storybook/react';
import RadioButton, { RadioButtonProps } from './RadioButton';

export default {
  title: 'components/shared/RadioButton',
  component: RadioButton,
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: {
        type: 'select',
        options: ['default', 'outline', 'filled'],
      },
    },
    isDisabled: {
      control: 'boolean',
    },
  },
} as Meta;

const Template: StoryFn<RadioButtonProps> = (args) => {
  const [isChecked, setIsChecked] = useState(args.isChecked);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setIsChecked(event.target.checked);
  };

  return (
    <RadioButton {...args} isChecked={isChecked} onChange={handleChange} />
  );
};

export const Default = Template.bind({});
Default.args = {
  id: 'radio1',
  name: 'radioGroup',
  label: 'Option 1',
  isChecked: false,
  variant: 'default',
  isDisabled: false,
};

export const Checked = Template.bind({});
Checked.args = {
  ...Default.args,
  isChecked: true,
};

export const Outline = Template.bind({});
Outline.args = {
  ...Default.args,
  variant: 'outline',
};

export const Filled = Template.bind({});
Filled.args = {
  ...Default.args,
  variant: 'filled',
};

export const Disabled = Template.bind({});
Disabled.args = {
  ...Default.args,
  isDisabled: true,
};
