import React from 'react';
import classNames from 'classnames';
import './RadioButton.scss';

export interface RadioButtonProps {
  id: string;
  name: string;
  label: string;
  isChecked: boolean;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  variant?: 'default' | 'outline' | 'filled';
  isDisabled?: boolean;
}

export default function RadioButton({
  id,
  name,
  label,
  isChecked,
  onChange,
  variant = 'default',
  isDisabled = false,
}: RadioButtonProps) {
  const radioButtonClasses = classNames('RadioButton', {
    [`RadioButton--${variant}`]: true,
    'RadioButton--checked': isChecked,
    'RadioButton--disabled': isDisabled,
  });

  return (
    <div className={radioButtonClasses}>
      <input
        type="radio"
        id={id}
        name={name}
        checked={isChecked}
        onChange={onChange}
        className="RadioButton__input"
        disabled={isDisabled}
      />
      <label htmlFor={id || name} className="RadioButton__label">
        <span className="RadioButton__custom">
          <span className="RadioButton__inner"></span>
        </span>
        {label}
      </label>
    </div>
  );
}
