// hooks
import React, { memo, useState } from 'react';
import useClickAwayListener from '@/hooks/useClickawayListener';

// components
import { Input, Scrollbar } from '../';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

// icons
import { faSearch, faSpinner } from '@fortawesome/free-solid-svg-icons';
import classNames from 'classnames';

// types
import { InputProps } from '../Input/Input';

// styles
import './AutocompleteInput.scss';

export interface AutocompleteProps extends InputProps {
  isLoading: boolean;
  options: any[];
  onOptionClick: (option: any) => void;
  renderOptionLabel?: (option: any) => string | JSX.Element;
  getOptionKey?: (option: any, idx: number) => any;
  isDisabled?: boolean;
  value: string;
}

function AutocompleteInput({
  isLoading,
  options,
  onOptionClick,
  renderOptionLabel = (option: any) => option.label,
  getOptionKey = (option: any, idx) => option.entityId || idx,
  isDisabled,
  value,
  ...rest
}: AutocompleteProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const dropdownRef = useClickAwayListener<HTMLDivElement>(
    () => setIsOpen(false),
    [isOpen],
  );

  const handleInputFocus = () => setIsOpen(true);

  const handleOptionClick = (option: any) => {
    onOptionClick(option);
    setIsOpen(false);
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'ArrowDown') {
      setSelectedIndex((prevIndex) =>
        Math.min(prevIndex + 1, options.length - 1),
      );
    } else if (event.key === 'ArrowUp') {
      setSelectedIndex((prevIndex) => Math.max(prevIndex - 1, -1));
    } else if (event.key === 'Enter' && selectedIndex !== -1) {
      handleOptionClick(options[selectedIndex]);
    }
  };

  return (
    <div
      className={classNames('AutocompleteInput', {
        'AutocompleteInput--disabled': isDisabled,
        'AutocompleteInput--loading': isLoading,
      })}
    >
      <Input
        icon={faSearch}
        onFocus={handleInputFocus}
        onKeyDown={handleKeyDown}
        isDisabled={isDisabled}
        value={value}
        {...rest}
      />
      {isLoading && (
        <span className="AutocompleteInput__loading">
          <FontAwesomeIcon icon={faSpinner} spin />
        </span>
      )}
      {isOpen && options.length > 0 && (
        <div ref={dropdownRef} className="AutocompleteInput__dropdown-wrapper">
          <Scrollbar className="AutocompleteInput__dropdown">
            <ul>
              {options.map((option, index) => (
                <li
                  key={getOptionKey(option, index)}
                  className={classNames('AutocompleteInput__option', {
                    'AutocompleteInput__option--selected':
                      index === selectedIndex,
                  })}
                  onClick={() => handleOptionClick(option)}
                >
                  {renderOptionLabel(option)}
                </li>
              ))}
            </ul>
          </Scrollbar>
        </div>
      )}
    </div>
  );
}

export default memo(AutocompleteInput);
