import React, { useState } from 'react';
import { Story, Meta } from '@storybook/react';
import AutocompleteInput, { AutocompleteProps } from './AutocompleteInput';

export default {
  title: 'components/shared/AutocompleteInput',
  component: AutocompleteInput,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'An autocomplete input component with customizable options and loading state.',
      },
    },
  },
  argTypes: {
    isLoading: {
      control: 'boolean',
      description: 'Indicates whether the component is in a loading state',
      defaultValue: false,
    },
    options: {
      control: 'object',
      description: 'An array of options to display in the dropdown',
    },
    onOptionClick: {
      action: 'option clicked',
      description: 'Function called when an option is selected',
    },
    renderOptionLabel: {
      description: 'Custom function to render the label for each option',
    },
    getOptionKey: {
      description: 'Custom function to get the key for each option',
    },
    placeholder: {
      control: 'text',
      description: 'Placeholder text for the input',
      defaultValue: 'Type to search...',
    },
    isDisabled: {
      control: 'boolean',
      description: 'Disables the input',
      defaultValue: false,
    },
  },
  decorators: [
    (Story) => (
      <div style={{ height: '250px', overflow: 'visible' }}>
        <Story />
      </div>
    ),
  ],
} as Meta;

const Template: Story<AutocompleteProps> = (args) => {
  const [inputValue, setInputValue] = useState('');
  return (
    <AutocompleteInput
      {...args}
      value={inputValue}
      onChange={(e) => setInputValue(e.target.value)}
      options={args.options.filter((option) =>
        option.label?.toLowerCase?.().includes(inputValue?.toLowerCase()),
      )}
    />
  );
};

export const Default = Template.bind({});
Default.args = {
  isLoading: false,
  options: [
    { entityId: '1', label: 'Apple' },
    { entityId: '2', label: 'Banana' },
    { entityId: '3', label: 'Cherry' },
    { entityId: '4', label: 'Date' },
    { entityId: '5', label: 'Elderberry' },
  ],
  onOptionClick: (option) => console.log('Selected option:', option),
  placeholder: 'Search fruits...',
};

export const Loading = Template.bind({});
Loading.args = {
  ...Default.args,
  isLoading: true,
};

export const NoOptions = Template.bind({});
NoOptions.args = {
  ...Default.args,
  options: [],
};

export const CustomRender = Template.bind({});
CustomRender.args = {
  ...Default.args,
  options: [
    {
      entityId: '1',
      name: 'John Doe',
      email: 'john@example.com',
      label: 'John Doe',
    },
    {
      entityId: '2',
      name: 'Jane Smith',
      email: 'jane@example.com',
      label: 'Jane Smith',
    },
    {
      entityId: '3',
      name: 'Bob Johnson',
      email: 'bob@example.com',
      label: 'Bob Johnson',
    },
  ],
  renderOptionLabel: (option) => (
    <div>
      <strong>{option.name}</strong>
      <br />
      <small>{option.email}</small>
    </div>
  ),
  getOptionKey: (option) => option.entityId,
  placeholder: 'Search users...',
};

export const LongList = Template.bind({});
LongList.args = {
  ...Default.args,
  options: Array.from({ length: 100 }, (_, i) => ({
    entityId: `${i + 1}`,
    label: `Option ${i + 1}`,
  })),
};

const AsyncTemplate: Story<AutocompleteProps> = (args) => {
  const [inputValue, setInputValue] = useState('');
  const [options, setOptions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = async (e) => {
    const value = e.target.value;
    setInputValue(value);
    setIsLoading(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const newOptions = Array.from({ length: 5 }, (_, i) => ({
      entityId: `${i + 1}`,
      label: `${value} result ${i + 1}`,
    }));

    setOptions(newOptions);
    setIsLoading(false);
  };

  return (
    <AutocompleteInput
      {...args}
      value={inputValue}
      onChange={handleInputChange}
      options={options}
      isLoading={isLoading}
    />
  );
};

export const AsyncSearch = AsyncTemplate.bind({});
AsyncSearch.args = {
  onOptionClick: (option) => console.log('Selected option:', option),
  placeholder: 'Type to search...',
};

// Add autodocs
Default.parameters = {
  docs: {
    source: {
      type: 'dynamic',
    },
  },
};
