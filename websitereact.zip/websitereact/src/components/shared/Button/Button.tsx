import React, { memo } from 'react';
import './Button.scss';
import classNames from 'classnames';

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger';
  isRounded?: boolean;
  isDisabled?: boolean;
}

function Button({
  variant = 'primary',
  isRounded = false,
  isDisabled = false,
  className = '',
  children,
  ...props
}: ButtonProps) {
  return (
    <button
      disabled={isDisabled}
      className={classNames('Button', className, {
        'Button--primary': variant === 'primary',
        'Button--secondary': variant === 'secondary',
        'Button--danger': variant === 'danger',
        'Button--rounded': isRounded,
        'Button--disabled': isDisabled,
      })}
      {...props}
    >
      {children}
    </button>
  );
}

export default memo(Button);
