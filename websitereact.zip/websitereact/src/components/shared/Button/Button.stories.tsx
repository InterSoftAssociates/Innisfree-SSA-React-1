import { StoryFn, Meta } from '@storybook/react';
import { fn } from '@storybook/test';
import Button, { ButtonProps } from './Button';

export default {
  title: 'components/shared/Button',
  component: Button,
  args: {
    onClick: () => fn(),
  },
  argTypes: {
    onClick: {
      action: 'clicked',
      description:
        'onClick event handler that will be called when the button is clicked',
    },
    variant: {
      control: {
        type: 'select',
        options: ['primary', 'secondary', 'danger'],
      },
      description: 'the variant of the button',
    },
    isRounded: {
      control: 'boolean',
      default: false,
      description: 'if `true`, the button will be rounded',
    },
    className: {
      control: 'text',
      description: 'additional CSS classes to apply to the button',
      default: '',
    },
    isDisabled: {
      control: 'boolean',
      default: false,
      description: 'if `true`, the button will be disabled',
    },
  },
  tags: ['autodocs'],
} as Meta;

const Template: StoryFn = (args: ButtonProps) => <Button {...args} />;

export const Primary = Template.bind({});
Primary.args = {
  children: 'Primary Button',
  variant: 'primary',
};

export const Secondary = Template.bind({});
Secondary.args = {
  children: 'Secondary Button',
  variant: 'secondary',
};

export const Danger = Template.bind({});
Danger.args = {
  children: 'Danger Button',
  variant: 'danger',
};

export const Rounded = Template.bind({});
Rounded.args = {
  children: 'Rounded Button',
  isRounded: true,
};
