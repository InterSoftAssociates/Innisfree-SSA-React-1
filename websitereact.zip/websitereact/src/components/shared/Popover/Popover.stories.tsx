import Popover, { PopoverProps } from './Popover';
import { StoryFn } from '@storybook/react/*';

export default {
  title: 'components/shared/Popover',
  tags: ['autodocs'],
  argTypes: {
    content: { control: 'text' },
    trigger: { control: 'text' },
    style: { control: 'text' },
  },
};

export const Default: StoryFn = (args: PopoverProps) => (
  <div style={{ position: 'relative' }}>
    <Popover {...args} />
  </div>
);

Default.args = {
  trigger: <div>Trigger</div>,
  content: 'Content',
  style: { width: '200px' },
};
