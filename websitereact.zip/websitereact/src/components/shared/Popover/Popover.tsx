import React, { useState, useRef, useEffect } from 'react';
import './Popover.scss';

export interface PopoverProps {
  trigger: React.ReactNode;
  content: React.ReactNode;
  style?: React.CSSProperties;
}

export default function Popover({
  trigger,
  content,
  style = {},
}: PopoverProps) {
  const [isOpen, setIsOpen] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        popoverRef.current &&
        !popoverRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="Popover" ref={popoverRef} style={style}>
      <div onClick={() => setIsOpen(!isOpen)}>{trigger}</div>
      {isOpen && <div className="Popover__content">{content}</div>}
    </div>
  );
}
