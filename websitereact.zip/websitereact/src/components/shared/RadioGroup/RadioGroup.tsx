import RadioButton from '../RadioButton/RadioButton';
import './RadioGroup.scss';

export interface RadioGroupProps {
  name: string;
  options: Array<{ id: string; label: string; value: string }>;
  value: string;
  onChange: (value: any) => void;
  variant?: 'default' | 'outline' | 'filled';
  label?: string;
}

export default function RadioGroup({
  name,
  options,
  value,
  onChange,
  variant = 'default',
  label = '',
}: RadioGroupProps) {
  return (
    <div className="RadioGroup">
      {label && <label className="RadioGroup__label">{label}</label>}

      {options.map((option) => (
        <RadioButton
          key={option.id}
          id={option.id}
          name={name}
          label={option.label}
          isChecked={value === option.value}
          onChange={() => onChange(option.value)}
          variant={variant}
        />
      ))}
    </div>
  );
}
