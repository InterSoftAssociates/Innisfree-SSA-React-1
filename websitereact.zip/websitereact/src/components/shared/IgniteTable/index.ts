export { default } from './IgniteTable';
