import { StoryFn, Meta } from '@storybook/react';
import IgniteTable, { IgniteTableProps } from './IgniteTable';

export default {
  title: 'components/shared/IgniteTable',
  component: IgniteTable,
  argTypes: {
    pageSize: { control: 'number' },
  },
} as Meta;

// Sample data
const sampleData = [
  { id: 1, name: 'John Doe', age: 30, city: 'New York' },
  { id: 2, name: 'Jane Smith', age: 25, city: 'Los Angeles' },
  { id: 3, name: 'Bob Johnson', age: 35, city: 'Chicago' },
  { id: 4, name: 'Alice Brown', age: 28, city: 'Houston' },
  { id: 5, name: 'Charlie Wilson', age: 40, city: 'Phoenix' },
];

// Sample columns
const sampleColumns = [
  { field: 'name', header: 'Name', dataType: 'string' },
  { field: 'age', header: 'Age', dataType: 'number' },
  { field: 'city', header: 'City', dataType: 'string' },
];

const Template: StoryFn<IgniteTableProps<(typeof sampleData)[0], any>> = (
  args,
) => <IgniteTable {...args} />;

export const Default = Template.bind({});
Default.args = {
  data: sampleData,
  columns: sampleColumns,
  primaryKey: 'id',
  pageSize: 10,
};

export const CustomPageSize = Template.bind({});
CustomPageSize.args = {
  ...Default.args,
  pageSize: 3,
};

export const WithCustomTemplate = Template.bind({});
WithCustomTemplate.args = {
  ...Default.args,
  columns: [
    ...sampleColumns,
    {
      field: 'action',
      header: 'Action',
      dataType: 'string',
      bodyTemplate: (props: { dataContext: any }) => (
        <button
          onClick={() =>
            alert(`Clicked on ${props.dataContext.cell.row.data.name}`)
          }
        >
          Click me
        </button>
      ),
    },
  ],
};
