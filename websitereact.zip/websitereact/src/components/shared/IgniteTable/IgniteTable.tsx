import React, { memo, useCallback } from 'react';
// components
import {
  IgrGrid,
  IgrColumn,
  IgrPaginator,
  IgrCellTemplateContext,
  IgrGridToolbar,
  IgrGridToolbarActions,
  IgrGridToolbarAdvancedFiltering,
} from '@infragistics/igniteui-react-grids';
import Loader from '../Loader';
import Scrollbar from '../Scrollbar';
import TableToolbar from '../TableToolbar';

// lib
import * as XLSX from 'xlsx';

// styles
import './IgniteTable.scss';
import '@infragistics/igniteui-react-grids/grids/combined';
import '@infragistics/igniteui-react-grids/grids/themes/light/bootstrap.css';
import classNames from 'classnames';

export type IgniteColumns = Array<{
  field: string;
  header: string;
  dataType: 'string' | 'number' | 'date';
  isSortable?: boolean;
  formatter?: (value: any) => any;
  bodyTemplate?: (props: { dataContext: IgrCellTemplateContext }) => any;
}>;

export interface IgniteTableProps<T, C> {
  data: T[];
  columns: IgniteColumns;
  primaryKey: keyof T | string;
  pageSize?: number;
  isLoading?: boolean;
  excelFileName?: string;
  rowClasses?:
    | ((row: any) => string)
    | { [key: string]: (row: any) => boolean };
  additionalButtons?: Array<{
    onClick: () => void;
    children: React.ReactNode;
    icon?: any;
  }>;
  size?: 'default' | 'small';
  maxHeight?: any;
  isExcelButtonVisible?: boolean;
  renderToolbar?: () => React.ReactNode;
}

function IgniteTable<T, C>({
  data,
  columns,
  primaryKey,
  pageSize = 10,
  isLoading = false,
  excelFileName = `Export_${Date.now()}`,
  rowClasses,
  additionalButtons = [],
  size = 'default',
  maxHeight = null,
  isExcelButtonVisible = true,
  renderToolbar,
}: IgniteTableProps<T, C>) {
  const gridRef = React.useRef<IgrGrid>(null);

  const handleExport = useCallback(() => {
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
    XLSX.writeFile(workbook, `${excelFileName}.xlsx`);
  }, [data, excelFileName]);

  const containerClasses = classNames('IgniteTable igContainer', {
    'IgniteTable--small': size === 'small',
  });

  return (
    <Scrollbar
      className={containerClasses}
      style={{
        borderRadius: '5px',
        position: 'relative',
      }}
    >
      <Loader isVisible={isLoading} />

      <TableToolbar
        onExportToExcel={handleExport}
        isExcelButtonVisible={isExcelButtonVisible}
        buttons={additionalButtons}
        size={size}
        renderToolbar={renderToolbar}
      />

      <IgrGrid
        ref={gridRef}
        autoGenerate={false}
        data={data}
        primaryKey={primaryKey as string}
        displayDensity={size === 'small' ? 'Compact' : 'Cosy'}
        allowFiltering={true}
        filterMode="ExcelStyleFilter"
        height={
          maxHeight
            ? maxHeight
            : size === 'small'
              ? 'calc(100% - 30px)'
              : 'inherit'
        }
        width="100%"
        moving
        rowClasses={rowClasses}
      >
        <IgrGridToolbar>
          <IgrGridToolbarActions>
            <IgrGridToolbarAdvancedFiltering />
          </IgrGridToolbarActions>
        </IgrGridToolbar>

        <IgrPaginator perPage={pageSize} />
        {columns.map((column) => (
          <IgrColumn
            key={column.field as string}
            field={column.field as string}
            header={column.header}
            dataType={column.dataType}
            sortable={column.isSortable}
            hasSummary={false}
            editable={false}
            resizable={true}
            {...(typeof column.formatter === 'function' && {
              formatter: column.formatter,
            })}
            {...(typeof column.bodyTemplate === 'function' && {
              bodyTemplate: column.bodyTemplate,
            })}
            movable
          />
        ))}
      </IgrGrid>
    </Scrollbar>
  );
}

const MemoizedIgniteTable = memo(IgniteTable);

export default MemoizedIgniteTable;
