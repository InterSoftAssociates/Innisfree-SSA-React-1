import React from 'react';
import VerticalLine from '../VerticalLine';

// lib
import classNames from 'classnames';

// styles
import './VerticalLineStats.scss';

function VerticalLineStats({
  value,
  label,
  variants = [],
}: {
  value: any;
  label: string;
  variants?: string[];
}) {
  return (
    <VerticalLine
      direction="left"
      alignItems="stretch"
      className={classNames(
        'VerticalLineStats',
        ...variants.map((variant) => `VerticalLineStats--${variant}`),
      )}
    >
      <article className="VerticalLineStats__column">
        <h2 className="VerticalLineStats__value">{value}</h2>
        <label className="VerticalLineStats__label">{label}</label>
      </article>
    </VerticalLine>
  );
}

const MemoizedVerticalLineStats = React.memo(VerticalLineStats);
export default MemoizedVerticalLineStats;
