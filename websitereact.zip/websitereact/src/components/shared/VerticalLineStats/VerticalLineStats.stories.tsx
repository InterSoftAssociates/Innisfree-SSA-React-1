import { Meta, StoryObj } from '@storybook/react';
import VerticalLineStats from './VerticalLineStats';

const meta: Meta<typeof VerticalLineStats> = {
  title: 'components/shared/VerticalLineStats',
  component: VerticalLineStats,
  tags: ['autodocs'],
  argTypes: {
    value: {
      control: { type: 'number' },
      description: 'The numerical value to display',
    },
    label: {
      control: { type: 'text' },
      description: 'The label describing the value',
    },
  },
};

export default meta;

type Story = StoryObj<typeof VerticalLineStats>;

export const Default: Story = {
  args: {
    value: 42,
    label: 'Answer to Life',
  },
};

export const LargeNumber: Story = {
  args: {
    value: 1000000,
    label: 'Population',
  },
};

export const Percentage: Story = {
  args: {
    value: 75.5,
    label: 'Completion Rate',
  },
  render: (args) => <VerticalLineStats {...args} value={`${args.value}%`} />,
};

export const CurrencyValue: Story = {
  args: {
    value: 1234.56,
    label: 'Total Revenue',
  },
  render: (args) => (
    <VerticalLineStats {...args} value={`$${args.value.toLocaleString()}`} />
  ),
};

export const MultipleStats: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '20px' }}>
      <VerticalLineStats value={500} label="Users" />
      <VerticalLineStats value={10000} label="Page Views" />
      <VerticalLineStats value={95} label="Satisfaction Rate" />
    </div>
  ),
};
