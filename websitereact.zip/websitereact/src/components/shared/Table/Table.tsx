import React, { memo, useState } from 'react';
import useTable from '@/hooks/useTable';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import TablePagination from '../TablePagination';
import TableToolbar from '../TableToolbar';
import FilterInput from '../FilterInput';
import Loader from '../Loader';
import Popover from '../Popover';

// lib
import classNames from 'classnames';

// styles
import './Table.scss';

const ROW_HEIGHT = 42;

export interface ColumnDef<T> {
  key: string | keyof T;
  header: string;
  filter?: 'text' | 'date' | 'none' | 'number' | undefined;
  render?: (value: any, row: T, index: number) => React.ReactNode;
  columnWidth?: string;
}

export interface TableProps<T> {
  data: T[];
  columns: ColumnDef<T>[];
  initialSort?: keyof T | undefined;
  initialSortDirection?: 'asc' | 'desc';
  initialLimit?: number;
  isLoading?: boolean;
  maxHeight?: number | string;
  toolbarButtons?: Array<{
    onClick: () => void;
    children: React.ReactNode;
  }>;
  fileName?: string;
  isExcelVisible?: boolean;
  size?: 'default' | 'small';
}

function Table<T>({
  data = [],
  isLoading = false,
  columns: initialColumns,
  initialSort,
  initialSortDirection,
  initialLimit,
  maxHeight = 400,
  toolbarButtons = [],
  fileName,
  isExcelVisible = true,
  size = 'default',
}: TableProps<T>) {
  const {
    sortKey,
    sortDirection,
    currentPage,
    limit,
    totalPages,
    canGoBack,
    canGoNext,
    goToNextPage,
    goToPreviousPage,
    goToFirstPage,
    goToLastPage,
    handleSort,
    setLimit,
    handleExportToExcel,
    handleScroll,
    filteredData,
    handleFilterChange,
    isFiltering,
    visibleData,
    onDragEnd,
    startIndex,
    containerRef,
    tableRef,
    columns,
    toggleColumnVisibility,
    adjustedColumnWidths,
    adjustedTableWidth,
    isColumnVisible,
  } = useTable<T>({
    data,
    initialSort,
    initialSortDirection,
    initialLimit,
    initialColumns,
    rowHeight: ROW_HEIGHT,
    maxHeight,
    fileName,
  });

  const tableClasses = classNames('Table', {
    'Table--small': size === 'small',
  });

  return (
    <div className="Table__container" ref={containerRef}>
      <TableToolbar
        onExportToExcel={handleExportToExcel}
        buttons={toolbarButtons}
        isExcelButtonVisible={isExcelVisible}
        size={size}
      />
      {(isFiltering || isLoading) && <Loader />}
      <div
        className={classNames('Table__outer-wrapper', {
          'Table__outer-wrapper--small': size === 'small',
        })}
        style={{ height: maxHeight }}
        onScroll={handleScroll}
      >
        <div
          className="Table__inner-wrapper"
          style={{ width: adjustedTableWidth }}
        >
          <table className={tableClasses} style={{ width: adjustedTableWidth }}>
            <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="table-header" direction="horizontal">
                {(provided) => (
                  <thead ref={provided.innerRef} {...provided.droppableProps}>
                    <tr className="Table__header">
                      {columns.map((column, index) => (
                        <Draggable
                          key={column.key as string}
                          draggableId={column.key as string}
                          index={index}
                        >
                          {(provided, snapshot) => (
                            <TableHeaderCell
                              column={column}
                              index={index}
                              handleSort={handleSort}
                              sortKey={sortKey}
                              sortDirection={sortDirection}
                              handleFilterChange={handleFilterChange}
                              isColumnVisible={isColumnVisible}
                              toggleColumnVisibility={toggleColumnVisibility}
                              adjustedColumnWidths={adjustedColumnWidths}
                              snapshot={snapshot}
                              provided={provided}
                            />
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </tr>
                  </thead>
                )}
              </Droppable>
            </DragDropContext>
            <tbody ref={tableRef}>
              {visibleData.map((item, index) => (
                <tr
                  key={startIndex + index}
                  className={classNames('Table__row', {
                    'Table__row--small': size === 'small',
                    'Table__row--positive': item.change > 0,
                    'Table__row--negative': item.change < 0,
                  })}
                  style={{
                    height:
                      size === 'small'
                        ? `${ROW_HEIGHT * 0.8}px`
                        : `${ROW_HEIGHT}px`,
                    transform: `translateY(${(startIndex + index) * (size === 'small' ? ROW_HEIGHT * 0.8 : ROW_HEIGHT)}px)`,
                  }}
                >
                  {columns.map((column, colIndex) => (
                    <td
                      key={column.key as string}
                      className={classNames('Table__cell', {
                        'Table__cell--hidden-column': !isColumnVisible(
                          column.key,
                        ),
                      })}
                      style={{
                        width: `${adjustedColumnWidths[colIndex]}px`,
                        minWidth: `${adjustedColumnWidths[colIndex]}px`,
                        maxWidth: `${adjustedColumnWidths[colIndex]}px`,
                        padding: !isColumnVisible(column.key) ? 0 : undefined,
                        border: !isColumnVisible(column.key)
                          ? 'none'
                          : undefined,
                      }}
                    >
                      {isColumnVisible(column.key) &&
                        (column.render
                          ? column.render(
                              item[column.key],
                              item,
                              startIndex + index,
                            )
                          : String(item[column.key]) === 'null'
                            ? ''
                            : String(item[column.key]))}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <TablePagination
        currentPage={currentPage}
        totalPages={totalPages}
        limit={limit}
        total={filteredData.length}
        canGoBack={canGoBack}
        canGoNext={canGoNext}
        onNextPage={goToNextPage}
        onPreviousPage={goToPreviousPage}
        onFirstPage={goToFirstPage}
        onLastPage={goToLastPage}
        onLimitChange={setLimit}
        size={size}
      />
    </div>
  );
}

const TableHeaderCell: React.FC<{
  column: ColumnDef<any>;
  index: number;
  handleSort: any;
  sortKey: any;
  sortDirection: 'asc' | 'desc' | undefined;
  handleFilterChange: any;
  isColumnVisible: any;
  toggleColumnVisibility: any;
  adjustedColumnWidths: number[];
  snapshot: any;
  provided: any;
}> = ({
  column,
  index,
  handleSort,
  sortKey,
  sortDirection,
  handleFilterChange,
  isColumnVisible,
  toggleColumnVisibility,
  adjustedColumnWidths,
  snapshot,
  provided,
}) => {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <th
      ref={provided.innerRef}
      {...provided.draggableProps}
      {...provided.dragHandleProps}
      className={classNames('Table__header-cell', {
        'Table__header-cell--sorted-asc':
          sortKey === column.key && sortDirection === 'asc',
        'Table__header-cell--sorted-desc':
          sortKey === column.key && sortDirection === 'desc',
        'Table__header-cell--dragging': snapshot.isDragging,
        'Table__header-cell--hidden-column': !isColumnVisible(column.key),
        'Table__header-cell--active': isFocused,
      })}
      style={{
        ...provided.draggableProps.style,
        width: `${adjustedColumnWidths[index]}px`,
        minWidth: `${adjustedColumnWidths[index]}px`,
        maxWidth: `${adjustedColumnWidths[index]}px`,
        padding: !isColumnVisible(column.key) ? 0 : undefined,
        border: !isColumnVisible(column.key) ? 'none' : undefined,
      }}
    >
      <div className="Table__header-cell__th-content">
        <div onClick={() => handleSort(column.key)}>
          {column.header}
          <span className="Table__header-cell__sort-indicator"></span>
        </div>
        <Popover
          trigger={<span>⚙️</span>}
          content={
            <button onClick={() => toggleColumnVisibility(column.key)}>
              {!isColumnVisible(column.key) ? 'Show Column' : 'Hide Column'}
            </button>
          }
        />
      </div>
      {column.filter &&
        column.filter !== 'none' &&
        isColumnVisible(column.key) && (
          <FilterInput
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            identifier={column.key as string}
            type={column.filter}
            placeholder={`Filter ${column.header}...`}
            onFilterChange={handleFilterChange}
            defaultFilter={column.filter === 'date' ? 'on' : 'contains'}
          />
        )}
    </th>
  );
};

export default memo(Table);
