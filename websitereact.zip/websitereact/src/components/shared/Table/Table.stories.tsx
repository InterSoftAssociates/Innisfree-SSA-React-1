import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import Table, { TableProps } from './Table';

export default {
  title: 'components/shared/Table',
  component: Table,
  tags: ['autodocs'],
  parameters: {
    controls: { expanded: true },
  },
} as Meta;

interface User {
  id: number;
  name: string;
  email: string;
  age: number;
  birthdate: string;
}

const users: User[] = Array(50)
  .fill(null)
  .map((_, index) => ({
    id: index + 1,
    name: `User ${index + 1}`,
    email: `user${index + 1}@example.com`,
    age: 20 + Math.floor(Math.random() * 50),
    birthdate: new Date(
      1970 + Math.floor(Math.random() * 30),
      Math.floor(Math.random() * 12),
      Math.floor(Math.random() * 28) + 1,
    )
      .toISOString()
      .split('T')[0],
  }));

const columns: {
  key: keyof User;
  header: string;
  filter?: 'text' | 'date' | undefined;
  render?: (value: any) => React.ReactNode;
}[] = [
  { key: 'id', header: 'ID', filter: 'text' },
  { key: 'name', header: 'Name', filter: 'text' },
  { key: 'email', header: 'Email', filter: 'text' },
  { key: 'age', header: 'Age', filter: 'text' },
  { key: 'birthdate', header: 'Birth Date', filter: 'date' },
];

const Template: StoryFn<TableProps<User>> = (args) => <Table<User> {...args} />;

export const Default = Template.bind({});
Default.args = {
  data: users,
  columns: columns,
  initialSort: 'name',
  initialSortDirection: 'asc',
  initialLimit: 10,
  isLoading: false,
};

export const Loading = Template.bind({});
Loading.args = {
  ...Default.args,
  isLoading: true,
};

export const EmptyTable = Template.bind({});
EmptyTable.args = {
  ...Default.args,
  data: [],
};

export const CustomRendering = Template.bind({});
CustomRendering.args = {
  ...Default.args,
  columns: [
    ...columns,
    {
      key: 'actions' as keyof User,
      header: 'Actions',
      render: () => (
        <button onClick={() => alert('Action clicked!')}>Click me</button>
      ),
    },
  ],
};

export const ShortTable = Template.bind({});
ShortTable.args = {
  ...Default.args,
  maxHeight: 300,
};

export const TallTable = Template.bind({});
TallTable.args = {
  ...Default.args,
  maxHeight: 800,
};
