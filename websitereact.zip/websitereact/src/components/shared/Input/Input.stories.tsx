import { StoryFn, Meta } from '@storybook/react';
import Input, { InputProps } from './Input';
import { faUser, faLock } from '@fortawesome/free-solid-svg-icons';

export default {
  title: 'components/shared/Input',
  component: Input,
  tags: ['autodocs'],
  argTypes: {
    icon: {
      control: {
        type: 'select',
        options: [faUser],
      },
      description: 'the icon to display on the left side of the input',
    },
    placeholder: {
      control: 'text',
      description: 'the placeholder text for the input',
      default: '',
    },
    type: {
      control: {
        type: 'select',
        options: ['text', 'password'],
      },
      description: 'the type of the input field',
    },
    isDisabled: {
      control: 'boolean',
      description: 'whether the input is disabled',
      default: false,
    },
  },
} as Meta<InputProps>;

const Template: StoryFn<InputProps> = (args) => <Input {...args} />;

export const WithIcon = Template.bind({});
WithIcon.args = {
  icon: faUser,
  placeholder: 'Username',
  type: 'text',
};

export const WithoutIcon = Template.bind({});
WithoutIcon.args = {
  placeholder: 'Enter text',
  type: 'text',
};

export const PasswordInput = Template.bind({});
PasswordInput.args = {
  icon: faLock,
  placeholder: 'Enter password',
  type: 'password',
};
