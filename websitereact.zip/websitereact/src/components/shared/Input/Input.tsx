// hooks
import React, { memo, useCallback, useState } from 'react';

// components
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

// icons
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';

// lib
import classNames from 'classnames';

// styles
import './Input.scss';

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  icon?: IconDefinition;
  isDisabled?: boolean;
  onIconClick?: (args: any) => void;
}

function Input({
  icon,
  className = '',
  type = 'text',
  isDisabled = false,
  onIconClick,
  ...rest
}: InputProps) {
  const [isPasswordShowing, setIsPasswordShowing] = useState(false);

  const togglePasswordVisibility = useCallback(() => {
    setIsPasswordShowing((prevState) => !prevState);
  }, []);

  const inputType = type === 'password' && isPasswordShowing ? 'text' : type;

  return (
    <div
      className={classNames('Input', className, {
        'Input--disabled': isDisabled,
      })}
    >
      {icon && (
        <span
          className="Input__icon"
          onClick={onIconClick}
          style={{
            display: 'flex',
            cursor: onIconClick ? 'pointer' : 'default',
            zIndex: onIconClick ? 4 : 1,
          }}
        >
          <FontAwesomeIcon icon={icon} />
        </span>
      )}
      <input
        className="Input__field"
        type={inputType}
        disabled={isDisabled}
        {...rest}
      />
      {type === 'password' && (
        <button
          type="button"
          className="Input__password-toggle"
          onClick={togglePasswordVisibility}
        >
          <FontAwesomeIcon icon={isPasswordShowing ? faEyeSlash : faEye} />
        </button>
      )}
    </div>
  );
}

export default memo(Input);
