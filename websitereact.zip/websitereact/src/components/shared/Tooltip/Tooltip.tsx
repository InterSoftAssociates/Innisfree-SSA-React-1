import React, { memo, useMemo } from 'react';
import { Tooltip as ReactTooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css';

type TooltipPlacement =
  | 'top'
  | 'top-start'
  | 'top-end'
  | 'right'
  | 'right-start'
  | 'right-end'
  | 'bottom'
  | 'bottom-start'
  | 'bottom-end'
  | 'left'
  | 'left-start'
  | 'left-end';

export interface TooltipProps {
  anchorClass?: string;
  title: string;
  placement?: TooltipPlacement;
  zIndex?: number;
  children?: React.ReactNode;
  isVisible?: boolean;
  anchorSelect?: string;
}

const generateRandomClass = () =>
  `Tooltip__anchor-${Math.random().toString(36).substring(7)}`;

function Tooltip({
  anchorClass = '',
  anchorSelect = '',
  title = '',
  placement = 'top',
  zIndex = 10,
  children,
  isVisible = true,
}: TooltipProps) {
  const innerAnchorClass = useMemo(() => {
    if (!anchorClass) {
      return generateRandomClass();
    }

    return anchorClass;
  }, [anchorClass]);

  if (!isVisible) {
    return children;
  }

  return (
    <>
      <div className={`${innerAnchorClass} ${anchorSelect.replace('.', '')}`}>
        {children}
      </div>
      <ReactTooltip
        anchorSelect={anchorSelect ? anchorSelect : `.${innerAnchorClass}`}
        content={title}
        style={{
          zIndex,
          fontSize: '0.8rem',
          textTransform: 'unset',
          fontFamily: 'Inter, sans-serif',
        }}
        place={placement}
      />
    </>
  );
}

export default memo(Tooltip);
