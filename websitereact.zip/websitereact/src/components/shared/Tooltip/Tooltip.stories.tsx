import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import Tooltip, { TooltipProps } from './Tooltip';

const meta: Meta = {
  title: 'components/shared/Tooltip',
  component: Tooltip,
  tags: ['autodocs'],
  argTypes: {
    title: {
      control: { type: 'text' },
      description: 'The content of the tooltip',
    },
    placement: {
      control: { type: 'select' },
      options: [
        'top',
        'top-start',
        'top-end',
        'right',
        'right-start',
        'right-end',
        'bottom',
        'bottom-start',
        'bottom-end',
        'left',
        'left-start',
        'left-end',
      ],
      description: 'The placement of the tooltip',
    },
    zIndex: {
      control: { type: 'number' },
      description: 'The z-index of the tooltip',
    },
    children: {
      control: { type: 'text' },
      description: 'The element wrapped by the tooltip',
    },
  },
  parameters: {
    docs: {
      description: {
        component:
          'A tooltip component that displays additional information on hover or focus.',
      },
    },
  },
};

export default meta;

const Template: StoryFn<TooltipProps> = (args) => (
  <div
    style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '300px',
    }}
  >
    <Tooltip {...args} />
  </div>
);

export const Default = Template.bind({});
Default.args = {
  title: 'Default Tooltip',
  children: <button>Hover over me</button>,
};

export const TopPlacement = Template.bind({});
TopPlacement.args = {
  title: 'Tooltip on Top',
  placement: 'top',
  children: <button>Hover over me</button>,
};

export const RightPlacement = Template.bind({});
RightPlacement.args = {
  title: 'Tooltip on Right',
  placement: 'right',
  children: <button>Hover over me</button>,
};

export const BottomPlacement = Template.bind({});
BottomPlacement.args = {
  title: 'Tooltip on Bottom',
  placement: 'bottom',
  children: <button>Hover over me</button>,
};

export const LeftPlacement = Template.bind({});
LeftPlacement.args = {
  title: 'Tooltip on Left',
  placement: 'left',
  children: <button>Hover over me</button>,
};

export const CustomZIndex = Template.bind({});
CustomZIndex.args = {
  title: 'Tooltip with Custom Z-Index',
  zIndex: 100,
  children: <button>Hover over me</button>,
};
