import React, { memo } from 'react';
import ReactDOM from 'react-dom';
import Button, { ButtonProps } from '../Button/Button';
import './Modal.scss';

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: string;
  isCloseButtonVisible?: boolean;
  actionButtons?: ButtonProps[];
  styles?: {
    container?: React.CSSProperties;
    content?: React.CSSProperties;
  };
}

function Modal({
  isOpen,
  onClose,
  isCloseButtonVisible,
  children,
  title,
  actionButtons = [],
  styles = {
    container: {},
    content: {},
  },
}: ModalProps) {
  if (!isOpen) return null;

  const modalContent = (
    <div className="Modal" style={styles.container}>
      <div className="Modal__overlay" onClick={onClose}></div>
      <div className="Modal__content" style={styles.content}>
        <div className="Modal__header">
          {title && <h2 className="Modal__title">{title}</h2>}
          {isCloseButtonVisible && (
            <button
              className="Modal__close-button"
              onClick={onClose}
              aria-label="Close"
            >
              &times;
            </button>
          )}
        </div>
        <div className="Modal__body">{children}</div>

        {actionButtons.length > 0 && (
          <footer className="Modal__footer">
            {actionButtons.map((button, index) => (
              <Button
                key={index}
                className="Modal__action-button"
                onClick={button.onClick}
                {...button}
              >
                {button.children}
              </Button>
            ))}
          </footer>
        )}
      </div>
    </div>
  );

  return ReactDOM.createPortal(modalContent, document.body);
}

export default memo(Modal);
