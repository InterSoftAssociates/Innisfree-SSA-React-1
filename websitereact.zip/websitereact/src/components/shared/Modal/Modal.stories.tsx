import { StoryFn, Meta } from '@storybook/react/types-6-0';
import { action } from '@storybook/addon-actions';
import Modal, { ModalProps } from './Modal';

export default {
  title: 'components/shared/Modal',
  component: Modal,
  tags: ['autodocs'],
  argTypes: {
    isOpen: { control: 'boolean' },
    onClose: { action: 'closed' },
    title: { control: 'text' },
    isCloseButtonVisible: { control: 'boolean', default: true },
  },
  decorators: [
    (Story) => (
      <div style={{ height: '100vh', position: 'relative' }}>
        <div style={{ padding: '20px' }}>
          <h1>Page Content</h1>
          <p>This is the content behind the modal.</p>
        </div>
        <Story />
      </div>
    ),
  ],
} as Meta;

const Template: StoryFn<ModalProps> = (args) => <Modal {...args} />;

export const Default = Template.bind({});
Default.args = {
  isOpen: true,
  onClose: action('modal closed'),
  title: 'Default Modal',
  children: <p>This is the content of the modal.</p>,
  isCloseButtonVisible: true,
};

export const WithoutTitle = Template.bind({});
WithoutTitle.args = {
  ...Default.args,
  title: undefined,
};

export const WithoutCloseButton = Template.bind({});
WithoutCloseButton.args = {
  ...Default.args,
  isCloseButtonVisible: false,
};

export const WithLongContent = Template.bind({});
WithLongContent.args = {
  ...Default.args,
  title: 'Modal with Long Content',
  children: (
    <>
      <p>This modal has a lot of content to demonstrate scrolling behavior.</p>
      {Array(20)
        .fill(null)
        .map((_, i) => (
          <p key={i}>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          </p>
        ))}
    </>
  ),
};

export const WithForm = Template.bind({});
WithForm.args = {
  ...Default.args,
  title: 'Modal with Form',
  children: (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        action('form submitted')(e);
      }}
    >
      <div>
        <label htmlFor="name">Name:</label>
        <input id="name" type="text" />
      </div>
      <div>
        <label htmlFor="email">Email:</label>
        <input id="email" type="email" />
      </div>
      <button type="submit">Submit</button>
    </form>
  ),
};

export const Closed = Template.bind({});
Closed.args = {
  ...Default.args,
  isOpen: false,
};
