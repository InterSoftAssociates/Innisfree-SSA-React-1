import React from 'react';

// components
import Card from '../Card';
import ToolbarButton from '../ToolbarButton';
import { faDownload } from '@fortawesome/free-solid-svg-icons';

// styles
import './TableToolbar.scss';

interface TableToolbarProps {
  onExportToExcel: () => void;
  buttons?: Array<{
    onClick: () => void;
    children: React.ReactNode;
    icon?: any;
  }>;
  isExcelButtonVisible?: boolean;
  size?: 'default' | 'small';
  renderToolbar?: () => React.ReactNode;
}

const TableToolbar: React.FC<TableToolbarProps> = ({
  onExportToExcel,
  isExcelButtonVisible = true,
  buttons = [],
  size = 'default',
  renderToolbar,
}) => {
  return (
    <Card
      containerClassName={
        'TableToolbar' + (size === 'small' ? ' TableToolbar--small' : '')
      }
      contentClassName="TableToolbar__content"
    >
      {renderToolbar ? (
        renderToolbar()
      ) : (
        <>
          {isExcelButtonVisible && (
            <ToolbarButton onClick={onExportToExcel} icon={faDownload}>
              Export to Excel
            </ToolbarButton>
          )}
          {buttons.map((button, index) => (
            <ToolbarButton
              key={index}
              onClick={button.onClick}
              icon={button.icon}
            >
              {button.children}
            </ToolbarButton>
          ))}
        </>
      )}
    </Card>
  );
};

export default TableToolbar;
