import React, { memo } from 'react';
import './Loader.scss';

export interface LoaderProps {
  isVisible?: boolean;
  isFixed?: boolean;
}

const Loader: React.FC<LoaderProps> = ({
  isVisible = true,
  isFixed = false,
}) => {
  if (!isVisible) return null;

  return (
    <div
      className="Loader"
      style={{
        position: isFixed ? 'fixed' : 'absolute',
      }}
    >
      <div className="Loader__spinner"></div>
    </div>
  );
};

export default memo(Loader);
