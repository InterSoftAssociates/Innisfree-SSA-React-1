import { StoryFn, Meta } from '@storybook/react/types-6-0';
import Loader, { LoaderProps } from './Loader';
import Card from '../Card';

export default {
  title: 'components/shared/Loader',
  component: Loader,
  argTypes: {
    isVisible: { control: 'boolean' },
  },
  tags: ['autodocs'],
} as Meta;

const Template: StoryFn<LoaderProps> = (args) => (
  <div
    style={{ minHeight: '200px', minWidth: '200px', background: 'transparent' }}
  >
    <Loader {...args} />
  </div>
);
const CardTemplate: StoryFn<LoaderProps> = (args) => (
  <Card>
    <Loader {...args} />
  </Card>
);

export const Visible = Template.bind({});
Visible.args = {
  isVisible: true,
};

export const Hidden = Template.bind({});
Hidden.args = {
  isVisible: false,
};

export const VisibleOnCard = CardTemplate.bind({});
VisibleOnCard.args = {
  isVisible: true,
};

export const HiddenOnCard = CardTemplate.bind({});
HiddenOnCard.args = {
  isVisible: false,
};
