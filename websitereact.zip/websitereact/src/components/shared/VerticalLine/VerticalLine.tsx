import React from 'react';
import classNames from 'classnames';

interface VerticalLineProps {
  direction?: 'left' | 'right';
  color?: string;
  paddingLeft?: string;
  paddingTop?: string;
  paddingBottom?: string;
  styles?: React.CSSProperties;
  children?: React.ReactNode;
  className?: string;
  alignItems?: string;
}

function VerticalLine({
  direction = 'left',
  color = '#6ebfd4',
  paddingLeft = '5px',
  paddingTop = '12px',
  paddingBottom = '12px',
  alignItems = 'center',
  styles,
  children,
  className,
  ...rest
}: VerticalLineProps) {
  return (
    <div
      className={classNames(
        'VerticalLine',
        `VerticalLine--${direction}`,
        className,
      )}
      style={{
        display: 'flex',
        alignItems,
        flexDirection:
          direction === 'left'
            ? 'row'
            : direction === 'right'
              ? 'row-reverse'
              : direction === 'top'
                ? 'column'
                : 'column-reverse',
        gap: '5px',
        paddingLeft,
        ...styles,
      }}
      {...rest}
    >
      <div
        className="VerticalLine__line"
        style={{
          backgroundColor: color,
          borderLeft: `3px solid ${color}`,
          display: 'flex',
          paddingTop,
          paddingBottom,
        }}
      />
      {children}
    </div>
  );
}

const MemoizedVerticalLine = React.memo(VerticalLine);
export default MemoizedVerticalLine;
