import type { Meta, StoryObj } from '@storybook/react';
import VerticalLine from './VerticalLine';

const meta: Meta<typeof VerticalLine> = {
  title: 'components/shared/VerticalLine',
  component: VerticalLine,
  tags: ['autodocs'],
  argTypes: {
    direction: {
      description: 'The direction of the vertical line',
      control: { type: 'radio' },
      options: ['left', 'right'],
    },
    color: {
      description: 'The color of the vertical line',
      control: { type: 'color' },
    },
    paddingLeft: {
      description: 'The left padding of the content',
      control: { type: 'text' },
    },
    styles: {
      description: 'Additional CSS styles to apply to the component',
    },
    children: {
      description: 'The content to be rendered inside the component',
    },
    className: {
      description: 'Additional CSS class names to apply to the component',
    },
  },
};

export default meta;

type Story = StoryObj<typeof VerticalLine>;

export const Default: Story = {
  args: {
    children: 'This is a vertical line component',
  },
};

export const RightAligned: Story = {
  args: {
    direction: 'right',
    children: 'This is a right-aligned vertical line',
  },
};

export const CustomColor: Story = {
  args: {
    color: '#ff0000',
    children: 'This vertical line has a custom color',
  },
};

export const CustomPadding: Story = {
  args: {
    paddingLeft: '20px',
    children: 'This vertical line has custom padding',
  },
};

export const WithCustomStyles: Story = {
  args: {
    styles: { backgroundColor: '#f0f0f0', padding: '10px' },
    children: 'This vertical line has custom styles',
  },
};
