import { memo, ReactNode } from 'react';
import './Card.scss';
import classNames from 'classnames';

export interface CardProps {
  children: ReactNode;
  containerClassName?: string;
  contentClassName?: string;
  headerTitle?: string;
  variants?: string[];
  Component?:
    | 'div'
    | 'section'
    | 'article'
    | 'aside'
    | 'main'
    | 'header'
    | 'footer'
    | React.ElementType;
  [key: string]: any;
}

function Card({
  children,
  containerClassName = '',
  contentClassName = '',
  headerTitle,
  variants = [],
  Component = 'div',
  ...rest
}: CardProps) {
  return (
    <Component
      className={classNames(
        'Card',
        containerClassName,
        ...variants.map((variant) => `Card--${variant}`),
      )}
      {...rest}
    >
      {headerTitle && (
        <div className="Card__header">
          <h2 className="Card__header__title">{headerTitle}</h2>
        </div>
      )}
      <div className={`Card__content ${contentClassName}`}>{children}</div>
    </Component>
  );
}

export default memo(Card);
