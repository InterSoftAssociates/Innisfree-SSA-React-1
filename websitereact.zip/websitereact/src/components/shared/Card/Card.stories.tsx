import { StoryFn, Meta } from '@storybook/react';
import Card, { CardProps } from './Card';

export default {
  title: 'components/shared/Card',
  component: Card,
  tags: ['autodocs'],
  argTypes: {
    children: {
      control: 'text',
      description: 'The content to be rendered inside the card',
    },
    headerTitle: {
      control: 'text',
      description: 'The title to be rendered inside the card header',
    },
    containerClassName: {
      control: 'text',
      description: 'Additional CSS class names to be applied to the card',
    },
    contentClassName: {
      control: 'text',
      description:
        'Additional CSS class names to be applied to the card content',
    },
  },
} as Meta<CardProps>;

const _AutoDocsTemplate: StoryFn<CardProps> = (args) => (
  <Card
    {...args}
    children={
      // render children as html so that when we pass a string, it will render as html if we enter <button>Click me!</button> or things like that in the storybook autodocs
      <div dangerouslySetInnerHTML={{ __html: args.children as string }} />
    }
  />
);

const Template2: StoryFn<CardProps> = (args: CardProps) => (
  <Card {...args}>{args.children}</Card>
);

export const Default = _AutoDocsTemplate.bind({});
Default.args = {
  children: `<p>This is a default card with some content.</p>`,
};

export const WithHeader = Template2.bind({});
WithHeader.args = {
  children: <p>This card has a header.</p>,
  headerTitle: 'Card Header',
};

export const WithCustomClass = Template2.bind({});
WithCustomClass.args = {
  children: <p>This card has a custom class applied.</p>,
  containerClassName: 'custom-card-class',
};

export const WithComplexContent = Template2.bind({});
WithComplexContent.args = {
  children: (
    <>
      <h2>Card Title</h2>
      <p>This is a paragraph inside the card.</p>
      <button>Click me!</button>
    </>
  ),
};
