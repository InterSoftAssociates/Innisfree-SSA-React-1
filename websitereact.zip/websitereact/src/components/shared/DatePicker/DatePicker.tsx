// hooks
import { useState, useRef, useEffect, useCallback, useMemo } from 'react';

// components
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faCalendar,
  faChevronLeft,
  faChevronRight,
} from '@fortawesome/free-solid-svg-icons';
import Input from '../Input';

// lib
import { format, parse, isValid, isBefore, isAfter } from 'date-fns';

// styles
import './DatePicker.scss';

export interface DatePickerProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  minDate?: string;
  maxDate?: string;
  dateFormat?: string;
  anchor?: 'top' | 'bottom';
  onOpen?: () => void;
  onClose?: () => void;
}

export default function DatePicker({
  value,
  onChange,
  placeholder,
  disabled = false,
  minDate,
  maxDate,
  dateFormat = 'MM-dd-yyyy',
  anchor = 'bottom',
  onOpen,
  onClose,
}: DatePickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        wrapperRef.current &&
        !wrapperRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [wrapperRef]);

  const getDaysInMonth = useCallback((date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const days = new Date(year, month + 1, 0).getDate();
    const firstDay = new Date(year, month, 1).getDay();
    return { days, firstDay };
  }, []);

  const { days, firstDay } = useMemo(
    () => getDaysInMonth(currentDate),
    [getDaysInMonth, currentDate],
  );

  const isDateSelectable = useCallback(
    (date: Date) => {
      if (minDate && isBefore(date, parse(minDate, dateFormat, new Date()))) {
        return false;
      }
      if (maxDate && isAfter(date, parse(maxDate, dateFormat, new Date()))) {
        return false;
      }
      return true;
    },
    [minDate, maxDate, dateFormat],
  );

  const handleDateClick = useCallback(
    (day: number) => {
      const newDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth(),
        day,
      );
      if (isDateSelectable(newDate)) {
        onChange(format(newDate, dateFormat));
        setIsOpen(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [currentDate, dateFormat, isDateSelectable],
  );

  const changeMonth = useCallback(
    (increment: number) => {
      setCurrentDate(
        new Date(
          currentDate.getFullYear(),
          currentDate.getMonth() + increment,
          1,
        ),
      );
    },
    [currentDate],
  );

  const formattedValue = useMemo(() => {
    return value
      ? format(parse(value, dateFormat, new Date()), dateFormat)
      : '';
  }, [value, dateFormat]);

  useEffect(() => {
    if (isOpen) {
      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
      onOpen && onOpen();
    } else {
      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
      onClose && onClose();
    }
  }, [isOpen, onOpen, onClose]);

  return (
    <div className="DatePicker" ref={wrapperRef}>
      <Input
        onIconClick={() => !disabled && setIsOpen(!isOpen)}
        icon={faCalendar}
        value={formattedValue}
        onChange={(e) => {
          const date = parse(e.target.value, dateFormat, new Date());
          if (isValid(date) && isDateSelectable(date)) {
            onChange(format(date, dateFormat));
          }
        }}
        placeholder={placeholder}
        onClick={() => !disabled && setIsOpen(!isOpen)}
        readOnly
        disabled={disabled}
      />
      {isOpen && !disabled && (
        <div className={`DatePicker__calendar DatePicker__calendar--${anchor}`}>
          <div className="DatePicker__header">
            <button onClick={() => changeMonth(-1)}>
              <FontAwesomeIcon icon={faChevronLeft} />
            </button>
            <span>{format(currentDate, 'MMMM yyyy')}</span>
            <button onClick={() => changeMonth(1)}>
              <FontAwesomeIcon icon={faChevronRight} />
            </button>
          </div>
          <div className="DatePicker__days">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="DatePicker__day-name">
                {day}
              </div>
            ))}
            {Array.from({ length: firstDay }).map((_, index) => (
              <div
                key={`empty-${index}`}
                className="DatePicker__day DatePicker__day--empty"
              ></div>
            ))}
            {Array.from({ length: days }).map((_, index) => {
              const day = index + 1;
              const date = new Date(
                currentDate.getFullYear(),
                currentDate.getMonth(),
                day,
              );
              const isSelectable = isDateSelectable(date);
              return (
                <div
                  key={day}
                  className={`DatePicker__day ${!isSelectable ? 'DatePicker__day--disabled' : ''}`}
                  onClick={() => isSelectable && handleDateClick(day)}
                >
                  {day}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
