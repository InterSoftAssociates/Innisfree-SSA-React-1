import { useState } from 'react';
import { StoryFn, Meta } from '@storybook/react';
import DatePicker, { DatePickerProps } from './DatePicker';

export default {
  title: 'components/shared/DatePicker',
  component: DatePicker,
  tags: ['autodocs'],
  argTypes: {
    value: {
      control: 'text',
      description: 'The selected date',
    },
    placeholder: {
      control: 'text',
      description: 'The placeholder text for the input',
      default: '',
    },
    disabled: {
      control: 'boolean',
      description: 'Whether the input is disabled',
      default: false,
    },
    minDate: {
      control: 'text',
      description: 'The minimum date that can be selected',
    },
    maxDate: {
      control: 'text',
      description: 'The maximum date that can be selected',
    },
    dateFormat: {
      control: 'select',
      options: [
        'yyyy-MM-dd',
        'MM/dd/yyyy',
        'dd-MM-yyyy',
        'yyyy/MM/dd',
        'dd/MM/yyyy',
        'MM-dd-yyyy',
      ],
      description: 'The format of the date',
      default: 'yyyy-MM-dd',
    },
  },
  decorators: [
    (Story) => (
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: '300px',
        }}
      >
        <Story />
      </div>
    ),
  ],
} as Meta;

const Template: StoryFn<DatePickerProps> = (args) => {
  const [date, setDate] = useState(args.value);
  return (
    <DatePicker
      {...args}
      value={date}
      onChange={(newDate) => {
        setDate(newDate);
        args.onChange(newDate);
      }}
    />
  );
};

export const Default = Template.bind({});
Default.args = {
  value: '',
  placeholder: 'Select a date',
  onChange: (date: string) => console.log('Date changed:', date),
};

export const WithInitialDate = Template.bind({});
WithInitialDate.args = {
  value: '2023-05-15',
  placeholder: 'Select a date',
  onChange: (date: string) => console.log('Date changed:', date),
};

export const WithCustomPlaceholder = Template.bind({});
WithCustomPlaceholder.args = {
  value: '',
  placeholder: 'Choose your birthdate',
  onChange: (date: string) => console.log('Date changed:', date),
};

export const Disabled = Template.bind({});
Disabled.args = {
  value: '',
  placeholder: 'Select a date',
  disabled: true,
  onChange: (date: string) => console.log('Date changed:', date),
};

export const WithMinMaxDates = Template.bind({});
WithMinMaxDates.args = {
  value: '',
  placeholder: 'Select a date',
  minDate: '2023-01-01',
  maxDate: '2023-12-31',
  onChange: (date: string) => console.log('Date changed:', date),
};

export const WithCustomFormat = Template.bind({});
WithCustomFormat.args = {
  value: '',
  placeholder: 'Select a date',
  dateFormat: 'MM/dd/yyyy',
  onChange: (date: string) => console.log('Date changed:', date),
};

export const WithTopAnchor = Template.bind({});
WithTopAnchor.args = {
  ...Default.args,
  anchor: 'top',
};
