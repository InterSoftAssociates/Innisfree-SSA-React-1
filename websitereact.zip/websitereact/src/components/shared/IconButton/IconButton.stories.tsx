import { StoryFn, Meta } from '@storybook/react';
import {
  faHeart,
  faStar,
  faUser,
  faEdit,
  faTrash,
} from '@fortawesome/free-solid-svg-icons';
import IconButton, { IconButtonProps } from './IconButton';

export default {
  title: 'components/shared/IconButton',
  tags: ['autodocs'],
  component: IconButton,
  argTypes: {
    color: {
      control: {
        type: 'select',
        options: ['default', 'primary', 'secondary', 'action', 'error'],
      },
    },
    size: {
      control: { type: 'select', options: ['small', 'medium', 'large'] },
    },
    isDisabled: { control: 'boolean' },
    onClick: { action: 'clicked' },
  },
} as Meta;

const Template: StoryFn<IconButtonProps> = (args) => <IconButton {...args} />;

export const Default = Template.bind({});
Default.args = {
  icon: faHeart,
  color: 'default',
  size: 'medium',
};

export const Primary = Template.bind({});
Primary.args = {
  icon: faStar,
  color: 'primary',
  size: 'medium',
};

export const Secondary = Template.bind({});
Secondary.args = {
  icon: faUser,
  color: 'secondary',
  size: 'medium',
};

export const Action = Template.bind({});
Action.args = {
  icon: faEdit,
  color: 'action',
  size: 'medium',
};

export const Error = Template.bind({});
Error.args = {
  icon: faTrash,
  color: 'error',
  size: 'medium',
};

export const Small = Template.bind({});
Small.args = {
  icon: faHeart,
  color: 'primary',
  size: 'small',
};

export const Large = Template.bind({});
Large.args = {
  icon: faHeart,
  color: 'primary',
  size: 'large',
};

export const Disabled = Template.bind({});
Disabled.args = {
  icon: faHeart,
  color: 'primary',
  size: 'medium',
  isDisabled: true,
};
