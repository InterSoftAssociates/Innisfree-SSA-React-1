import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconProp } from '@fortawesome/fontawesome-svg-core';
import classNames from 'classnames';
import './IconButton.scss';

export interface IconButtonProps {
  icon?: IconProp;
  onClick?: () => void;
  color?: 'default' | 'primary' | 'secondary' | 'action' | 'error';
  size?: 'small' | 'medium' | 'large';
  isDisabled?: boolean;
  className?: string;
  MuiIcon?: any;
}

export default function IconButton({
  icon,
  MuiIcon = null,
  onClick,
  color = 'default',
  size = 'medium',
  isDisabled = false,
  className,
}: IconButtonProps) {
  const buttonClasses = classNames(
    'IconButton',
    `IconButton--${color}`,
    `IconButton--${size}`,
    { 'IconButton--disabled': isDisabled },
    className,
  );

  const handleClick = () => {
    if (isDisabled) return;
    onClick?.();
  };

  return (
    <button
      className={buttonClasses}
      onClick={handleClick}
      disabled={isDisabled}
    >
      <span className="IconButton__ripple"></span>

      {icon && <FontAwesomeIcon icon={icon} />}
      {MuiIcon && <MuiIcon />}
    </button>
  );
}
