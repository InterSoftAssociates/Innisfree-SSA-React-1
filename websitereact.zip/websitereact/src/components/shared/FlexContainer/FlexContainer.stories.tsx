import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import FlexContainer, { FlexContainerProps } from './FlexContainer';

export default {
  title: 'components/shared/FlexContainer',
  component: FlexContainer,
  tags: ['autodocs'],
  argTypes: {
    flexDirection: {
      control: 'select',
      options: ['row', 'column', 'row-reverse', 'column-reverse'],
      description: 'The flex direction of the container',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'row' },
      },
    },
    alignItems: {
      control: 'select',
      options: ['flex-start', 'center', 'flex-end', 'stretch', 'baseline'],
      description: 'The align-items property of the container',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'center' },
      },
    },
    justifyContent: {
      control: 'select',
      options: [
        'flex-start',
        'center',
        'flex-end',
        'space-between',
        'space-around',
        'space-evenly',
      ],
      description: 'The justify-content property of the container',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'center' },
      },
    },
    Component: {
      control: 'select',
      options: ['div', 'section', 'article'],
      description: 'The HTML element to use for the container',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'div' },
      },
    },
    children: {
      description: 'The child elements to render inside the container',
      control: 'text',
    },
  },
} as Meta<FlexContainerProps>;

const Template: StoryFn<FlexContainerProps> = (args) => (
  <FlexContainer {...args}>
    <div
      style={{
        padding: '20px',
        background: '#007bff',
        color: 'white',
        margin: '5px',
      }}
    >
      Item 1
    </div>
    <div
      style={{
        padding: '20px',
        background: '#28a745',
        color: 'white',
        margin: '5px',
      }}
    >
      Item 2
    </div>
    <div
      style={{
        padding: '20px',
        background: '#dc3545',
        color: 'white',
        margin: '5px',
      }}
    >
      Item 3
    </div>
  </FlexContainer>
);

export const Default = Template.bind({});
Default.args = {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  Component: 'div',
};

export const Column = Template.bind({});
Column.args = {
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  Component: 'div',
};

export const SpaceBetween = Template.bind({});
SpaceBetween.args = {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  Component: 'div',
};

export const CustomComponent = Template.bind({});
CustomComponent.args = {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  Component: 'section',
};

// Add some basic styles to visualize the container
const styles = `
  <style>
    .FlexContainer {
      display: flex;
      min-height: 200px;
      border: 2px dashed #ccc;
      padding: 10px;
    }
  </style>
`;

// Inject the styles into the head of the document
if (typeof document !== 'undefined') {
  document.head.insertAdjacentHTML('beforeend', styles);
}
