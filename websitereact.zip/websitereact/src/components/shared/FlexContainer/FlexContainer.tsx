export interface FlexContainerProps {
  flexDirection?: 'row' | 'column' | 'row-reverse' | 'column-reverse' | 'unset';
  alignItems?:
    | 'flex-start'
    | 'center'
    | 'flex-end'
    | 'stretch'
    | 'baseline'
    | 'unset';
  justifyContent?:
    | 'flex-start'
    | 'center'
    | 'flex-end'
    | 'space-between'
    | 'space-around'
    | 'space-evenly'
    | 'unset';
  Component?: ElementType;
  children: React.ReactNode;
}

export default function FlexContainer({
  flexDirection = 'row',
  alignItems = 'unset',
  justifyContent = 'unset',
  Component = 'div',
  children,
}: FlexContainerProps) {
  return (
    <Component
      className="FlexContainer"
      style={{
        display: 'flex',
        flexDirection,
        alignItems,
        justifyContent,
      }}
    >
      {children}
    </Component>
  );
}
