import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import './ToolbarButton.scss';

export default function ToolbarButton({
  icon = null,
  onClick,
  children,
  ...rest
}: {
  icon?: any;
  onClick: () => void;
  children: React.ReactNode;
  [key: string]: any;
}) {
  return (
    <button onClick={onClick} {...rest} className="ToolbarButton">
      {icon && (
        <FontAwesomeIcon
          className="ToolbarButton__icon"
          icon={icon}
          style={{ marginRight: '10px' }}
        />
      )}
      {children}
    </button>
  );
}
