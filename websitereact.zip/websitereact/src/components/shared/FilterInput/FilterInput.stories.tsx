import { StoryFn, Meta } from '@storybook/react';
import FilterInput, { FilterInputProps } from './FilterInput';

export default {
  tags: ['autodocs'],
  title: 'components/shared/FilterInput',
  component: FilterInput,
  argTypes: {
    type: {
      control: {
        type: 'select',
        options: ['text', 'date'],
      },
    },
    onFilterChange: { action: 'filter changed' },
  },
} as Meta;

const Template: StoryFn<FilterInputProps> = (args) => <FilterInput {...args} />;

export const TextFilter = Template.bind({});
TextFilter.args = {
  type: 'text',
  placeholder: 'Filter text...',
};

export const DateFilter = Template.bind({});
DateFilter.args = {
  type: 'date',
  placeholder: 'Filter date...',
};

export const CustomClassName = Template.bind({});
CustomClassName.args = {
  type: 'text',
  placeholder: 'Custom class...',
  className: 'custom-filter-input',
};

export const DisabledFilter = Template.bind({});
DisabledFilter.args = {
  type: 'text',
  placeholder: 'Disabled filter',
  isDisabled: true,
};

export const WithInitialValue = Template.bind({});
WithInitialValue.args = {
  type: 'text',
  placeholder: 'With initial value',
  value: 'Initial filter value',
};
