import React, { memo, useState, useEffect, useCallback } from 'react';
import useClickAwayListener from '@/hooks/useClickawayListener';
import useDebouncedCallback from '@/hooks/useDebouncedCallback';

// components
import DatePicker from '../DatePicker';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFilter } from '@fortawesome/free-solid-svg-icons';
import Dropdown from '../Dropdown';
import Input from '../Input';

// lib
import classNames from 'classnames';
import { dateFilterOptions, textFilterOptions } from '@/lib/filtering';

// styles
import './FilterInput.scss';

export interface FilterInputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  type: 'text' | 'date' | 'number';
  onFilterChange: (
    key: string,
    type: string,
    value: string,
    selectedFilter: string,
  ) => void;
  isDisabled?: boolean;
  dropdownAnchor?: 'top' | 'bottom';
  defaultFilter?: string;
  identifier: string;
  onFocus?: () => void;
  onBlur?: () => void;
}

function FilterInput({
  type,
  onFilterChange,
  className = '',
  isDisabled = false,
  dropdownAnchor = 'bottom',
  defaultFilter = 'contains',
  identifier,
  onFocus = () => {},
  onBlur = () => {},
  ...rest
}: FilterInputProps) {
  const [innerValue, setInnerValue] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const dropdownRef = useClickAwayListener<HTMLDivElement>(() =>
    setIsDropdownOpen(false),
  );

  const [selectedFilter, setSelectedFilter] = useState(defaultFilter);

  const handleFilterClick = useCallback(() => {
    setIsDropdownOpen((prevState) => !prevState);
  }, []);

  useEffect(() => {
    setSelectedFilter(defaultFilter);
  }, [defaultFilter]);

  const handleFilterSelect = useCallback(
    (filterType: string) => {
      if (innerValue) {
        if (filterType === 'clear') {
          setIsDropdownOpen(false);
          setInnerValue('');
          onFilterChange(identifier, type, '', filterType);
          return;
        }

        setSelectedFilter(filterType);
        setIsDropdownOpen(false);
        onFilterChange(identifier, type, innerValue, filterType);
      } else {
        setIsDropdownOpen(false);
        setSelectedFilter(filterType);
      }
    },

    // eslint-disable-next-line react-hooks/exhaustive-deps
    [innerValue, identifier, type],
  );

  const filterChangeDebounced = useDebouncedCallback((value: string) => {
    onFilterChange(identifier, type, value, selectedFilter);
  }, 250);

  const dateFilterChangeDebounced = useDebouncedCallback((value: string) => {
    onFilterChange(identifier, type, value, selectedFilter);
  }, 100);

  const handleDateSelect = useCallback((date: string) => {
    setInnerValue(date);
    dateFilterChangeDebounced(date);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      className={classNames('FilterInput', className, {
        'FilterInput--disabled': isDisabled,
      })}
      ref={dropdownRef}
      onFocus={onFocus}
      onBlur={onBlur}
    >
      {type !== 'date' && (
        <Input
          icon={faFilter}
          type={type}
          onChange={(e) => {
            setInnerValue(e.target.value);
            filterChangeDebounced(e.target.value);
          }}
          value={innerValue}
          isDisabled={isDisabled}
          onIconClick={handleFilterClick}
          {...rest}
        />
      )}
      {type === 'date' && (
        <>
          <DatePicker value={innerValue} onChange={handleDateSelect} />

          <div className="FilterInput__icon__end" onClick={handleFilterClick}>
            <FontAwesomeIcon icon={faFilter} />
          </div>
        </>
      )}

      <Dropdown
        anchor={dropdownAnchor}
        isOpen={isDropdownOpen}
        options={type === 'text' ? textFilterOptions : dateFilterOptions}
        selectedValues={[selectedFilter]}
        onOptionClick={handleFilterSelect}
      />
    </div>
  );
}

export default memo(FilterInput);
