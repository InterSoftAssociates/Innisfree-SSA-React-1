import './TextArea.scss';

export default function TextArea(props: Record<string, any>) {
  return <textarea className="TextArea" {...props} />;
}
