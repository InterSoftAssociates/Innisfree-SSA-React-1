import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import Select, { SelectProps } from './Select';

export default {
  title: 'components/shared/Select',
  component: Select,
  tags: ['autodocs'],
  argTypes: {
    anchor: {
      control: {
        type: 'select',
        options: ['top', 'bottom'],
      },
    },
    onChange: { action: 'onChange' },
    options: { control: { type: 'object' } },
    isMulti: {
      control: 'boolean',
      description:
        'Whether the select is a multi-select or not (only select 1 option or multiple)',
    },
    label: { control: 'text' },
    isDisabled: {
      control: 'boolean',
      description: 'Whether the select is disabled or not',
    },
  },
} as Meta;

const Template: StoryFn<SelectProps> = (args) => <Select {...args} />;

export const SingleSelect = Template.bind({});
SingleSelect.args = {
  options: [
    { value: '1', label: 'Option 1' },
    { value: '2', label: 'Option 2' },
    { value: '3', label: 'Option 3' },
  ],
  value: '1',
  onChange: (value: string | number | (string | number)[]) =>
    console.log('Selected:', value),
  isMulti: false,
  label: 'Single Select',
};

export const MultiSelect = Template.bind({});
MultiSelect.args = {
  options: [
    { value: '1', label: 'Option 1' },
    { value: '2', label: 'Option 2' },
    { value: '3', label: 'Option 3' },
    { value: '4', label: 'Option 4' },
    { value: '5', label: 'Option 5' },
  ],
  value: ['1', '3'],
  onChange: (value: string | number | (string | number)[]) =>
    console.log('Selected:', value),
  isMulti: true,
  label: 'Multi Select',
};

export const MultiSelectManyOptions = Template.bind({});
MultiSelectManyOptions.args = {
  options: Array.from({ length: 20 }, (_, i) => ({
    value: `${i + 1}`,
    label: `Option ${i + 1}`,
  })),
  value: ['1', '3', '5', '7', '9', '11', '13', '15'],
  onChange: (value: string | number | (string | number)[]) =>
    console.log('Selected:', value),
  isMulti: true,
  label: 'Multi Select with Many Options',
};
