// hooks
import React, { useRef, useState, useEffect, useCallback } from 'react';
import useClickAwayListener from '@/hooks/useClickawayListener';

// components
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Dropdown from '../Dropdown';

// icons
import { faChevronDown, faTimes } from '@fortawesome/free-solid-svg-icons';

// styles
import './Select.scss';

interface SelectOption {
  value: string | number;
  label: string;
}

export interface SelectProps {
  options: SelectOption[];
  value: string | number | (string | number)[];
  onChange: (value: any | any[]) => void;
  isMulti?: boolean;
  label?: string;
  name?: string;
  id?: string;
  placeholder?: string;
  onClose?: () => void;
  anchor?: 'top' | 'bottom';
  onOpen?: () => void;
  isDisabled?: boolean;
}

export default function Select({
  options,
  value,
  onChange,
  isMulti = false,
  name = '',
  id = '',
  label = '',
  placeholder = 'Select...',
  onClose = () => {},
  anchor = 'bottom',
  onOpen,
  isDisabled,
}: SelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedValues, setSelectedValues] = useState<(string | number)[]>(
    isMulti ? (Array.isArray(value) ? value : []) : [value as string | number],
  );
  const selectRef = useRef<HTMLDivElement>(null);

  const handleClose = useCallback(() => {
    setIsOpen(false);
    onClose();
  }, [onClose]);

  const ref = useClickAwayListener<HTMLDivElement>(handleClose, [isOpen]);

  useEffect(() => {
    if (isMulti) {
      setSelectedValues(Array.isArray(value) ? value : []);
    } else {
      setSelectedValues([value as string | number]);
    }
  }, [value, isMulti]);

  const handleOptionClick = (optionValue: string | number) => {
    if (isMulti) {
      const updatedValues = selectedValues.includes(optionValue)
        ? selectedValues.filter((v) => v !== optionValue)
        : [...selectedValues, optionValue];
      setSelectedValues(updatedValues);

      if (JSON.stringify(updatedValues) === JSON.stringify(selectedValues)) {
        return;
      }

      onChange(updatedValues);
    } else {
      setSelectedValues([optionValue]);

      if (JSON.stringify([optionValue]) === JSON.stringify(selectedValues)) {
        return handleClose();
      }
      onChange(optionValue);
      handleClose();
    }
  };

  const handleCancel = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedValues([]);
    onChange([]);
  };

  const handleToggle = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();

      const nextValue = !isOpen ? true : false;

      setIsOpen(nextValue);

      if (nextValue && typeof onOpen === 'function') {
        onOpen?.();
      }

      if (!nextValue) {
        handleClose();
      }
    },

    // eslint-disable-next-line react-hooks/exhaustive-deps
    [isOpen],
  );

  const getDisplayValue = () => {
    if (isMulti) {
      return selectedValues
        .map((v) => options?.find?.((opt) => opt.value === v)?.label)
        .join(', ');
    }
    return options?.find?.((option) => option.value === selectedValues[0])
      ?.label;
  };

  return (
    <div
      className={`Select Select--${anchor} ${
        isDisabled ? 'Select--disabled' : ''
      }`}
      ref={ref}
      id={id}
    >
      {label && (
        <label htmlFor={id || name} className="Select__label">
          {label}
        </label>
      )}
      <div
        className={`Select__selected ${isOpen ? 'Select__selected--open' : ''}`}
        onClick={handleToggle}
        ref={selectRef}
      >
        <div className="Select__selected-text">
          {getDisplayValue() || placeholder}
        </div>
        <div className="Select__icons">
          {isMulti && selectedValues.length > 0 && (
            <FontAwesomeIcon
              icon={faTimes}
              className="Select__cancel"
              onClick={handleCancel}
            />
          )}
          <FontAwesomeIcon
            icon={faChevronDown}
            className={`Select__arrow ${isOpen ? 'Select__arrow--open' : ''}`}
          />
        </div>
      </div>
      <Dropdown
        options={options}
        selectedValues={selectedValues}
        onOptionClick={handleOptionClick}
        isOpen={isOpen}
        anchor={anchor}
      />
    </div>
  );
}
