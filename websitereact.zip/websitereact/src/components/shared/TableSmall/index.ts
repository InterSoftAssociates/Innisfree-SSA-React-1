export { default } from './TableSmall';
