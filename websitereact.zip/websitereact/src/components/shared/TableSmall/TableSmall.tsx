import React from 'react';
import './TableSmall.scss';

interface TableRow {
  [key: string]: React.ReactNode;
}

interface TableSmallProps {
  data: TableRow[];
  className?: string;
}

export default function TableSmall({ data, className = '' }: TableSmallProps) {
  return (
    <div className={`TableSmall ${className}`}>
      <table className="TableSmall__table">
        <tbody>
          {data.map((row, rowIndex) => (
            <tr
              key={rowIndex}
              className={`TableSmall__row TableSmall__row--${rowIndex % 2 === 0 ? 'even' : 'odd'}`}
            >
              {Object.entries(row).map(([key, value], cellIndex) => (
                <React.Fragment key={cellIndex}>
                  <td className="TableSmall__cell TableSmall__cell--header">
                    {key}
                  </td>
                  <td className="TableSmall__cell TableSmall__cell--data">
                    {value}
                  </td>
                </React.Fragment>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
