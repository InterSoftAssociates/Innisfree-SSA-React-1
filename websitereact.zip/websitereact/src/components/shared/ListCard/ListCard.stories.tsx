import ListCard, { ListCardProps } from './ListCard';

export default {
  title: 'Components/shared/ListCard',
  component: ListCard,
  tags: ['autodocs'],
  argTypes: {
    items: {
      control: 'array',
      description: 'List of items to display',
    },
    renderItemLabel: {
      description: 'Function to render the label of each item',
    },
    getItemKey: {
      description: 'Function to get the key of each item',
    },
    onItemClick: {
      description: 'Function to handle the click event of each item',
    },
    headerTitle: {
      description: 'Title of the card',
    },
  },
  decorators: [
    (Story: any) => (
      <div style={{ width: '500px' }}>
        <Story />
      </div>
    ),
  ],
};

interface TestUser {
  id: number;
  name: string;
  email: string;
  role: string;
}

const generateUser = () => ({
  id: Math.floor(Math.random() * 1000),
  name: Math.random().toString(36).substring(7),
  email: `${Math.random().toString(36).substring(7)}@gmail.com`,
  role: 'Admin',
});

const usersList: TestUser[] = Array.from({ length: 10 }, generateUser);

const props = {
  items: usersList,
  renderItemLabel: (item: TestUser) => item.name,
  getItemKey: (item: TestUser) => item.id.toString(),
  onItemClick: (item: TestUser) => console.log(item),
  headerTitle: 'Users',
};

const Template = (args: ListCardProps) => <ListCard {...args} />;

export const Default = Template.bind({});

export const WithItems = Template.bind({});
WithItems.args = props;
