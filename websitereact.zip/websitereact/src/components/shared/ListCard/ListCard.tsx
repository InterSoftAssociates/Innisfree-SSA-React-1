import classNames from 'classnames';
import Card from '../Card';
import './ListCard.scss';

export interface ListCardProps {
  items: any[];
  renderItemLabel: (item: any) => string | JSX.Element;
  getItemKey?: (item: any) => string;
  onItemClick?: (item: any) => void;
  headerTitle?: string;
}

export default function ListCard({
  items = [],
  renderItemLabel,
  onItemClick,
  getItemKey,
  headerTitle,
}: ListCardProps) {
  return (
    <Card
      containerClassName={classNames('ListCard', {
        'ListCard--visible': items.length > 0,
        'ListCard--hidden': items.length <= 0,
      })}
      headerTitle={headerTitle}
    >
      <ul className="ListCard__list">
        {items.map((item, index) => (
          <li
            key={getItemKey?.(item) ?? index}
            onClick={() => onItemClick?.(item)}
            className="ListCard__list__item"
          >
            {renderItemLabel(item)}
          </li>
        ))}
      </ul>
    </Card>
  );
}
