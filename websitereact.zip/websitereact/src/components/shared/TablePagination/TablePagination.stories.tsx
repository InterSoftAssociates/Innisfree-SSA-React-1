import { StoryFn, Meta } from '@storybook/react';
import TablePagination, { TablePaginationProps } from './TablePagination';

export default {
  title: 'components/shared/TablePagination',
  component: TablePagination,
  decorators: [
    (Story) => (
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <Story />
      </div>
    ),
  ],
} as Meta;

const Template: StoryFn<TablePaginationProps> = (args) => (
  <TablePagination {...args} />
);

export const Default = Template.bind({});
Default.args = {
  currentPage: 1,
  totalPages: 5,
  limit: 10,
  total: 50,
  canGoBack: false,
  canGoNext: true,
  onNextPage: () => console.log('Next page'),
  onPreviousPage: () => console.log('Previous page'),
  onLimitChange: (limit: number) => console.log('Limit changed to:', limit),
};
