import { memo } from 'react';

// components
import Select from '../Select';
import IconButton from '../IconButton';

// icons
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';

// styles
import './TablePagination.scss';

export interface TablePaginationProps {
  currentPage: number;
  totalPages: number;
  limit: number;
  total: number;
  canGoBack: boolean;
  canGoNext: boolean;
  onNextPage: () => void;
  onFirstPage: () => void;
  onLastPage: () => void;
  onPreviousPage: () => void;
  onLimitChange: (limit: number) => void;
  itemsLabel?: string;
  size?: 'default' | 'small';
}

function TablePagination({
  currentPage,
  limit,
  total,
  canGoBack,
  canGoNext,
  onNextPage,
  onPreviousPage,
  onLimitChange,
  onLastPage,
  onFirstPage,
  totalPages,
  itemsLabel = 'records',
  size = 'default',
}: TablePaginationProps) {
  const start = (currentPage - 1) * limit + 1;
  const end = Math.min(currentPage * limit, total);

  return (
    <div
      className={`TablePagination ${size === 'small' ? 'TablePagination--small' : ''}`}
    >
      <div className="TablePagination__info">
        {start} - {end} of {total} {itemsLabel}
      </div>
      <div className="TablePagination__controls">
        <Select
          options={[
            { value: 10, label: '10 per page' },
            { value: 25, label: '25 per page' },
            { value: 50, label: '50 per page' },
            { value: 75, label: '75 per page' },
            { value: 100, label: '100 per page' },
          ]}
          value={limit}
          onChange={(value) => onLimitChange(Number(value))}
          anchor="top"
        />

        <IconButton
          MuiIcon={KeyboardDoubleArrowLeftIcon}
          onClick={onFirstPage}
          isDisabled={!canGoBack}
        />

        <IconButton
          MuiIcon={KeyboardArrowLeftIcon}
          onClick={onPreviousPage}
          isDisabled={!canGoBack}
        />

        <div className="TablePagination__page">
          {currentPage} of {totalPages}
        </div>

        <IconButton
          MuiIcon={KeyboardArrowRightIcon}
          onClick={onNextPage}
          isDisabled={!canGoNext}
        />

        <IconButton
          MuiIcon={KeyboardDoubleArrowRightIcon}
          onClick={onLastPage}
          isDisabled={!canGoNext}
        />
      </div>
    </div>
  );
}

export default memo(TablePagination);
