import React from 'react';
import { Story, Meta } from '@storybook/react';
import Scrollbar from './Scrollbar';

export default {
  title: 'components/shared/Scrollbar',
  component: Scrollbar,
  parameters: {
    docs: {
      description: {
        component:
          'A custom scrollbar component that can be used to wrap scrollable content.',
      },
    },
  },
  argTypes: {
    height: {
      control: 'text',
      description: 'Height of the scrollable area',
      defaultValue: '300px',
    },
    width: {
      control: 'text',
      description: 'Width of the scrollable area',
      defaultValue: '100%',
    },
  },
  tags: ['autodocs'],
} as Meta;

const Template: Story = (args) => (
  <Scrollbar style={{ height: args.height, width: args.width }}>
    <div style={{ padding: '10px', background: '#fff' }}>
      {Array.from({ length: 50 }, (_, i) => (
        <p key={i}>Scrollable content line {i + 1}</p>
      ))}
    </div>
  </Scrollbar>
);

export const Default = Template.bind({});
Default.args = {
  height: '300px',
  width: '100%',
};

export const HorizontalScroll = Template.bind({});
HorizontalScroll.args = {
  height: '300px',
  width: '200px',
};
HorizontalScroll.parameters = {
  docs: {
    description: {
      story: 'This story demonstrates both vertical and horizontal scrolling.',
    },
  },
};

const LongContentTemplate: Story = (args) => (
  <Scrollbar style={{ height: args.height, width: args.width }}>
    <div style={{ padding: '10px' }}>
      <h2>Lorem Ipsum</h2>
      {Array.from({ length: 10 }, (_, i) => (
        <p key={i}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat.
        </p>
      ))}
    </div>
  </Scrollbar>
);

export const LongContent = LongContentTemplate.bind({});
LongContent.args = {
  height: '400px',
  width: '100%',
};
LongContent.parameters = {
  docs: {
    description: {
      story:
        'This story shows how the scrollbar handles longer, more realistic content.',
    },
  },
};

const NestedScrollbarsTemplate: Story = (args) => (
  <Scrollbar style={{ height: args.height, width: args.width }}>
    <div style={{ padding: '10px' }}>
      <h2>Outer Scrollbar</h2>
      <p>This is content in the outer scrollable area.</p>
      <Scrollbar
        style={{ height: '200px', width: '100%', border: '1px solid #ccc' }}
      >
        <div style={{ padding: '10px' }}>
          <h3>Inner Scrollbar</h3>
          {Array.from({ length: 20 }, (_, i) => (
            <p key={i}>Inner scrollable content line {i + 1}</p>
          ))}
        </div>
      </Scrollbar>
      <p>More content in the outer scrollable area.</p>
    </div>
  </Scrollbar>
);

export const NestedScrollbars = NestedScrollbarsTemplate.bind({});
NestedScrollbars.args = {
  height: '400px',
  width: '100%',
};
NestedScrollbars.parameters = {
  docs: {
    description: {
      story:
        'This story demonstrates nested scrollbars, showing how they interact with each other.',
    },
  },
};
