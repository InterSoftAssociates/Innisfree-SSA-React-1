import './Scrollbar.scss';

interface ScrollbarProps {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

export default function Scrollbar({
  children,
  className = '',
  style = {},
}: ScrollbarProps) {
  return (
    <div className={`Scrollbar ${className}`} style={style}>
      {children}
    </div>
  );
}
