import { memo } from 'react';

// lib
import classNames from 'classnames';

// styles
import './StatsButton.scss';

function StatsButton({
  image,
  label,
  value,
  variants = [],
}: {
  image?: string;
  label: string;
  value: any;
  variants?: string[];
}) {
  return (
    <button
      className={classNames(
        'StatsButton',
        ...variants.map((variant: string) => `StatsButton--${variant}`),
      )}
    >
      {image && (
        <div className="StatsButton__column">
          <img src={image} alt="icon" className="StatsButton__icon" />
        </div>
      )}

      <div className="StatsButton__column">
        <span className="StatsButton__value">{value}</span>
        <span className="StatsButton__label">{label}</span>
      </div>
    </button>
  );
}

export default memo(StatsButton);
