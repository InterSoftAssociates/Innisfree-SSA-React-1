import { Meta, StoryObj } from '@storybook/react';
import StatsButton from './StatsButton';

const meta: Meta<typeof StatsButton> = {
  title: 'components/shared/StatsButton',
  component: StatsButton,
  tags: ['autodocs'],
  argTypes: {
    image: {
      control: 'text',
      description: 'URL or path to the icon image',
    },
    label: {
      control: 'text',
      description: 'Label text for the button',
    },
    value: {
      control: 'text',
      description: 'Value to display on the button',
    },
    variants: {
      control: 'multi-select',
      options: ['buy', 'sell', 'neutral'],
      description: 'Visual variants for the button',
    },
  },
};

export default meta;

type Story = StoryObj<typeof StatsButton>;

export const Default: Story = {
  args: {
    image: '/path/to/default-icon.png',
    label: 'Total',
    value: '1,000',
  },
};

export const Buy: Story = {
  args: {
    image: '/static/images/up-arrow.png',
    label: 'Buys',
    value: '500',
    variants: ['buy'],
  },
};

export const Sell: Story = {
  args: {
    image: '/static/images/down.png',
    label: 'Sells',
    value: '300',
    variants: ['sell'],
  },
};

export const NoImage: Story = {
  args: {
    label: 'No Icon',
    value: '100',
  },
};

export const MultipleVariants: Story = {
  args: {
    image: '/static/images/up-arrow.png',
    label: 'Custom',
    value: '150',
    variants: ['buy', 'neutral'],
  },
};

export const LargeValue: Story = {
  args: {
    image: '/static/images/up-arrow.png',
    label: 'Total Assets',
    value: '1,000,000,000',
  },
};

export const ButtonGroup: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '10px' }}>
      <StatsButton
        image="/static/images/up-arrow.png"
        label="Buys"
        value="500"
        variants={['buy']}
      />
      <StatsButton
        image="/static/images/down.png"
        label="Sells"
        value="300"
        variants={['sell']}
      />
      <StatsButton
        image="/static/images/cash.png"
        label="Unchanged"
        value="200"
        variants={['neutral']}
      />
    </div>
  ),
};
