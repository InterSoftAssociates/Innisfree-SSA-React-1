import { useCallback, useEffect } from 'react';
import useSearchParams from '@/hooks/useSearchParams';
import useAuthStore from '@/features/auth/store/auth.store';
import { useNavigate } from 'react-router';
import { PATHS } from '@/routes/paths';

interface GuestGuardProps {
  children: React.ReactNode;
}

// a guard that redirects an authorized user away from unauthorized routes
export default function GuestGuard({ children }: GuestGuardProps) {
  const { isAuthenticated } = useAuthStore();
  const navigate = useNavigate();

  // if we wanted to return to a path where the user was previously before logging out like the reports page etc instead of hard coding it to login.
  // const searchParams = useSearchParams();
  // const returnTo = searchParams.get('redirectUrl') || PATHS.HOME;
  const returnTo = PATHS.HOME;
  const startGuardCheck = useCallback(() => {
    if (isAuthenticated) {
      navigate(returnTo, { replace: true });
    }
  }, [returnTo, navigate, isAuthenticated]);

  useEffect(() => {
    startGuardCheck();
  }, [startGuardCheck]);

  return children;
}
