import { useEffect, useCallback, useState } from 'react';
import useAuthStore from '../features/auth/store/auth.store';
import { useNavigate } from 'react-router';
import { PATHS } from '../routes/paths';

interface AuthGuardProps {
  children: React.ReactNode;
}

// a guard that redirects an unauthorized user away from authorized routes
export default function AuthGuard({ children }: AuthGuardProps) {
  const navigate = useNavigate();

  const { isLoading, isLoggedIn, isAuthenticated, logoutMessage } =
    useAuthStore();
  const [checked, setChecked] = useState(false);

  const startGuardCheck = useCallback(() => {
    if (!isLoggedIn() || !isAuthenticated) {
      let href = PATHS.get('AUTH.LOGIN');
      if (logoutMessage) {
        href += `?error=${logoutMessage}`;
      }

      const redirectUrl = window.location.pathname;

      if (redirectUrl.replace('/', '').trim() !== '') {
        const searchParams = new URLSearchParams({
          redirectUrl: window.location.pathname,
        }).toString();

        href += `?${searchParams}`;
      }

      navigate(href);
    } else {
      if (logoutMessage) {
        const href = `${PATHS.get('AUTH.LOGIN')}?error=${logoutMessage}`;
        navigate(href);
      }

      setChecked(true);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigate, isAuthenticated]);

  useEffect(() => {
    if (!isLoading) {
      startGuardCheck();
    }
  }, [startGuardCheck, isLoading]);

  if (!checked) {
    return null;
  }

  return children;
}
