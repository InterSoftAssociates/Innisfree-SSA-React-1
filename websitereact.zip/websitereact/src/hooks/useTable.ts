import { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import * as XLSX from 'xlsx';
import {
  isValid,
  isAfter,
  isBefore,
  isEqual,
  startOfDay,
  startOfMonth,
  endOfMonth,
  startOfYear,
  endOfYear,
  subDays,
  subMonths,
  subYears,
  addMonths,
  addYears,
} from 'date-fns';
import { ColumnDef } from '@/components/shared/Table/Table';
import { performanceMeasurement } from '@/lib/performanceMeasurement';

interface UseTableProps<T> {
  data: T[];
  initialSort?: keyof T;
  initialSortDirection?: 'asc' | 'desc';
  initialLimit?: number;
  initialColumns: ColumnDef<T>[];
  rowHeight?: number;
  maxHeight?: number | string;
  fileName?: string;
}

export default function useTable<T>({
  data,
  initialSort,
  initialSortDirection = 'asc',
  initialLimit = 25,
  initialColumns,
  rowHeight = 42,
  maxHeight = 400,
  fileName = 'Export',
}: UseTableProps<T>) {
  const [sortKey, setSortKey] = useState<keyof T | null>(initialSort || null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>(
    initialSortDirection,
  );
  const [filters, setFilters] = useState<
    Partial<
      Record<keyof T, { type: string; value: string; filterMethodKey: string }>
    >
  >({});
  const [currentPage, setCurrentPage] = useState(1);
  const [limit, setLimit] = useState(initialLimit);
  const [isFiltering, setIsFiltering] = useState(false);

  const [columns, setColumns] = useState(initialColumns);
  const [scrollTop, setScrollTop] = useState(0);
  const tableRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(0);

  const filterData = useCallback(
    (dataToFilter: T[]) => {
      setIsFiltering(true);
      const filtered = dataToFilter.filter((item) =>
        Object.entries(filters).every(([key, filter]) => {
          if (!filter.value) return true;
          const itemValue = String(item[key as keyof T]);

          if (filter.type === 'date') {
            const date = new Date(itemValue);
            if (!isValid(date)) return true; // Skip invalid dates

            const now = new Date();
            const filterDate = new Date(filter.value);

            switch (filter.filterMethodKey) {
              case 'on':
                return isEqual(date, filterDate);
              case 'notOn':
                return !isEqual(date, filterDate);
              case 'after':
                return isAfter(date, filterDate);
              case 'before':
                return isBefore(date, filterDate);
              case 'today':
                return isEqual(date, startOfDay(now));
              case 'yesterday':
                return isEqual(date, startOfDay(subDays(now, 1)));
              case 'thisMonth':
                return (
                  isAfter(date, startOfMonth(now)) &&
                  isBefore(date, endOfMonth(now))
                );
              case 'lastMonth': {
                const lastMonth = subMonths(now, 1);
                return (
                  isAfter(date, startOfMonth(lastMonth)) &&
                  isBefore(date, endOfMonth(lastMonth))
                );
              }
              case 'nextMonth': {
                const nextMonth = addMonths(now, 1);
                return (
                  isAfter(date, startOfMonth(nextMonth)) &&
                  isBefore(date, endOfMonth(nextMonth))
                );
              }
              case 'thisYear':
                return (
                  isAfter(date, startOfYear(now)) &&
                  isBefore(date, endOfYear(now))
                );
              case 'lastYear': {
                const lastYear = subYears(now, 1);
                return (
                  isAfter(date, startOfYear(lastYear)) &&
                  isBefore(date, endOfYear(lastYear))
                );
              }
              case 'nextYear': {
                const nextYear = addYears(now, 1);
                return (
                  isAfter(date, startOfYear(nextYear)) &&
                  isBefore(date, endOfYear(nextYear))
                );
              }
              default:
                return true;
            }
          } else {
            // Text filtering logic
            const lowerItemValue = itemValue.toLowerCase();
            const lowerFilterValue = filter.value.toLowerCase();
            switch (filter.filterMethodKey) {
              case 'startsWith':
                return lowerItemValue.startsWith(lowerFilterValue);
              case 'endsWith':
                return lowerItemValue.endsWith(lowerFilterValue);
              case 'contains':
                return lowerItemValue.includes(lowerFilterValue);
              case 'notContains':
                return !lowerItemValue.includes(lowerFilterValue);
              case 'equals':
                return lowerItemValue === lowerFilterValue;
              case 'notEquals':
                return lowerItemValue !== lowerFilterValue;
              default:
                return true;
            }
          }
        }),
      );
      setIsFiltering(false);
      return filtered;
    },
    [filters],
  );

  const filteredData = useMemo(() => filterData(data), [data, filterData]);

  const sortedData = useMemo(() => {
    if (!sortKey) return filteredData;
    return [...filteredData].sort((a, b) => {
      if (a[sortKey] < b[sortKey]) return sortDirection === 'asc' ? -1 : 1;
      if (a[sortKey] > b[sortKey]) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredData, sortKey, sortDirection]);

  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * limit;
    const end = start + limit;
    return sortedData.slice(start, end);
  }, [sortedData, currentPage, limit]);

  const totalPages = Math.ceil(sortedData.length / limit);

  const canGoBack = currentPage > 1;
  const canGoNext = currentPage < totalPages;

  const goToNextPage = useCallback(() => {
    performanceMeasurement.start('table:goToNextPage');
    if (canGoNext) setCurrentPage((prev) => prev + 1);
    performanceMeasurement.end('table:goToNextPage');
  }, [canGoNext]);

  const goToPreviousPage = useCallback(() => {
    performanceMeasurement.start('table:goToPreviousPage');
    if (canGoBack) setCurrentPage((prev) => prev - 1);
    performanceMeasurement.end('table:goToPreviousPage');
  }, [canGoBack]);

  const goToLastPage = useCallback(() => {
    performanceMeasurement.start('table:goToLastPage');
    setCurrentPage(totalPages);
    performanceMeasurement.end('table:goToLastPage');
  }, [totalPages]);

  const goToFirstPage = useCallback(() => {
    performanceMeasurement.start('table:goToFirstPage');
    setCurrentPage(1);
    performanceMeasurement.end('table:goToFirstPage');
  }, []);

  const handleSort = useCallback(
    (key: keyof T) => {
      performanceMeasurement.start('table:handleSort');
      if (key === sortKey) {
        setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
      } else {
        setSortKey(key);
        setSortDirection('asc');
      }
      performanceMeasurement.end('table:handleSort');
    },
    [sortKey],
  );

  const handleFilterChange = useCallback(
    (
      key: string,
      filterType: string,
      value: string,
      filterMethodKey: string,
    ) => {
      performanceMeasurement.start('table:handleFilterChange');
      setFilters((prev) => ({
        ...prev,
        [key]: { type: filterType, value, filterMethodKey },
      }));
      setCurrentPage(1); // Reset to first page when filter changes
      performanceMeasurement.end('table:handleFilterChange');
    },
    [],
  );

  const exportToExcel = useCallback(
    (
      columns: { header: string; key: keyof T }[],
      fileName: string = `Export-${Date.now()}`,
    ) => {
      const worksheet = XLSX.utils.json_to_sheet(
        sortedData.map((row) =>
          columns.reduce(
            (acc, column) => {
              acc[column.header] = row[column.key];
              return acc;
            },
            {} as Record<string, any>,
          ),
        ),
      );
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
      XLSX.writeFile(workbook, `${fileName}.xlsx`);
    },
    [sortedData],
  );

  const onDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    const newColumns = Array.from(columns);
    const [reorderedColumn] = newColumns.splice(result.source.index, 1);
    newColumns.splice(result.destination.index, 0, reorderedColumn);

    setColumns(newColumns);
  };

  const handleExportToExcel = useCallback(() => {
    exportToExcel(columns, fileName || Date.now().toString());
  }, [columns, fileName, exportToExcel]);

  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop);
  }, []);

  const startIndex = Math.floor(scrollTop / rowHeight);
  const endIndex = Math.min(
    startIndex + Math.ceil(Number(maxHeight) / rowHeight),
    paginatedData.length,
  );

  const visibleData = paginatedData.slice(startIndex, endIndex);

  useEffect(() => {
    if (tableRef.current) {
      tableRef.current.style.height = `${paginatedData.length * rowHeight}px`;
    }

    if (containerRef.current) {
      setContainerWidth(containerRef.current.offsetWidth);
    }
  }, [paginatedData]);

  const calculateColumnWidths = useCallback(() => {
    let totalFixedWidth = 0;
    let totalPercentageWidth = 0;

    columns.forEach((column) => {
      const width = column.columnWidth || '230px';
      if (width.endsWith('px')) {
        totalFixedWidth += parseInt(width, 10);
      } else if (width.endsWith('%')) {
        totalPercentageWidth += parseFloat(width);
      }
    });

    const remainingWidth = containerWidth - totalFixedWidth;
    const percentageUnit = remainingWidth / 100;

    return columns.map((column) => {
      const width = column.columnWidth || '230px';
      if (width.endsWith('px')) {
        return parseInt(width, 10);
      } else if (width.endsWith('%')) {
        return percentageUnit * parseFloat(width);
      }
      return 230; // default width
    });
  }, [columns, containerWidth]);

  // const columnWidths = calculateColumnWidths();
  const columnWidths = useMemo(
    () => calculateColumnWidths(),
    [calculateColumnWidths],
  );

  const tableWidth = useMemo(
    () => columnWidths.reduce((sum, width) => sum + width, 0),
    [columnWidths],
  );

  const [hiddenColumns, setHiddenColumns] = useState<Set<keyof T>>(new Set());

  const toggleColumnVisibility = useCallback((key: keyof T) => {
    setHiddenColumns((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(key)) {
        newSet.delete(key);
      } else {
        newSet.add(key);
      }
      return newSet;
    });
  }, []);

  const isColumnVisible = useCallback(
    (key: keyof T) => !hiddenColumns.has(key),
    [hiddenColumns],
  );

  const visibleColumns = useMemo(
    () => columns.filter((column) => !hiddenColumns.has(column.key)),
    [columns, hiddenColumns],
  );

  const adjustedColumnWidths = useMemo(() => {
    return columnWidths.map((width, index) =>
      hiddenColumns.has(columns[index].key as keyof T) ? 0 : width,
    );
  }, [columnWidths, hiddenColumns, columns]);

  const adjustedTableWidth = useMemo(
    () => adjustedColumnWidths.reduce((sum, width) => sum + width, 0),
    [adjustedColumnWidths],
  );

  return {
    paginatedData,
    sortKey,
    sortDirection,
    currentPage,
    limit,
    totalPages,
    canGoBack,
    canGoNext,
    goToNextPage,
    goToPreviousPage,
    goToLastPage,
    goToFirstPage,
    handleSort,
    setLimit,
    exportToExcel,
    handleFilterChange,
    filters,
    filteredData,
    isFiltering,
    handleExportToExcel,
    handleScroll,
    visibleData,
    onDragEnd,
    columnWidths,
    tableWidth,
    containerRef,
    startIndex,
    tableRef,
    columns,
    toggleColumnVisibility,
    visibleColumns,
    adjustedColumnWidths,
    adjustedTableWidth,
    isColumnVisible,
  };
}
