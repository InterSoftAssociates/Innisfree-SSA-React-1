import { useRef, useEffect, useCallback } from 'react';
import { debounce } from 'lodash';

// Custom hook to create a debounced callback
export default function useDebouncedCallback<T extends (...args: any[]) => any>(
  callback: T,
  delay: number,
): T {
  const callbackRef = useRef<T>(callback);

  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const debouncedCallback = useCallback(
    debounce((...args: Parameters<T>) => {
      callbackRef.current(...args);
    }, delay),
    [delay],
  );

  return debouncedCallback as unknown as T;
}
