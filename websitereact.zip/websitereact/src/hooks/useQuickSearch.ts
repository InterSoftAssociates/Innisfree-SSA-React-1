import { useCallback } from 'react';
import useSearchApi from 'src/hooks/useSearchApi';
import { postQuickSearch, QuickSearchResponse } from '../services/search';
import { Institution } from '@/features/institutions/types';
import { Company } from '@/features/companies/types';

interface UseQuickSearchReturnType {
  institutions: Institution[];
  companies: Company[];
  handleSearch: (searchValue: string) => void;
}

export default function useQuickSearch(): UseQuickSearchReturnType {
  const fetcher = useCallback(async (searchValue: string) => {
    const results = await postQuickSearch(searchValue);
    return results;
  }, []);

  const { result, handleSearch } = useSearchApi<QuickSearchResponse>(fetcher, {
    debounceTime: 250,
  });

  return {
    institutions: result?.institutions ?? [],
    companies: result?.companies ?? [],
    handleSearch,
  };
}
