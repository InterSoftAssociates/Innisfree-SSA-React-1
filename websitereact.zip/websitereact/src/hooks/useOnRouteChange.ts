import { useEffect, useState } from 'react';
import { useLocation } from 'react-router';

export default function useOnRouteChange(
  cb: (route: string) => void,
  deps: any[] = [],
) {
  const location = useLocation();
  const [currentLocation, setCurrentLocation] = useState<string>('');

  useEffect(() => {
    if (currentLocation !== location.pathname) {
      setCurrentLocation(location.pathname);
    }
  }, [location, currentLocation]);

  useEffect(() => {
    if (currentLocation && currentLocation !== location.pathname) {
      cb(location.pathname);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentLocation, location, ...deps]);

  return null;
}
