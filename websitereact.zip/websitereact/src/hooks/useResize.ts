import { useState, useEffect } from 'react';

export default function useResize({
  breakpoint = 768,
  onBreakpointChanged = () => {},
}: {
  breakpoint?: number;
  onBreakpointChanged?: (isMobile: boolean) => void;
}): {
  isMobile: boolean;
} {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= breakpoint);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= breakpoint);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [breakpoint]);

  useEffect(() => {
    onBreakpointChanged(isMobile);
  }, [isMobile]);

  return { isMobile };
}
