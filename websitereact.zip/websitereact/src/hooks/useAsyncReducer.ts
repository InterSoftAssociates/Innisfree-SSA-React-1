import { useCallback, useRef, useState } from 'react';

export default function useAsyncReducer<S, A>(
  reducer: (state: S, action: A) => S,
  initialState: S,
) {
  const [state, setState] = useState(initialState);
  const stateRef = useRef(state);

  const dispatch = useCallback(
    (action: A) => {
      setState((prevState) => {
        const newState = reducer(prevState, action);
        stateRef.current = newState;
        return newState;
      });
    },
    [reducer],
  );

  const getState = useCallback(() => stateRef.current, []);

  return [state, dispatch, getState] as const;
}
