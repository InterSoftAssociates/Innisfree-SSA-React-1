// hooks/useEventListener.ts
import { useEffect } from 'react';

export default function useEventListener(
  eventType: string,
  callback: (event: Event) => void,
  condition: boolean,
): void {
  useEffect(() => {
    if (condition) {
      document.addEventListener(eventType, callback);
      return () => document.removeEventListener(eventType, callback);
    }
  }, [eventType, callback, condition]);
}
