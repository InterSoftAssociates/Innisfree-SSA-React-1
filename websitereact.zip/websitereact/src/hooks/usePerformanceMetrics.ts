import { useState, useCallback, useEffect } from 'react';

interface PerformanceMetrics {
  initialLoadTime: number;
  filterChangeTime: number;
}

interface UsePerformanceMetricsProps {
  initialLoadCallback: () => Promise<void>;
}

export default function usePerformanceMetrics({
  initialLoadCallback,
}: UsePerformanceMetricsProps) {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    initialLoadTime: 0,
    filterChangeTime: 0,
  });

  const measureTime = useCallback(
    async (
      callback: () => Promise<void>,
      metricKey: keyof PerformanceMetrics,
    ) => {
      const startTime = performance.now();
      await callback();
      const endTime = performance.now();
      setMetrics((prev) => ({
        ...prev,
        [metricKey]: endTime - startTime,
      }));
    },
    [],
  );

  const measureFilterChange = useCallback(
    (callback: () => Promise<void>) => {
      return measureTime(callback, 'filterChangeTime');
    },
    [measureTime],
  );

  useEffect(() => {
    measureTime(initialLoadCallback, 'initialLoadTime');
  }, [initialLoadCallback, measureTime]);

  return {
    metrics,
    measureFilterChange,
  };
}
