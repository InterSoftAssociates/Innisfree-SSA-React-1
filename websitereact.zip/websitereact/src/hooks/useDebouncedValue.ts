import { useState, useEffect } from 'react';

// Custom React hook to debounce a value
export default function useDebouncedValue<T>(value: T, delay: number = 500): T {
  // State variable to store the debounced value
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    // Create a new timeout whenever the value changes (including on component mount)
    // This ensures that the API is not called on every keystroke or immediate value change
    // Wait for the specified delay duration (default is 500ms)
    // Then update the debouncedValue with the latest value
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    // Clean up the timeout when the component unmounts or when the value/delay changes
    // This ensures that the timeout is cleared and prevents memory leaks
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  // Return the debouncedValue, which represents the latest value after the delay
  return debouncedValue;
}
