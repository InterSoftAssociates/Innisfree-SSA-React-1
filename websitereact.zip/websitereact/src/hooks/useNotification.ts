import { useSnackbar, VariantType } from 'notistack';

export const useNotification = () => {
  const { enqueueSnackbar } = useSnackbar();

  const displayMessage = (
    message: string,
    variant: VariantType = 'info',
    duration = 5000
  ) => {
    enqueueSnackbar(message, {
      variant,
      autoHideDuration: duration,
      anchorOrigin: {
        vertical: 'top',
        horizontal: 'center',
      },
    });
  };

  return { displayMessage };
};
