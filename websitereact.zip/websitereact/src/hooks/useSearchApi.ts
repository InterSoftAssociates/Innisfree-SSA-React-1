import { useState, useCallback } from 'react';
import useSearchInputState from './useSearchInputState';

interface FetcherOptions {
  offset?: number;
  [key: string]: any;
}

type Fetcher<T> = (searchQuery: string, options?: FetcherOptions) => Promise<T>;

interface UseSearchApiOptions {
  debounceTime?: number;
}

export default function useSearchApi<T>(
  fetcher: Fetcher<T>,
  { debounceTime = 500 }: UseSearchApiOptions = {},
) {
  const [result, setResult] = useState<T | null>(null);
  const [isSearchLoading, setIsSearchLoading] = useState(false);
  const [previousSearchQuery, setPreviousSearchQuery] = useState('');

  const searchRequestHandler = useCallback(
    async (newSearchQuery: string, other: FetcherOptions = {}) => {
      try {
        if (isSearchLoading) return;

        if (newSearchQuery !== previousSearchQuery) {
          setIsSearchLoading(true);
          setResult(null);
        }

        const data = await fetcher(newSearchQuery, other);
        setResult(data);
        return data;
      } catch (error) {
        console.error('Error searching:', error);
        setResult(null);
      } finally {
        setPreviousSearchQuery(newSearchQuery);
        setIsSearchLoading(false);
      }
    },
    [fetcher, previousSearchQuery, isSearchLoading],
  );

  const [searchQuery, setSearchQuery, debouncedSearchQuery] =
    useSearchInputState({
      searchHandler: searchRequestHandler,
      initialValue: '',
      debounceTime,
    });

  const handleSearch = useCallback(
    (value: string) => {
      setSearchQuery(value);
    },
    [setSearchQuery],
  );

  return {
    result,
    isSearchLoading,
    searchQuery: String(searchQuery),
    handleSearch,
    searchRequestHandler,
    debouncedSearchQuery,
    previousSearchQuery,
  };
}
