import { useRef, useEffect, useCallback } from 'react';

export default function useClickAwayListener<T extends HTMLElement>(
  onClickAway: () => void,
  extraConditions: boolean[] = [true],
): React.RefObject<T> {
  const ref = useRef<T>(null);

  const handleClickOutside = useCallback(
    (event: MouseEvent) => {
      let conditions: boolean[] = [
        !!ref?.current,
        !ref?.current?.contains?.(event.target as Node),
      ];

      if (Array.isArray(extraConditions)) {
        conditions = [...conditions, ...extraConditions];
      }

      if (conditions.every(Boolean)) {
        onClickAway();
      }
    },
    [onClickAway, extraConditions],
  );

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [handleClickOutside]);

  return ref;
}
