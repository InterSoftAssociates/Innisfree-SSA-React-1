import { useEffect, useRef, useState } from 'react';

export default function useSearchInputState({
  searchHandler = (v) => {
    console.log('search result', v);
  },
  debounceTime = 600,
  initialValue = '',
}) {
  // to prevent calling the handler on component mount
  const didMountRef = useRef(false);

  const [searchValue, setSearchValue] = useState(initialValue);
  const [searchValueDebounced, setSearchValueDebounced] =
    useState(initialValue);

  useEffect(() => {
    let delayDebounceFn;

    if (didMountRef.current) {
      delayDebounceFn = setTimeout(
        () => {
          searchHandler(searchValue);
          setSearchValueDebounced(searchValue ?? null);
        },

        debounceTime,
      );
    } else {
      didMountRef.current = true;
    }

    return () => clearTimeout(delayDebounceFn);
  }, [searchValue, debounceTime]);

  return [searchValue, setSearchValue, searchValueDebounced];
}
