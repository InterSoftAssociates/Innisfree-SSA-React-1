import { useState, useCallback, useEffect } from 'react';
import useSWR from 'swr';
import useDebouncedValue from '@/hooks/useDebouncedValue';

interface UseGenericSearchProps<T, U> {
  searchFunction: (term: string) => Promise<T[]>;
  getInfoFunction: (item: T) => Promise<U>;
  onItemSelected: (item: T | null, itemInfo: U | null) => void;
  defaultItem?: T | null;
  getSearchTerm: (item: T) => string;
  searchKey: string;
}

interface UseGenericSearchReturn<T> {
  searchTerm: string;
  items: T[];
  isLoading: boolean;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleSelect: (item: T) => Promise<U | undefined>;
  isLoadingInfo: boolean;
}

export default function useAPIAutocompleteSearch<T, U>({
  searchFunction,
  getInfoFunction,
  onItemSelected,
  defaultItem,
  getSearchTerm,
  searchKey,
}: UseGenericSearchProps<T, U>): UseGenericSearchReturn<T> {
  const [searchTerm, setSearchTerm] = useState<string>(
    getSearchTerm(defaultItem || ({} as T)),
  );
  const debouncedSearchTerm = useDebouncedValue(searchTerm, 250);

  const [isDefaultItemLoaded, setIsDefaultItemLoaded] =
    useState<boolean>(false);
  const [isLoadingInfo, setIsLoadingInfo] = useState<boolean>(false);
  const [selectedItem, setSelectedItem] = useState<T | null>(null);

  const { data: items = [] as T[], isValidating } = useSWR(
    searchTerm ? `${searchKey}_${debouncedSearchTerm}` : null,
    () =>
      searchFunction(encodeURIComponent(debouncedSearchTerm)).catch(() => []),
  );

  const handleSelect = useCallback(
    async (item: T): Promise<U | undefined> => {
      try {
        if (!item) return;
        if (isLoadingInfo) return;
        setIsLoadingInfo(true);
        const itemInfo = await getInfoFunction(item);
        setSelectedItem(item);
        setSearchTerm(getSearchTerm(item));
        setIsLoadingInfo(false);
        onItemSelected(item, itemInfo);
        return itemInfo;
      } catch (error) {
        console.error(`Error selecting ${searchKey}:`, error);
        setIsLoadingInfo(false);
      }
    },
    [isLoadingInfo, getInfoFunction, getSearchTerm, onItemSelected, searchKey],
  );

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      // @ts-expect-error type issue on inputType nativeElement
      const isBackSpace = e.nativeEvent.inputType === 'deleteContentBackward';
      if (isBackSpace && selectedItem) {
        setSearchTerm('');
        setSelectedItem(null);
        onItemSelected(null, null);
        return;
      }

      setSearchTerm(e.target.value);
    },
    [selectedItem, onItemSelected],
  );

  useEffect(() => {
    if (defaultItem && !isDefaultItemLoaded) {
      setIsDefaultItemLoaded(true);
      handleSelect(defaultItem);
    }
  }, [defaultItem, handleSelect, setIsDefaultItemLoaded, isDefaultItemLoaded]);

  return {
    searchTerm,
    items,
    isLoading: isValidating || isLoadingInfo,
    handleInputChange,
    handleSelect,
    isLoadingInfo,
  };
}
