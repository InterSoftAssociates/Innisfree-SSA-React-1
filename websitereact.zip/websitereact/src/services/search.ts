import api from '@api';
import { Company } from '@/features/companies/types';
import { Institution } from '@/features/institutions/types';
import IQCache from '@/lib/cache';

export interface QuickSearchResponse {
  companies: Company[];
  institutions: Institution[];
}

const homeQuickSearchCache: IQCache = new IQCache({
  ttl: 1000 * 60 * 60, // 1 hour
  maxItems: 100,
  key: 'HOME_QUICKSEARCH',
});

export const postQuickSearch = async (query: string) => {
  if (query.length < 2) return;

  const cached = homeQuickSearchCache.get(query);
  if (cached) return cached;

  const response = await api.post<QuickSearchResponse>(
    `/Home/QuickSearch/${query}`,
    {},
  );

  homeQuickSearchCache.set(query, response.data);
  return response.data;
};
