import {
  AuthenticationResult,
  Configuration,
  PublicClientApplication,
} from '@azure/msal-browser';
import { postVerify } from '@auth/services';
import Cookies from 'js-cookie';

// MSAL configuration
const msalConfig: Configuration = {
  auth: {
    clientId: '1086b134-d4bc-4073-b927-996dd21f76b0', // Replace with your client ID
    authority:
      'https://login.microsoftonline.com/b7b5ed0d-7598-462e-847d-c4e929e3c9e6', // Replace with your tenant ID
    redirectUri: 'http://localhost:5173/', // Replace with your redirect URI
  },
  cache: {
    cacheLocation: 'sessionStorage', // This configures where your cache will be stored
    storeAuthStateInCookie: true, // Set this to true if you are having issues on IE11 or Edge
  },
};

function handleResponse(response: AuthenticationResult | null) {
  if (response !== null) {
    console.log('ID Token acquired at: ' + new Date().toString());
    // Store the token in a cookie
    Cookies.set('idToken', response.idToken, {
      domain: window.location.hostname,
      expires: 1 / 2,
    });

    postVerify(response.idToken);
  } else {
    const currentAccounts = msalInstance.getAllAccounts(); //can examing saved token by existing accounts.
    if (!currentAccounts || currentAccounts.length === 0) {
      // No user signed in
      return;
    }
  }
}

// MSAL instance
export const msalInstance = new PublicClientApplication(msalConfig);

export const initializeMsal = async () => {
  await msalInstance.initialize();

  // Handle the redirect promise after initialization
  return msalInstance
    .handleRedirectPromise()
    .then(handleResponse)
    .catch((error) => {
      console.error(error);
    });
};
