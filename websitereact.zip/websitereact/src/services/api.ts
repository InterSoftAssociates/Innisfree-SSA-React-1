import axios, { AxiosResponse } from 'axios';
import Cookies from 'js-cookie';
import { logout } from '@/features/auth/services';

window.Cookies = Cookies;
const api = axios.create({
  baseURL:
    import.meta.env.NODE_ENV === 'production'
      ? 'http://activeiqservices.intersoft.lan'
      : import.meta.env.VITE_APP_API_URL || 'http://localhost:5251',
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    SessionKey: Cookies.get('sessionKey'),
    // domain: window.location.hostname, // this breaks api calls, probably a config in the backend that doesn't want this domain on port 5173?
  },
  withCredentials: true,
});

// while request is processing, show loading cursor
api.interceptors.request.use(
  (config) => {
    document.body.style.cursor = 'progress';

    const sessionKey = Cookies.get('sessionKey');

    if (sessionKey) {
      config.headers.SessionKey = sessionKey;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  },
);

const isSecureSessionEnabled = true;
const secureSessionCheck = (resp: AxiosResponse) => {
  if (isSecureSessionEnabled) {
    const keyCheck = resp.headers['SessionStatus'];

    if (keyCheck) {
      logout('Session Expired');
    }
  }
};

// hide loading cursor and check for session expiration on response
api.interceptors.response.use(
  (response) => {
    document.body.style.cursor = 'default';
    secureSessionCheck(response);
    return response;
  },
  (error) => {
    document.body.style.cursor = 'default';

    const { response } = error;

    if (response && response.status === 401) {
      logout('Unauthorized');
    }

    return Promise.reject(error);
  },
);

export default api;
