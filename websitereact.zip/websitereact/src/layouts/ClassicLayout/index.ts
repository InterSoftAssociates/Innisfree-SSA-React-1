export { default } from './ClassicLayout';
