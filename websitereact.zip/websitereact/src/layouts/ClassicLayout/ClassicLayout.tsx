import Navbar from '@/components/Navbar';
import './ClassicLayout.scss';

interface ClassicLayoutProps {
  children: React.ReactNode;
}

export default function ClassicLayout({ children }: ClassicLayoutProps) {
  return (
    <div className="ClassicLayout">
      <Navbar />
      <div className=" ClassicLayout__children">{children}</div>
    </div>
  );
}
