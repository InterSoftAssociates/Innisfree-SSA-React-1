import React from 'react';
import { SnackbarProvider as NotiSnackProvider, useSnackbar } from 'notistack';
import IconButton from '../components/shared/IconButton';
import { faTimes } from '@fortawesome/free-solid-svg-icons';

export default function SnackbarProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <NotiSnackProvider
      maxSnack={3}
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'right',
      }}
      autoHideDuration={3000}
      action={(key) => <SnackBarClose snackbarKey={key} />}
    >
      {children}
    </NotiSnackProvider>
  );
}

const SnackBarClose = ({ snackbarKey }: { snackbarKey: any }) => {
  const { closeSnackbar } = useSnackbar();

  return (
    <IconButton
      icon={faTimes}
      onClick={() => {
        closeSnackbar(snackbarKey);
      }}
      color="default"
      size="small"
    />
  );
};
