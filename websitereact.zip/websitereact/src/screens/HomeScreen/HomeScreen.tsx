// hooks
import useQuickSearch from '@/hooks/useQuickSearch';
import useCompanyStore from '@/features/companies/store/company.store';
import { useNavigate } from 'react-router';

// components
import ListCard from '@/components/shared/ListCard/ListCard';
import { Card, Input } from '@/components/shared';

// icons
import { faSearch } from '@fortawesome/free-solid-svg-icons';

// styles
import './HomeScreen.scss';

// lib
import { PATHS } from '@/routes/paths';
import { Company } from '@/features/companies/types';

export default function HomeScreen() {
  const { institutions, companies, handleSearch } = useQuickSearch();
  const { setSelectedCompanyFromHomeScreen } = useCompanyStore();

  const navigate = useNavigate();

  return (
    <main className="HomeScreen">
      <Card
        containerClassName="HomeScreen__quick-search"
        contentClassName="HomeScreen__quick-search__content"
        Component="section"
      >
        <Input
          icon={faSearch}
          type="text"
          placeholder="Search..."
          onChange={(e) => handleSearch(e.target.value)}
          className="HomeScreen__search"
        />

        <ListCard
          headerTitle="Institutions"
          items={institutions}
          renderItemLabel={(institution) => institution.institutionName}
          getItemKey={(institution) => institution.entityId}
          onItemClick={(institution) =>
            navigate(
              PATHS.get('INSTITUTIONS.PROFILE', {
                entityId: institution.entityId,
              }),
            )
          }
        />

        <ListCard
          headerTitle="Companies"
          items={companies}
          renderItemLabel={(company) => company.companyName}
          getItemKey={(company) => company.companyId}
          onItemClick={(company: Company) => {
            setSelectedCompanyFromHomeScreen(company);
            navigate(
              PATHS.get('COMPANIES.HISTORICAL_HOLDERS') + `?ignite=true`,
            );
          }}
        />
      </Card>
    </main>
  );
}
