import { Card } from '@/components/shared';
import './NotFoundScreen.scss';

export default function NotFoundScreen() {
  return (
    <main className="NotFoundScreen">
      <Card contentClassName="NotFoundScreen__Card__content">
        <h1 className="NotFoundScreen__title">
          Oops! Requested page not found.
        </h1>
        <h2 className="NotFoundScreen__frown__container">
          <i className="NotFoundScreen__frown__icon fa-solid fa-face-frown"></i>
        </h2>
      </Card>
    </main>
  );
}
