interface Fund {
  fundId: number;
  entityId: number;
  factsetEntityId: string;
  fundName: string;
  investmentStyle: string;
  address: string | null;
  phone: string | null;
  aum: number | null;
  profile: string | null;
  industry: string | null;
  sector: string | null;
  sic: string | null;
  buysIn: number | null;
  sellsOut: number | null;
  buys: number | null;
  sells: number | null;
  numHoldings: number;
  turnoverRate: number | null;
}

export default Fund;
