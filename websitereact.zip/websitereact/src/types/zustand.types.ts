export interface ZustandSetStateAction<T> {
  (args: Partial<T> | ((state: T) => Partial<T>)): void;
}

export interface ZustandStoreReducer<T> {
  get: () => T;
  set: ZustandSetStateAction<T>;
}
