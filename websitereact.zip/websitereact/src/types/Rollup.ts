export default interface Rollup {
  address?: string;
  aum?: number;
  buys?: number;
  buysIn?: number;
  entityId: number;
  factsetEntityId: string;
  industry: number;
  institutionId: number;
  institutionName: string;
  investmentStyle: string;
  mainFundParent: boolean;
  numHoldings: number;
  phone: number;
  profile: number;
  sector: number;
  sells: number;
  sellsOut: number;
  sic?: number;
  turnoverRate?: number;
}
