export default interface Person {
  entityId: number;
  factsetEntityId: string;
  fullName: string;
  jobFunction?: string | null;
  personId: number;
  phone?: string | null;
}
