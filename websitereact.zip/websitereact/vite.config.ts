import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

const __dirname = path.resolve();

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    sourcemap: true,
  },
  server: {
    port: 5173,
    open: true, // open browser on start
  },
  resolve: {
    alias: {
      src: path.resolve(__dirname, './src/'),
      '@': path.resolve(__dirname, './src/'),
      '@api': path.resolve(__dirname, './src/services/api.ts'),
      '@auth': path.resolve(__dirname, './src/features/auth/'),
    },
  },
});
