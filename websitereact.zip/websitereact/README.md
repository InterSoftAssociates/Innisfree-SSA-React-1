# Innisfreee React

# install node

install chocolatey: https://chocolatey.org/install
install NVM (node version manager): https://community.chocolatey.org/packages/nvm
install node version 20.16.0: nvm install 20.16.0
check node version: node -v
install pnpm: https://pnpm.io/installation

## install and run

(might have to open terminal as admin because there's a weird issue with infragistics packages...)
pnpm install
pnpm run dev

storybook is on port 7007

make sure you have node version ~20.16.0
