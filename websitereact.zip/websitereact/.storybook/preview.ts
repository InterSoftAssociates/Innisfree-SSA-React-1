import type { Preview } from '@storybook/react';
import { themes } from '@storybook/theming';

const preview: Preview = {
  parameters: {
    docs: {
      theme: themes.dark,
    },
    layout: 'centered',
    backgrounds: {
      default: 'dark',
      values: [
        // { name: 'dark', value: '#121212' },
        { name: 'dark', value: 'rgba(255, 255, 255, 0.9)' },
        { name: 'light', value: '#ffffff' },
      ],
    },

    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
  },
};

export default preview;
